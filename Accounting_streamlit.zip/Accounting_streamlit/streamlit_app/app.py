import streamlit as st

st.set_page_config(
    page_title="RICP — Reconciliation Risk State Engine",
    page_icon="🏦",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
/* Hide Streamlit default branding */
#MainMenu {visibility: hidden;}
footer {visibility: hidden;}
header {visibility: hidden;}

/* Sidebar styling */
[data-testid="stSidebar"] {
    background-color: #0d1117;
    border-right: 1px solid #1e293b;
}
[data-testid="stSidebar"] .stRadio label {
    font-size: 14px;
    padding: 4px 0;
}

/* Cards */
.metric-card {
    background: #161b2e;
    border: 1px solid #1e3a5f;
    border-radius: 10px;
    padding: 16px;
    text-align: center;
}
.metric-card .label {
    font-size: 11px;
    color: #94a3b8;
    font-family: monospace;
    letter-spacing: 1px;
    text-transform: uppercase;
}
.metric-card .value {
    font-size: 28px;
    font-weight: 800;
    margin-top: 4px;
}

/* Risk severity colors */
.high { color: #f87171; }
.medium { color: #fbbf24; }
.low { color: #34d399; }
.info { color: #4f8ef7; }
.muted { color: #64748b; }

/* Badges */
.badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 600;
    font-family: monospace;
}
.badge-red { background: rgba(248,113,113,0.15); color: #f87171; border: 1px solid rgba(248,113,113,0.3); }
.badge-amber { background: rgba(251,191,36,0.15); color: #fbbf24; border: 1px solid rgba(251,191,36,0.3); }
.badge-green { background: rgba(52,211,153,0.15); color: #34d399; border: 1px solid rgba(52,211,153,0.3); }
.badge-blue { background: rgba(79,142,247,0.15); color: #4f8ef7; border: 1px solid rgba(79,142,247,0.3); }
.badge-gray { background: rgba(100,116,139,0.15); color: #94a3b8; border: 1px solid rgba(100,116,139,0.3); }

/* Info panel */
.info-panel {
    background: #161b2e;
    border: 1px solid #1e293b;
    border-radius: 8px;
    padding: 14px;
}
.info-panel h4 {
    font-size: 12px;
    color: #94a3b8;
    font-family: monospace;
    letter-spacing: 1px;
    text-transform: uppercase;
    margin-bottom: 8px;
}
.info-row {
    display: flex;
    justify-content: space-between;
    font-size: 13px;
    padding: 2px 0;
    border-bottom: 1px solid #1e293b;
}
.info-row:last-child { border-bottom: none; }
.info-label { color: #64748b; }
.info-value { color: #e2e8f0; font-weight: 500; }

/* Historical match card */
.match-card {
    background: #1a2035;
    border: 1px solid #1e3a5f;
    border-radius: 8px;
    padding: 12px;
    margin-bottom: 8px;
}

/* Page title */
.page-header {
    border-bottom: 1px solid #1e293b;
    padding-bottom: 12px;
    margin-bottom: 20px;
}
.page-header h1 {
    font-size: 22px;
    font-weight: 700;
    color: #e2e8f0;
    margin: 0;
}
.page-header p {
    font-size: 13px;
    color: #64748b;
    margin: 4px 0 0 0;
}

/* Divider */
hr { border-color: #1e293b; }

/* Feature bar container */
.feat-row {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 4px;
}
.feat-label { font-size: 11px; color: #94a3b8; width: 140px; }
.feat-bar-bg { flex: 1; height: 6px; background: #1e293b; border-radius: 3px; overflow: hidden; }
.feat-bar-fill { height: 100%; border-radius: 3px; }
.feat-value { font-size: 11px; color: #e2e8f0; font-family: monospace; width: 50px; text-align: right; }
</style>
""", unsafe_allow_html=True)

pages = {
    "📊 Dashboard": "dashboard",
    "📁 Upload Breaks": "upload",
    "🔍 Analysis": "analysis",
    "📈 Segments": "segments",
    "🤖 ML Training": "training",
    "📋 Audit Log": "audit",
}

with st.sidebar:
    st.markdown("""
    <div style='padding: 16px 0 24px 0;'>
        <div style='font-size:18px; font-weight:800; color:#4f8ef7; letter-spacing:1px;'>🏦 RICP</div>
        <div style='font-size:11px; color:#64748b; margin-top:2px;'>Reconciliation Risk Engine</div>
    </div>
    """, unsafe_allow_html=True)

    page_name = st.radio(
        "Navigation",
        list(pages.keys()),
        label_visibility="collapsed",
    )
    st.markdown("<hr>", unsafe_allow_html=True)
    st.markdown("<div style='font-size:11px; color:#334155; text-align:center;'>FastAPI + Streamlit + AG Grid</div>", unsafe_allow_html=True)

page_key = pages[page_name]

if page_key == "dashboard":
    from streamlit_app.pages.dashboard import render
    render()
elif page_key == "upload":
    from streamlit_app.pages.upload import render
    render()
elif page_key == "analysis":
    from streamlit_app.pages.analysis import render
    render()
elif page_key == "segments":
    from streamlit_app.pages.segments import render
    render()
elif page_key == "training":
    from streamlit_app.pages.training import render
    render()
elif page_key == "audit":
    from streamlit_app.pages.audit import render
    render()
