import streamlit as st
import plotly.graph_objects as go
import pandas as pd
from st_aggrid import AgGrid, GridOptionsBuilder, GridUpdateMode, JsCode
from streamlit_app.api import get_analysis

FEATURE_NAMES = {
    "breakFrequency30d": "Break Freq (30d)",
    "avgAgeing": "Avg Ageing",
    "thresholdDistance": "Threshold Dist",
    "repeatTradeFlag": "Repeat Trade",
    "segmentVolatility": "Seg Volatility",
    "maturityProximityDays": "Maturity Prox",
}
PLOT_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(13,17,23,0.4)",
    font=dict(color="#e2e8f0", size=10),
    margin=dict(l=0, r=10, t=10, b=0),
    showlegend=False,
)

SEV_BADGE_CLASS = {"High": "badge-red", "Medium": "badge-amber", "Low": "badge-green"}


def sev_color(s):
    return {"High": "#f87171", "Medium": "#fbbf24", "Low": "#34d399"}.get(s, "#475569")


def conf_badge(sim):
    if sim >= 80:
        return f'<span class="badge badge-green">{sim:.0f}% match</span>'
    elif sim >= 50:
        return f'<span class="badge badge-amber">{sim:.0f}% match</span>'
    return f'<span class="badge badge-gray">{sim:.0f}% match</span>'


def feature_bar_html(label, value, max_val, color="#4f8ef7"):
    pct = min(100, (float(value) / max_val * 100)) if max_val else 0
    return (
        f'<div class="feat-row">'
        f'<span class="feat-label">{label}</span>'
        f'<div class="feat-bar-bg"><div class="feat-bar-fill" style="width:{pct:.1f}%; background:{color};"></div></div>'
        f'<span class="feat-value">{float(value):.2f}</span>'
        f"</div>"
    )


def plotly_hbar(labels, values, colors, height=160):
    max_v = max(values) if values else 1
    fig = go.Figure(go.Bar(
        x=values,
        y=labels,
        orientation="h",
        marker=dict(color=colors),
        text=[f"{v:.1f}%" for v in values],
        textposition="outside",
        hovertemplate="%{y}: %{x:.1f}%<extra></extra>",
    ))
    fig.update_layout(**PLOT_LAYOUT, height=height,
                      xaxis=dict(showgrid=False, color="#334155", range=[0, max_v * 1.25]),
                      yaxis=dict(showgrid=False, color="#64748b", autorange="reversed"))
    return fig


def render():
    st.markdown('<div class="page-header"><h1>🔍 Break Analysis</h1><p>ML predictions, feature importance, and intelligent historical linkage — up to 5 references per break</p></div>', unsafe_allow_html=True)

    analysis = get_analysis()

    if not analysis:
        st.info("No data yet. Upload break files to populate analysis.")
        return

    df = pd.DataFrame(analysis)

    def safe_sev(b):
        return (b.get("prediction") or {}).get("severity", "Unscored") if isinstance(b, dict) else "Unscored"

    def safe_risk(b):
        try:
            return float((b.get("prediction") or {}).get("riskScore", 0) or 0)
        except Exception:
            return 0.0

    high_c = sum(1 for b in analysis if safe_sev(b) == "High")
    med_c = sum(1 for b in analysis if safe_sev(b) == "Medium")
    low_c = sum(1 for b in analysis if safe_sev(b) == "Low")
    corr_c = sum(1 for b in analysis if b.get("correctionFlag"))

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(f'<div class="metric-card"><div class="label">High Risk</div><div class="value high">{high_c}</div></div>', unsafe_allow_html=True)
    with c2:
        st.markdown(f'<div class="metric-card"><div class="label">Medium</div><div class="value medium">{med_c}</div></div>', unsafe_allow_html=True)
    with c3:
        st.markdown(f'<div class="metric-card"><div class="label">Low Risk</div><div class="value low">{low_c}</div></div>', unsafe_allow_html=True)
    with c4:
        st.markdown(f'<div class="metric-card"><div class="label">Corrected</div><div class="value info">{corr_c}</div></div>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    with st.expander("🔽 Filters", expanded=True):
        f1, f2, f3, f4, f5, f6 = st.columns(6)
        with f1:
            search_q = st.text_input("Search", placeholder="Trade ID / Rec / Entity", key="ana_search")
        with f2:
            rec_opts = ["All"] + sorted(df["recName"].dropna().unique().tolist()) if "recName" in df.columns else ["All"]
            sel_rec = st.selectbox("Rec Name", rec_opts, key="ana_rec")
        with f3:
            ent_opts = ["All"] + sorted(df["entity"].dropna().unique().tolist()) if "entity" in df.columns else ["All"]
            sel_ent = st.selectbox("Entity", ent_opts, key="ana_ent")
        with f4:
            ac_opts = ["All"] + sorted(df["assetClass"].dropna().unique().tolist()) if "assetClass" in df.columns else ["All"]
            sel_ac = st.selectbox("Asset Class", ac_opts, key="ana_ac")
        with f5:
            sel_sev = st.selectbox("Severity", ["All", "High", "Medium", "Low", "Unscored"], key="ana_sev")
        with f6:
            sort_opts = {"Risk Score ↓": "risk", "Ageing ↓": "ageing", "Amount ↓": "amount"}
            sel_sort = st.selectbox("Sort By", list(sort_opts.keys()), key="ana_sort")

    filtered = analysis
    if search_q:
        q = search_q.lower()
        filtered = [b for b in filtered if
                    q in str(b.get("tradeId", "")).lower() or
                    q in str(b.get("recName", "")).lower() or
                    q in str(b.get("entity", "")).lower()]
    if sel_rec != "All":
        filtered = [b for b in filtered if b.get("recName") == sel_rec]
    if sel_ent != "All":
        filtered = [b for b in filtered if b.get("entity") == sel_ent]
    if sel_ac != "All":
        filtered = [b for b in filtered if b.get("assetClass") == sel_ac]
    if sel_sev != "All":
        filtered = [b for b in filtered if safe_sev(b) == sel_sev]

    sort_key = sort_opts[sel_sort]
    if sort_key == "risk":
        filtered = sorted(filtered, key=safe_risk, reverse=True)
    elif sort_key == "ageing":
        filtered = sorted(filtered, key=lambda b: int(b.get("computedAgeingDays") or 0), reverse=True)
    elif sort_key == "amount":
        filtered = sorted(filtered, key=lambda b: float(b.get("amountGbp") or 0), reverse=True)

    filtered = filtered[:100]

    table_rows = []
    for b in filtered:
        pred = b.get("prediction") or {}
        sev = pred.get("severity", "Unscored")
        risk = safe_risk(b)
        repeat = (b.get("features") or {}).get("repeatTradeFlag", 0)
        flags = []
        if b.get("correctionFlag"):
            flags.append("Corrected")
        if repeat == 1:
            flags.append("Repeat")
        table_rows.append({
            "Trade ID": b.get("tradeId", ""),
            "Rec Name": b.get("recName", ""),
            "Entity": b.get("entity", ""),
            "Asset Class": b.get("assetClass", ""),
            "Amount GBP": float(b.get("amountGbp") or 0),
            "Ageing (d)": int(b.get("computedAgeingDays") or 0),
            "Bucket": b.get("derivedAgeingBucket") or b.get("ageingBucket") or "",
            "Risk Score": round(risk, 1),
            "Severity": sev,
            "Flags": ", ".join(flags),
            "Matches": len(b.get("historicalMatches") or []),
        })

    df_table = pd.DataFrame(table_rows) if table_rows else pd.DataFrame(
        columns=["Trade ID", "Rec Name", "Entity", "Asset Class", "Amount GBP",
                 "Ageing (d)", "Bucket", "Risk Score", "Severity", "Flags", "Matches"])

    sev_cell_style = JsCode("""
    function(params) {
        var c = {'High':'#f87171','Medium':'#fbbf24','Low':'#34d399','Unscored':'#475569'};
        return {color: c[params.value] || '#94a3b8', fontWeight:'700', fontFamily:'monospace'};
    }""")
    risk_cell_style = JsCode("""
    function(params) {
        var v = parseFloat(params.value || 0);
        var color = v > 50 ? '#f87171' : v > 25 ? '#fbbf24' : '#34d399';
        return {color: color, fontWeight:'600', fontFamily:'monospace'};
    }""")
    trade_cell_style = {"color": "#4f8ef7", "fontFamily": "monospace", "fontWeight": "600"}

    gb = GridOptionsBuilder.from_dataframe(df_table)
    gb.configure_column("Trade ID", pinned="left", width=120, cellStyle=trade_cell_style)
    gb.configure_column("Rec Name", width=150)
    gb.configure_column("Entity", width=110)
    gb.configure_column("Asset Class", width=110)
    gb.configure_column("Amount GBP", width=130, type=["numericColumn"],
                        valueFormatter=JsCode("function(p){return '\u00a3'+p.value.toLocaleString('en-GB',{minimumFractionDigits:2});}"))
    gb.configure_column("Ageing (d)", width=95, type=["numericColumn"])
    gb.configure_column("Bucket", width=85)
    gb.configure_column("Risk Score", width=100, type=["numericColumn"], cellStyle=risk_cell_style)
    gb.configure_column("Severity", width=100, cellStyle=sev_cell_style)
    gb.configure_column("Flags", width=110)
    gb.configure_column("Matches", width=85)
    gb.configure_selection("single", use_checkbox=False, pre_selected_rows=[])
    gb.configure_default_column(resizable=True, sortable=True, filter=True)
    gb.configure_grid_options(rowHeight=36, headerHeight=38)

    st.markdown(f"**{len(filtered)} breaks** — click a row to inspect ML features, feature importance, and historical linkage")

    grid_resp = AgGrid(
        df_table,
        gridOptions=gb.build(),
        theme="streamlit",
        height=420,
        update_mode=GridUpdateMode.SELECTION_CHANGED,
        fit_columns_on_grid_load=False,
        allow_unsafe_jscode=True,
        key="analysis_grid",
    )

    sel_rows = grid_resp.get("selected_rows")
    sel_break = None
    if sel_rows is not None and len(sel_rows) > 0:
        row = sel_rows[0]
        sel_trade_id = row.get("Trade ID") if isinstance(row, dict) else None
        if sel_trade_id:
            sel_break = next((b for b in filtered if b.get("tradeId") == sel_trade_id), None)

    if sel_break:
        _render_detail_panel(sel_break)
    else:
        st.markdown(
            "<div style='text-align:center; color:#334155; font-size:12px; padding:16px;'>"
            "↑ Click a row to see ML features, feature importance, and historical linkage"
            "</div>",
            unsafe_allow_html=True,
        )


def _render_detail_panel(b: dict):
    trade_id = b.get("tradeId", "")
    pred = b.get("prediction") or {}
    features = b.get("features") or {}
    matches = b.get("historicalMatches") or []
    sev = pred.get("severity", "Unscored")
    risk = float(pred.get("riskScore") or 0)
    sev_col = sev_color(sev)
    badge_cls = SEV_BADGE_CLASS.get(sev, "badge-gray")
    rec_name = b.get("recName", "")
    entity = b.get("entity", "")
    asset_cls = b.get("assetClass", "")

    st.markdown("---")
    st.markdown(
        f"<div style='display:flex; align-items:center; gap:12px; margin-bottom:16px;'>"
        f"<span style='font-size:16px; font-weight:800; color:#4f8ef7; font-family:monospace;'>{trade_id}</span>"
        f"<span class='badge {badge_cls}'>{sev}</span>"
        f"<span style='color:#64748b; font-size:12px;'>Risk Score: <strong style='color:{sev_col};'>{risk:.1f}</strong></span>"
        f"<span style='color:#64748b; font-size:12px;'>|</span>"
        f"<span style='color:#64748b; font-size:12px;'>{rec_name} / {entity} / {asset_cls}</span>"
        "</div>",
        unsafe_allow_html=True,
    )

    col_feat, col_imp, col_hist = st.columns([1, 1, 2])

    with col_feat:
        st.markdown("**🎛 ML Features**")
        if features:
            feat_maxes = {
                "breakFrequency30d": 20, "avgAgeing": 300, "thresholdDistance": 2,
                "repeatTradeFlag": 1, "segmentVolatility": 200000, "maturityProximityDays": 999,
            }
            colors_feat = ["#4f8ef7", "#4f8ef7", "#fbbf24", "#a78bfa", "#f97316", "#34d399"]
            html = ""
            for i, (key, label) in enumerate(FEATURE_NAMES.items()):
                val = float(features.get(key) or 0)
                html += feature_bar_html(label, val, feat_maxes[key], colors_feat[i])
            st.markdown(html, unsafe_allow_html=True)
        else:
            st.caption("No features computed — run the pipeline first.")

    with col_imp:
        st.markdown("**📊 Feature Importance**")
        fi = pred.get("featureImportance")
        if fi and isinstance(fi, dict):
            sorted_fi = sorted(fi.items(), key=lambda x: x[1], reverse=True)
            labels = [FEATURE_NAMES.get(k, k) for k, _ in sorted_fi]
            vals = [float(v) for _, v in sorted_fi]
            max_v = max(vals) if vals else 1
            bar_colors = ["#4f8ef7" if v == max_v else "#2d4a7a" for v in vals]
            st.plotly_chart(plotly_hbar(labels, vals, bar_colors, height=200), use_container_width=True)
        else:
            st.caption("No feature importance — train a model and run inference.")

    with col_hist:
        match_count = len(matches)
        st.markdown(f"**🔗 Historical Linkage** — {match_count} reference{'s' if match_count != 1 else ''}")
        if not matches:
            st.caption("No historical matches. Upload more breaks in the same segment.")
        else:
            for m in matches:
                _render_match_card(m)


def _render_match_card(m: dict):
    sim = float(m.get("similarity") or 0)
    m_sev = m.get("severity") or "—"
    m_sev_col = sev_color(m_sev)
    jira = m.get("jiraId") or ""
    fc = m.get("featureContributions") or {}

    trade_id = m.get("tradeId") or ""
    rec_name = str(m.get("recName") or "")[:16]
    entity = m.get("entity") or "—"
    asset_cls = m.get("assetClass") or "—"
    acct_grp = str(m.get("accountGroup") or "")[:14]
    ageing_days = m.get("ageingDays") or "—"
    ageing_bucket = m.get("ageingBucket") or "—"

    try:
        amt_fmt = f"\u00a3{float(m.get('amountGbp') or 0):,.0f}"
    except Exception:
        amt_fmt = "—"

    jira_html = f'<span class="badge badge-blue" style="margin-left:6px;">{jira}</span>' if jira else ""
    conf_html = conf_badge(sim)

    fc_html = ""
    if fc:
        fc_sorted = sorted(fc.items(), key=lambda x: x[1], reverse=True)
        fc_items_html = ""
        for feat_key, pct in fc_sorted:
            feat_label = FEATURE_NAMES.get(feat_key, feat_key)
            w = min(int(float(pct)), 100)
            pct_val = float(pct)
            fc_items_html += (
                f'<div style="flex:1; min-width:80px;">'
                f'<div style="font-size:9px; color:#475569;">{feat_label}</div>'
                f'<div style="height:4px; background:#1e293b; border-radius:2px; margin:2px 0; overflow:hidden;">'
                f'<div style="width:{w}%; height:100%; background:#06b6d4; border-radius:2px;"></div></div>'
                f'<div style="font-size:9px; color:#94a3b8; font-family:monospace;">{pct_val:.0f}%</div>'
                f"</div>"
            )
        fc_html = (
            '<div style="margin-top:6px; border-top:1px solid #1e293b; padding-top:6px;">'
            '<span style="font-size:9px; color:#475569; font-family:monospace; letter-spacing:1px;">SIMILARITY DRIVERS</span>'
            f'<div style="display:flex; flex-wrap:wrap; gap:4px; margin-top:4px;">{fc_items_html}</div>'
            "</div>"
        )

    card_html = (
        '<div class="match-card">'
        '  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">'
        f'    <div><span style="font-family:monospace; font-size:13px; font-weight:700; color:#4f8ef7;">{trade_id}</span>{jira_html}</div>'
        f"    {conf_html}"
        "  </div>"
        '  <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:8px; font-size:11px; margin-bottom:6px;">'
        f'    <div><div style="color:#475569;">Amount</div><div style="color:#e2e8f0; font-family:monospace;">{amt_fmt}</div></div>'
        f'    <div><div style="color:#475569;">Ageing</div><div style="color:#e2e8f0; font-family:monospace;">{ageing_days}d</div></div>'
        f'    <div><div style="color:#475569;">Severity</div><div style="color:{m_sev_col}; font-weight:700;">{m_sev}</div></div>'
        f'    <div><div style="color:#475569;">Bucket</div><div style="color:#e2e8f0; font-family:monospace;">{ageing_bucket}</div></div>'
        "  </div>"
        '  <div style="display:grid; grid-template-columns:repeat(4,1fr); gap:8px; font-size:11px; padding-top:6px; border-top:1px solid #1e293b;">'
        f'    <div><div style="color:#475569;">Rec Name</div><div style="color:#94a3b8;">{rec_name}</div></div>'
        f'    <div><div style="color:#475569;">Entity</div><div style="color:#94a3b8;">{entity}</div></div>'
        f'    <div><div style="color:#475569;">Asset Class</div><div style="color:#94a3b8;">{asset_cls}</div></div>'
        f'    <div><div style="color:#475569;">Acct Group</div><div style="color:#94a3b8;">{acct_grp}</div></div>'
        "  </div>"
        f"  {fc_html}"
        "</div>"
    )
    st.markdown(card_html, unsafe_allow_html=True)
