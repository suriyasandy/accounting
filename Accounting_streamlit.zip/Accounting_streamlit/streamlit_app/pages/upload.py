import io
import csv
import time
import streamlit as st
import pandas as pd
from streamlit_app.api import upload_breaks

PIPELINE_STEPS = [
    "Ingest Raw Breaks",
    "Data Quality Validation",
    "Ageing Recalculation",
    "Threshold Computation",
    "Trend Analysis (EWMA)",
    "Feature Engineering",
    "ML Inference",
    "Publish Health Snapshot",
]

STEP_ICONS = {
    "complete": "✅",
    "running": "⏳",
    "pending": "⬜",
    "error": "❌",
}


def parse_csv_to_rows(file_bytes: bytes) -> list[dict]:
    content = file_bytes.decode("utf-8-sig")
    reader = csv.DictReader(io.StringIO(content))
    return [row for row in reader]


def render():
    st.markdown('<div class="page-header"><h1>📁 Upload Breaks</h1><p>Upload a CSV file of reconciliation breaks to trigger the 8-step processing pipeline</p></div>', unsafe_allow_html=True)

    uploaded = st.file_uploader(
        "Drag and drop a CSV file or click to browse",
        type=["csv"],
        help="The CSV should contain columns: tradeId, recName, entity, assetClass, accountGroup, startDate, amountGbp, ageingDays, etc.",
    )

    if not uploaded:
        st.markdown("""
        <div style='background:#161b2e; border:1px dashed #1e3a5f; border-radius:10px; padding:32px; text-align:center; color:#64748b;'>
            <div style='font-size:36px; margin-bottom:8px;'>📂</div>
            <div style='font-size:14px;'>Upload a CSV file to get started</div>
            <div style='font-size:12px; margin-top:6px;'>Expected columns: tradeId, recName, entity, assetClass, amountGbp, ageingDays...</div>
        </div>
        """, unsafe_allow_html=True)
        return

    file_bytes = uploaded.read()
    rows = parse_csv_to_rows(file_bytes)

    if not rows:
        st.error("Could not parse CSV file. Please check the file format.")
        return

    st.success(f"✅ Loaded **{len(rows)}** rows from `{uploaded.name}`")

    st.markdown("**Preview (first 5 rows)**")
    df_preview = pd.DataFrame(rows[:5])

    from st_aggrid import AgGrid, GridOptionsBuilder
    gb = GridOptionsBuilder.from_dataframe(df_preview)
    gb.configure_default_column(resizable=True, sortable=False, filter=False, editable=False)
    gb.configure_grid_options(domLayout="autoHeight")
    AgGrid(
        df_preview,
        gridOptions=gb.build(),
        theme="streamlit",
        fit_columns_on_grid_load=True,
        height=180,
    )

    col_detected = list(rows[0].keys())
    st.markdown(f"**Detected columns:** `{'`, `'.join(col_detected)}`")

    st.markdown("---")

    if st.button("🚀 Run Full Pipeline", type="primary", use_container_width=True):
        progress_placeholder = st.empty()
        result_placeholder = st.empty()

        with progress_placeholder.container():
            st.markdown("**Pipeline Progress**")
            step_cols = []
            for i, step_name in enumerate(PIPELINE_STEPS):
                st.markdown(f"<div style='padding:6px 0; font-size:13px;'>{STEP_ICONS['pending']} <span style='color:#64748b;'>Step {i+1}: {step_name}</span></div>", unsafe_allow_html=True)

        with st.spinner("Running pipeline..."):
            step_progress = st.empty()

            with step_progress.container():
                st.markdown("**Pipeline Progress**")
                for i in range(len(PIPELINE_STEPS)):
                    html = ""
                    for j, step_name in enumerate(PIPELINE_STEPS):
                        if j < i:
                            html += f"<div style='padding:6px 0; font-size:13px;'>{STEP_ICONS['complete']} <span style='color:#34d399;'>Step {j+1}: {step_name}</span></div>"
                        elif j == i:
                            html += f"<div style='padding:6px 0; font-size:13px;'>{STEP_ICONS['running']} <span style='color:#fbbf24; font-weight:600;'>Step {j+1}: {step_name} (running...)</span></div>"
                        else:
                            html += f"<div style='padding:6px 0; font-size:13px;'>{STEP_ICONS['pending']} <span style='color:#334155;'>Step {j+1}: {step_name}</span></div>"
                    step_progress.markdown(html, unsafe_allow_html=True)
                    time.sleep(0.15)

            result = upload_breaks(rows)

        progress_placeholder.empty()

        if result.get("batchId"):
            step_progress.empty()
            html = ""
            for j, step_name in enumerate(PIPELINE_STEPS):
                html += f"<div style='padding:6px 0; font-size:13px;'>{STEP_ICONS['complete']} <span style='color:#34d399;'>Step {j+1}: {step_name}</span></div>"
            with result_placeholder.container():
                st.markdown("**Pipeline Progress**")
                st.markdown(html, unsafe_allow_html=True)
                st.markdown("---")
                st.success(f"✅ Pipeline complete! Batch ID: `{result.get('batchId')}` — Status: **{result.get('status', 'complete')}**")
                st.info("📊 Navigate to the **Analysis** page to explore the results.")
        else:
            st.error("Pipeline failed. Check that the backend is running and the data format is correct.")
