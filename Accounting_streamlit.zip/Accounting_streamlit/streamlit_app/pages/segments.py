import streamlit as st
import plotly.graph_objects as go
import pandas as pd
from streamlit_app.api import get_segment_stats, get_segment_trends

PLOT_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(13,17,23,0.6)",
    font=dict(color="#e2e8f0", family="sans-serif", size=11),
    margin=dict(l=10, r=10, t=30, b=10),
    legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(size=11)),
)


def render():
    st.markdown('<div class="page-header"><h1>📈 Risk Segments</h1><p>Segment threshold computations and EWMA trend analysis</p></div>', unsafe_allow_html=True)

    seg_stats = get_segment_stats()
    seg_trends = get_segment_trends()

    stable = sum(1 for s in seg_stats if str(s.get("isDeteriorating", "false")).lower() != "true")
    deteri = len(seg_stats) - stable

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(f'<div class="metric-card"><div class="label">Total Segments</div><div class="value info">{len(seg_stats)}</div></div>', unsafe_allow_html=True)
    with c2:
        st.markdown(f'<div class="metric-card"><div class="label">Stable</div><div class="value low">{stable}</div></div>', unsafe_allow_html=True)
    with c3:
        st.markdown(f'<div class="metric-card"><div class="label">Deteriorating</div><div class="value medium">{deteri}</div></div>', unsafe_allow_html=True)
    with c4:
        st.markdown(f'<div class="metric-card"><div class="label">Trend Points</div><div class="value info">{len(seg_trends)}</div></div>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    tab_thresh, tab_ewma = st.tabs(["📊 Thresholds", "📉 EWMA Trends"])

    with tab_thresh:
        if not seg_stats:
            st.info("No segment data yet. Upload breaks to compute thresholds.")
        else:
            st.markdown("**Per-Segment Threshold Computations**")
            cols_per_row = 3
            for row_start in range(0, len(seg_stats), cols_per_row):
                row_segs = seg_stats[row_start:row_start + cols_per_row]
                cols = st.columns(cols_per_row)
                for ci, seg in enumerate(row_segs):
                    key = seg.get("segmentKey", "")
                    is_det = str(seg.get("isDeteriorating", "false")).lower() == "true"
                    det_badge = '<span class="badge badge-amber">⚠ Deteriorating</span>' if is_det else '<span class="badge badge-green">✓ Stable</span>'

                    def fmt_gbp(v):
                        try:
                            return f"£{float(v):,.0f}"
                        except Exception:
                            return str(v) if v else "—"

                    median = fmt_gbp(seg.get("medianAmount") or seg.get("median_amount"))
                    mad = fmt_gbp(seg.get("mad") or seg.get("madAmount"))
                    material = fmt_gbp(seg.get("materialThreshold") or seg.get("material_threshold"))
                    early = fmt_gbp(seg.get("earlyWarningThreshold") or seg.get("early_warning_threshold"))
                    sigma = fmt_gbp(seg.get("robustSigma") or seg.get("robust_sigma"))
                    bc = seg.get("breakCount") or seg.get("break_count") or 0

                    with cols[ci]:
                        st.markdown(f"""
                        <div class="info-panel" style="margin-bottom:12px;">
                            <div style="display:flex; justify-content:space-between; margin-bottom:10px; align-items:center;">
                                <span style="font-size:12px; font-weight:700; color:#4f8ef7; font-family:monospace;">{key[:22]}</span>
                                {det_badge}
                            </div>
                            <div class="info-row"><span class="info-label">Breaks</span><span class="info-value">{bc}</span></div>
                            <div class="info-row"><span class="info-label">Median</span><span class="info-value">{median}</span></div>
                            <div class="info-row"><span class="info-label">MAD</span><span class="info-value">{mad}</span></div>
                            <div class="info-row"><span class="info-label">Robust Sigma</span><span class="info-value">{sigma}</span></div>
                            <div class="info-row"><span class="info-label" style="color:#fbbf24;">Early Warning</span><span class="info-value" style="color:#fbbf24;">{early}</span></div>
                            <div class="info-row"><span class="info-label" style="color:#f87171;">Material Threshold</span><span class="info-value" style="color:#f87171;">{material}</span></div>
                        </div>
                        """, unsafe_allow_html=True)

    with tab_ewma:
        if not seg_trends:
            st.info("No trend data yet. Upload breaks to compute EWMA trends.")
        else:
            df_trends = pd.DataFrame(seg_trends)
            all_segments = sorted(df_trends["segmentKey"].unique().tolist()) if "segmentKey" in df_trends.columns else []

            if not all_segments:
                st.info("No segments found in trend data.")
                return

            fcol1, fcol2, fcol3, fcol4 = st.columns(4)
            with fcol1:
                rec_opts = ["All"] + sorted(df_trends["segmentKey"].str.extract(r'^([^_]+)')[0].dropna().unique().tolist()) if "segmentKey" in df_trends.columns else ["All"]
                selected_seg = st.selectbox("Segment", ["All"] + all_segments, key="seg_ewma_sel")

            if selected_seg != "All":
                filtered_trends = df_trends[df_trends["segmentKey"] == selected_seg]
            else:
                filtered_trends = df_trends

            if selected_seg == "All":
                unique_segs = all_segments[:6]
                for seg_key in unique_segs:
                    seg_data = df_trends[df_trends["segmentKey"] == seg_key].copy()
                    if seg_data.empty:
                        continue
                    _render_ewma_chart(seg_key, seg_data)
            else:
                _render_ewma_chart(selected_seg, filtered_trends.copy())


def _render_ewma_chart(seg_key: str, seg_data: pd.DataFrame):
    seg_data = seg_data.sort_values("month") if "month" in seg_data.columns else seg_data

    try:
        monthly_sum = pd.to_numeric(seg_data.get("monthlySum", seg_data.get("monthly_sum", [])), errors="coerce").fillna(0)
        ewma_vals = pd.to_numeric(seg_data.get("ewma", []), errors="coerce").fillna(0)
        months = seg_data["month"].tolist() if "month" in seg_data.columns else list(range(len(seg_data)))
        is_det = seg_data["isDeteriorating"].tolist() if "isDeteriorating" in seg_data.columns else [False] * len(seg_data)
    except Exception:
        return

    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=months,
        y=monthly_sum.tolist(),
        name="Monthly Sum",
        fill="tozeroy",
        fillcolor="rgba(79,142,247,0.12)",
        line=dict(color="#4f8ef7", width=2),
        hovertemplate="%{x}: £%{y:,.0f}<extra>Monthly Sum</extra>",
    ))

    if ewma_vals.sum() > 0:
        fig.add_trace(go.Scatter(
            x=months,
            y=ewma_vals.tolist(),
            name="EWMA (α=0.3)",
            line=dict(color="#f97316", width=2, dash="dash"),
            hovertemplate="%{x}: £%{y:,.0f}<extra>EWMA</extra>",
        ))

    for i, (m, det) in enumerate(zip(months, is_det)):
        if det:
            fig.add_vrect(
                x0=m, x1=m,
                fillcolor="rgba(251,191,36,0.08)",
                line=dict(color="#fbbf24", width=1, dash="dot"),
                layer="below",
            )

    layout = dict(PLOT_LAYOUT)
    layout.update(
        title=dict(text=f"<b>{seg_key[:30]}</b>", font=dict(size=13, color="#e2e8f0"), x=0),
        height=260,
        xaxis=dict(showgrid=False, color="#64748b", tickangle=-30, tickfont=dict(size=9)),
        yaxis=dict(showgrid=True, gridcolor="#1e293b", color="#64748b", tickformat=",.0f"),
    )
    fig.update_layout(**layout)
    st.plotly_chart(fig, use_container_width=True)
