import streamlit as st
import pandas as pd
from st_aggrid import AgGrid, GridOptionsBuilder, JsCode
from streamlit_app.api import get_audit_log


def render():
    st.markdown('<div class="page-header"><h1>📋 Audit Log</h1><p>Complete governance and compliance trail of all system actions</p></div>', unsafe_allow_html=True)

    logs = get_audit_log()

    if not logs:
        st.info("No audit entries yet. Upload breaks to populate the audit trail.")
        return

    df = pd.DataFrame(logs)

    total = len(df)
    unique_actions = df["action"].nunique() if "action" in df.columns else 0
    latest_ts = df["createdAt"].max() if "createdAt" in df.columns else "—"

    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown(f'<div class="metric-card"><div class="label">Total Entries</div><div class="value info">{total}</div></div>', unsafe_allow_html=True)
    with c2:
        st.markdown(f'<div class="metric-card"><div class="label">Unique Actions</div><div class="value info">{unique_actions}</div></div>', unsafe_allow_html=True)
    with c3:
        ts_display = str(latest_ts)[:19] if latest_ts != "—" else "—"
        st.markdown(f'<div class="metric-card"><div class="label">Latest Entry</div><div class="value" style="font-size:14px; color:#94a3b8;">{ts_display}</div></div>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    display_cols = ["createdAt", "action", "entity", "entityId", "details_str"]
    for col in ["createdAt", "action", "entity", "entityId", "details"]:
        if col not in df.columns:
            df[col] = ""

    df["createdAt"] = df["createdAt"].apply(lambda x: str(x)[:19] if x else "")
    df["details_str"] = df["details"].apply(lambda x: str(x)[:150] if x else "")

    action_cell_style = JsCode("""
    function(params) {
        const colors = {
            'PIPELINE_COMPLETE': '#4f8ef7',
            'PIPELINE_START': '#4f8ef7',
            'ML_INFERENCE_COMPLETE': '#a78bfa',
            'MODEL_TRAINED': '#a78bfa',
            'DATA_QUALITY': '#34d399',
            'THRESHOLDS_COMPUTED': '#34d399',
            'TRENDS_COMPUTED': '#fbbf24',
            'FEATURES_COMPUTED': '#fbbf24',
            'HEALTH_PUBLISHED': '#34d399',
            'ERROR': '#f87171',
        };
        const color = colors[params.value] || '#94a3b8';
        return {
            'color': color,
            'fontWeight': '600',
            'fontFamily': 'monospace',
            'fontSize': '11px',
        };
    }
    """)

    gb = GridOptionsBuilder.from_dataframe(df[["createdAt", "action", "entity", "entityId", "details_str"]])
    gb.configure_column("createdAt", header_name="Timestamp", width=160, pinned="left")
    gb.configure_column("action", header_name="Action", width=220, cellStyle=action_cell_style)
    gb.configure_column("entity", header_name="Entity", width=140)
    gb.configure_column("entityId", header_name="Entity ID", width=100)
    gb.configure_column("details_str", header_name="Details", flex=1, tooltipField="details_str")
    gb.configure_default_column(resizable=True, sortable=True, filter=True)
    gb.configure_grid_options(rowHeight=36, headerHeight=36)

    AgGrid(
        df[["createdAt", "action", "entity", "entityId", "details_str"]],
        gridOptions=gb.build(),
        theme="streamlit",
        height=600,
        fit_columns_on_grid_load=False,
        allow_unsafe_jscode=True,
    )
