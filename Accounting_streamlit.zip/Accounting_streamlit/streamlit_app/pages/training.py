import io
import csv
import streamlit as st
import pandas as pd
from st_aggrid import AgGrid, GridOptionsBuilder
from streamlit_app.api import get_models, upload_training_data, train_model


def parse_csv_to_rows(file_bytes: bytes) -> list[dict]:
    content = file_bytes.decode("utf-8-sig")
    reader = csv.DictReader(io.StringIO(content))
    return [row for row in reader]


def render():
    st.markdown('<div class="page-header"><h1>🤖 ML Training Pipeline</h1><p>Upload historical break data and train the gradient-boosted risk classifier</p></div>', unsafe_allow_html=True)

    col_upload, col_train = st.columns([1, 1])

    with col_upload:
        st.markdown("#### Step 1 — Upload Historical Training Data")
        uploaded = st.file_uploader(
            "Upload historical CSV",
            type=["csv"],
            key="training_csv",
            help="Historical breaks used as training labels. More data = better model accuracy.",
        )

        if uploaded:
            file_bytes = uploaded.read()
            rows = parse_csv_to_rows(file_bytes)
            if rows:
                st.success(f"✅ Loaded **{len(rows)}** historical rows")
                df_prev = pd.DataFrame(rows[:5])
                gb = GridOptionsBuilder.from_dataframe(df_prev)
                gb.configure_default_column(resizable=True, sortable=False, editable=False)
                AgGrid(df_prev, gridOptions=gb.build(), theme="streamlit", height=160, fit_columns_on_grid_load=True)

                if st.button("📤 Upload Training Data", type="secondary", use_container_width=True):
                    with st.spinner("Uploading training data..."):
                        result = upload_training_data(rows)
                    if result.get("batchId"):
                        st.success(f"✅ Training data uploaded! Batch: `{result.get('batchId')}`")
                    else:
                        st.error("Upload failed. Check backend connection.")
            else:
                st.error("Could not parse CSV file.")

    with col_train:
        st.markdown("#### Step 2 — Train ML Model")
        st.markdown("""
        <div class="info-panel">
            <div style="font-size:13px; color:#94a3b8; line-height:1.6;">
                Trains a gradient-boosted decision tree classifier on the 6-feature vectors.<br><br>
                Requires at least <strong style="color:#4f8ef7">5 break records</strong> with features in the system.<br><br>
                <strong>Features:</strong> breakFrequency30d, avgAgeing, thresholdDistance, repeatTradeFlag, segmentVolatility, maturityProximityDays
            </div>
        </div>
        """, unsafe_allow_html=True)
        st.markdown("<br>", unsafe_allow_html=True)

        if st.button("🚀 Train Model", type="primary", use_container_width=True):
            with st.spinner("Training gradient-boosted model (100 iterations)..."):
                result = train_model()

            if result.get("modelId"):
                st.success("✅ Model trained successfully!")
                r1, r2 = st.columns(2)
                with r1:
                    st.markdown(f'<div class="metric-card"><div class="label">Accuracy</div><div class="value" style="color:#34d399;">{float(result.get("accuracy", 0)):.2%}</div></div>', unsafe_allow_html=True)
                with r2:
                    st.markdown(f'<div class="metric-card"><div class="label">AUC</div><div class="value" style="color:#4f8ef7;">{float(result.get("auc", 0)):.4f}</div></div>', unsafe_allow_html=True)
                st.markdown("<br>", unsafe_allow_html=True)
                s1, s2 = st.columns(2)
                with s1:
                    st.markdown(f'<div class="metric-card"><div class="label">Train Samples</div><div class="value info">{result.get("trainSamples", 0)}</div></div>', unsafe_allow_html=True)
                with s2:
                    st.markdown(f'<div class="metric-card"><div class="label">Val Samples</div><div class="value info">{result.get("validationSamples", 0)}</div></div>', unsafe_allow_html=True)
                st.rerun()
            elif result.get("message"):
                st.warning(f"⚠️ {result.get('message')}")
            else:
                st.error("Training failed. Check backend connection.")

    st.markdown("---")
    st.markdown("#### Model Version History")
    models = get_models()

    if not models:
        st.info("No models trained yet.")
        return

    df_models = pd.DataFrame(models)

    status_cell_style = """
    function(params) {
        const color = params.value === 'ready' ? '#34d399' : '#fbbf24';
        return { 'color': color, 'fontWeight': '600', 'fontFamily': 'monospace' };
    }
    """
    from st_aggrid import JsCode
    status_js = JsCode(status_cell_style)

    show_cols = [c for c in ["version", "name", "accuracy", "auc", "trainSamples", "validationSamples", "status", "trainedAt"] if c in df_models.columns]
    gb = GridOptionsBuilder.from_dataframe(df_models[show_cols])
    gb.configure_column("version", header_name="Version", width=100, pinned="left")
    gb.configure_column("name", header_name="Model Name", width=180)
    gb.configure_column("accuracy", header_name="Accuracy", width=100)
    gb.configure_column("auc", header_name="AUC", width=90)
    gb.configure_column("trainSamples", header_name="Train Samples", width=120)
    gb.configure_column("validationSamples", header_name="Val Samples", width=110)
    if "status" in show_cols:
        gb.configure_column("status", header_name="Status", width=100, cellStyle=status_js)
    if "trainedAt" in show_cols:
        df_models["trainedAt"] = df_models["trainedAt"].apply(lambda x: str(x)[:19] if x else "")
        gb.configure_column("trainedAt", header_name="Trained At", flex=1)
    gb.configure_default_column(resizable=True, sortable=True)
    gb.configure_grid_options(rowHeight=36, headerHeight=36)

    AgGrid(
        df_models[show_cols],
        gridOptions=gb.build(),
        theme="streamlit",
        height=300,
        fit_columns_on_grid_load=False,
        allow_unsafe_jscode=True,
    )
