import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from streamlit_app.api import get_health, get_analysis, get_segment_stats, get_models, get_pipeline_runs

_BASE_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(13,17,23,0.6)",
    font=dict(color="#e2e8f0", family="sans-serif", size=12),
    margin=dict(l=10, r=10, t=30, b=10),
)
PLOT_LAYOUT = dict(**_BASE_LAYOUT, legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(size=11)))

BUCKET_ORDER = ["0-30", "31-60", "61-90", "91-180", "180+"]
BUCKET_COLORS = ["#34d399", "#4f8ef7", "#fbbf24", "#f97316", "#f87171"]
SEV_COLORS = {"High": "#f87171", "Medium": "#fbbf24", "Low": "#34d399", "Unscored": "#475569"}


def severity_badge(s: str) -> str:
    c = {"High": "badge-red", "Medium": "badge-amber", "Low": "badge-green"}.get(s, "badge-gray")
    return f'<span class="badge {c}">{s}</span>'


def render():
    st.markdown('<div class="page-header"><h1>📊 Dashboard</h1><p>Real-time reconciliation health, risk distribution, and segment thresholds</p></div>', unsafe_allow_html=True)

    health = get_health()
    analysis = get_analysis()
    seg_stats = get_segment_stats()
    models = get_models()
    runs = get_pipeline_runs()

    status = health.get("status", "No Data")
    status_color = "#34d399" if status == "Healthy" else "#fbbf24" if status == "Warning" else "#64748b"

    st.markdown(f"""
    <div style='display:flex; align-items:center; gap:10px; margin-bottom:16px;'>
        <div style='width:10px; height:10px; border-radius:50%; background:{status_color};'></div>
        <span style='font-size:13px; color:{status_color}; font-weight:600;'>{status}</span>
    </div>
    """, unsafe_allow_html=True)

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        st.markdown(f'<div class="metric-card"><div class="label">Total Breaks</div><div class="value info">{health.get("totalBreaks", 0)}</div></div>', unsafe_allow_html=True)
    with c2:
        st.markdown(f'<div class="metric-card"><div class="label">Material (High)</div><div class="value high">{health.get("materialBreaks", 0)}</div></div>', unsafe_allow_html=True)
    with c3:
        st.markdown(f'<div class="metric-card"><div class="label">Warning (Med)</div><div class="value medium">{health.get("warningBreaks", 0)}</div></div>', unsafe_allow_html=True)
    with c4:
        st.markdown(f'<div class="metric-card"><div class="label">Active Breaks</div><div class="value info">{health.get("activeBreaks", 0)}</div></div>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    with st.expander("🔽 Dimension Filters", expanded=False):
        df_all = pd.DataFrame(analysis) if analysis else pd.DataFrame()
        fcol1, fcol2, fcol3, fcol4 = st.columns(4)
        with fcol1:
            rec_opts = ["All"] + sorted(df_all["recName"].dropna().unique().tolist()) if not df_all.empty and "recName" in df_all.columns else ["All"]
            sel_rec = st.selectbox("Rec Name", rec_opts, key="dash_rec")
        with fcol2:
            ent_opts = ["All"] + sorted(df_all["entity"].dropna().unique().tolist()) if not df_all.empty and "entity" in df_all.columns else ["All"]
            sel_ent = st.selectbox("Entity", ent_opts, key="dash_ent")
        with fcol3:
            ac_opts = ["All"] + sorted(df_all["assetClass"].dropna().unique().tolist()) if not df_all.empty and "assetClass" in df_all.columns else ["All"]
            sel_ac = st.selectbox("Asset Class", ac_opts, key="dash_ac")
        with fcol4:
            ag_opts = ["All"] + sorted(df_all["accountGroup"].dropna().unique().tolist()) if not df_all.empty and "accountGroup" in df_all.columns else ["All"]
            sel_ag = st.selectbox("Account Group", ag_opts, key="dash_ag")

        if not df_all.empty:
            if sel_rec != "All":
                df_all = df_all[df_all["recName"] == sel_rec]
            if sel_ent != "All":
                df_all = df_all[df_all["entity"] == sel_ent]
            if sel_ac != "All":
                df_all = df_all[df_all["assetClass"] == sel_ac]
            if sel_ag != "All":
                df_all = df_all[df_all["accountGroup"] == sel_ag]
        analysis_filtered = df_all.to_dict("records") if not df_all.empty else analysis

    analysis_filtered = analysis_filtered if "analysis_filtered" in dir() else analysis

    st.markdown("---")
    col_left, col_right = st.columns(2)

    with col_left:
        st.markdown("**Breaks by Ageing Bucket**")
        bucket_counts = {b: 0 for b in BUCKET_ORDER}
        for b in analysis_filtered:
            bkt = b.get("derivedAgeingBucket") or b.get("ageingBucket") or "0-30"
            if bkt in bucket_counts:
                bucket_counts[bkt] += 1
            else:
                bucket_counts["0-30"] += 1
        fig_age = go.Figure(go.Bar(
            x=BUCKET_ORDER,
            y=[bucket_counts[b] for b in BUCKET_ORDER],
            marker_color=BUCKET_COLORS,
            text=[bucket_counts[b] for b in BUCKET_ORDER],
            textposition="outside",
            hovertemplate="%{x}: %{y} breaks<extra></extra>",
        ))
        fig_age.update_layout(**PLOT_LAYOUT, height=280,
                              xaxis=dict(showgrid=False, color="#64748b"),
                              yaxis=dict(showgrid=True, gridcolor="#1e293b", color="#64748b"))
        st.plotly_chart(fig_age, use_container_width=True)

    with col_right:
        st.markdown("**Severity Distribution**")
        sev_counts = {"High": 0, "Medium": 0, "Low": 0, "Unscored": 0}
        for b in analysis_filtered:
            sev = (b.get("prediction") or {}).get("severity")
            if sev in sev_counts:
                sev_counts[sev] += 1
            else:
                sev_counts["Unscored"] += 1
        labels = [k for k, v in sev_counts.items() if v > 0]
        values = [v for v in sev_counts.values() if v > 0]
        colors = [SEV_COLORS[k] for k in labels]
        fig_sev = go.Figure(go.Pie(
            labels=labels,
            values=values,
            hole=0.6,
            marker=dict(colors=colors, line=dict(color="#0f1117", width=2)),
            hovertemplate="%{label}: %{value} (%{percent})<extra></extra>",
        ))
        fig_sev.update_layout(**_BASE_LAYOUT, height=280, showlegend=True,
                               legend=dict(bgcolor="rgba(0,0,0,0)", orientation="v", x=1.0, y=0.5))
        st.plotly_chart(fig_sev, use_container_width=True)

    st.markdown("---")
    st.markdown("**Segment Threshold Comparison**")
    if seg_stats:
        seg_df = pd.DataFrame(seg_stats).head(8)
        seg_df["label"] = seg_df["segmentKey"].apply(lambda x: x[:20] if isinstance(x, str) else x)
        fig_thresh = go.Figure()
        fig_thresh.add_trace(go.Bar(name="Material Threshold", x=seg_df["label"],
                                    y=pd.to_numeric(seg_df.get("materialThreshold", seg_df.get("material_threshold", [0]*len(seg_df))), errors="coerce"),
                                    marker_color="#f87171", opacity=0.85))
        fig_thresh.add_trace(go.Bar(name="Early Warning", x=seg_df["label"],
                                    y=pd.to_numeric(seg_df.get("earlyWarningThreshold", seg_df.get("early_warning_threshold", [0]*len(seg_df))), errors="coerce"),
                                    marker_color="#fbbf24", opacity=0.85))
        fig_thresh.add_trace(go.Bar(name="Median", x=seg_df["label"],
                                    y=pd.to_numeric(seg_df.get("medianAmount", seg_df.get("median_amount", [0]*len(seg_df))), errors="coerce"),
                                    marker_color="#4f8ef7", opacity=0.85))
        fig_thresh.update_layout(**PLOT_LAYOUT, barmode="group", height=320,
                                  xaxis=dict(showgrid=False, color="#64748b", tickangle=-30, tickfont=dict(size=10)),
                                  yaxis=dict(showgrid=True, gridcolor="#1e293b", color="#64748b", tickformat=",.0f"))
        st.plotly_chart(fig_thresh, use_container_width=True)
    else:
        st.info("No segment data yet. Upload breaks to populate thresholds.")

    st.markdown("---")
    c_seg, c_ml, c_pipe = st.columns(3)

    with c_seg:
        st.markdown("**Segment Health**")
        stable = health.get("segmentsStable", 0)
        deteri = health.get("segmentsDeteriorating", 0)
        st.markdown(f"""
        <div class="info-panel">
            <div class="info-row"><span class="info-label">Stable</span><span class="info-value" style="color:#34d399">{stable}</span></div>
            <div class="info-row"><span class="info-label">Deteriorating</span><span class="info-value" style="color:#fbbf24">{deteri}</span></div>
            <div class="info-row"><span class="info-label">Total Segments</span><span class="info-value" style="color:#4f8ef7">{len(seg_stats)}</span></div>
        </div>
        """, unsafe_allow_html=True)

    with c_ml:
        st.markdown("**ML Model**")
        latest_model = models[0] if models else None
        if latest_model:
            st.markdown(f"""
            <div class="info-panel">
                <div class="info-row"><span class="info-label">Version</span><span class="info-value">{latest_model.get("version","—")}</span></div>
                <div class="info-row"><span class="info-label">AUC</span><span class="info-value" style="color:#4f8ef7">{latest_model.get("auc","—")}</span></div>
                <div class="info-row"><span class="info-label">Accuracy</span><span class="info-value" style="color:#34d399">{latest_model.get("accuracy","—")}</span></div>
                <div class="info-row"><span class="info-label">Status</span><span class="info-value">{latest_model.get("status","—")}</span></div>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown('<div class="info-panel"><div class="info-row"><span class="info-label">No model trained yet</span></div></div>', unsafe_allow_html=True)

    with c_pipe:
        st.markdown("**Latest Pipeline**")
        latest_run = runs[0] if runs else None
        if latest_run:
            st.markdown(f"""
            <div class="info-panel">
                <div class="info-row"><span class="info-label">Status</span><span class="info-value" style="color:#34d399">{latest_run.get("status","—")}</span></div>
                <div class="info-row"><span class="info-label">Steps Done</span><span class="info-value">{latest_run.get("currentStep","—")} / {latest_run.get("totalSteps","—")}</span></div>
                <div class="info-row"><span class="info-label">Batch ID</span><span class="info-value" style="font-size:10px; font-family:monospace">{str(latest_run.get("batchId","—"))[:16]}…</span></div>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown('<div class="info-panel"><div class="info-row"><span class="info-label">No pipeline runs yet</span></div></div>', unsafe_allow_html=True)
