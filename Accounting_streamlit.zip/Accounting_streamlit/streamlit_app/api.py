import requests
import streamlit as st

BASE_URL = "http://localhost:8000"


def _get(path: str) -> dict | list:
    try:
        r = requests.get(f"{BASE_URL}{path}", timeout=30)
        r.raise_for_status()
        return r.json()
    except requests.exceptions.ConnectionError:
        st.error("Cannot reach the API backend. Make sure FastAPI is running on port 8000.")
        return []
    except Exception as e:
        st.error(f"API error on {path}: {e}")
        return []


def _post(path: str, data: dict = None) -> dict | list:
    try:
        r = requests.post(f"{BASE_URL}{path}", json=data or {}, timeout=120)
        r.raise_for_status()
        return r.json()
    except requests.exceptions.ConnectionError:
        st.error("Cannot reach the API backend. Make sure FastAPI is running on port 8000.")
        return {}
    except Exception as e:
        st.error(f"API error on {path}: {e}")
        return {}


def get_health() -> dict:
    return _get("/api/reconciliation/health") or {}


def get_analysis() -> list:
    return _get("/api/breaks/analysis") or []


def get_clean_breaks() -> list:
    return _get("/api/breaks/clean") or []


def get_segment_stats() -> list:
    return _get("/api/segments/stats") or []


def get_segment_trends() -> list:
    return _get("/api/segments/trends") or []


def get_models() -> list:
    return _get("/api/models") or []


def get_pipeline_runs() -> list:
    return _get("/api/pipeline/runs") or []


def get_audit_log() -> list:
    return _get("/api/audit-log") or []


def upload_breaks(rows: list) -> dict:
    return _post("/api/upload/breaks", {"rows": rows})


def upload_training_data(rows: list) -> dict:
    return _post("/api/upload/training-data", {"rows": rows})


def train_model() -> dict:
    return _post("/api/models/train")
