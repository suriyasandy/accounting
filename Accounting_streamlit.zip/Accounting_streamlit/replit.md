# RICP — Reconciliation Risk State Engine

## Overview
Full end-to-end reconciliation risk platform for financial/banking operations. Implements deterministic data quality checks, robust statistical threshold computation, EWMA trend/drift detection, ML feature engineering, gradient-boosted decision tree model training/inference, and intelligent historical linkage with feature importance.

## Architecture
- **Frontend**: Streamlit (port 5000) — AG Grid tables, Plotly charts, dark fintech theme
- **Backend**: FastAPI (Python) on port 8000 — 13 routes, 8-step pipeline, in-memory storage
- **Storage**: In-memory Python data store — thread-safe with auto-increment IDs
- **ML**: Python gradient-boosted decision stumps (numpy-based)
- **Model Weights**: JSON files saved to `data/models/` at runtime
- **Communication**: Streamlit calls FastAPI directly via `requests` (no proxy)
- **Startup**: `bash start.sh` — launches uvicorn (FastAPI, port 8000) then Streamlit (port 5000)

## How to Run
```bash
# Install Python dependencies
pip install fastapi uvicorn numpy streamlit streamlit-aggrid plotly pandas requests

# Run both servers
bash start.sh

# Open in browser
# http://localhost:5000
```

## Startup Script
`start.sh` launches both processes:
1. `python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000` (FastAPI)
2. `PYTHONPATH=/home/runner/workspace streamlit run streamlit_app/app.py` (Streamlit on port 5000)

## Streamlit App Structure
```
streamlit_app/
├── app.py              # Entry point, sidebar nav, CSS injection
├── api.py              # Requests wrapper for all FastAPI routes
└── pages/
    ├── dashboard.py    # KPI cards, ageing bar, severity donut, threshold comparison
    ├── upload.py       # CSV uploader, pipeline progress (8 steps)
    ├── analysis.py     # AG Grid table + row detail: features, importance, historical linkage
    ├── segments.py     # Threshold cards, EWMA trend charts
    ├── training.py     # Upload training data, train model, version history
    └── audit.py        # AG Grid audit log with color-coded actions
.streamlit/
└── config.toml         # Dark theme, port 5000, headless
```

## In-Memory Tables (backend/storage.py)
1. `raw_breaks` — untouched ingested break file data
2. `clean_breaks` — validated/corrected breaks with derived ageing
3. `segment_stats` — per-segment threshold computations (Median + MAD)
4. `trend_metrics` — monthly EWMA series, drift values per segment
5. `ml_features` — 6 engineered features per break
6. `ml_predictions` — model inference results with severity scoring + feature importance
7. `models` — ML model registry with weights stored as JSON
8. `pipeline_runs` — batch execution tracking (8-step pipeline)
9. `recon_health` — summary health snapshots
10. `audit_log` — governance/compliance trail

## Python Backend Files
- `backend/main.py` — FastAPI app entry with CORS
- `backend/storage.py` — Thread-safe in-memory Table class with CRUD helpers
- `backend/routes.py` — All API route handlers (13 routes)
- `backend/engines/data_quality.py` — ageing recalculation, correction flagging
- `backend/engines/threshold.py` — Median + MAD robust statistics
- `backend/engines/trend.py` — EWMA (α=0.3) drift detection
- `backend/engines/features.py` — 6 ML features per break
- `backend/engines/ml_pipeline.py` — gradient-boosted trees, training, inference, historical matching, feature importance
- `backend/engines/pipeline.py` — 8-step DAG orchestrator

## API Routes (all return 200)
- `POST /api/upload/breaks` — upload break CSV, triggers full 8-step pipeline
- `POST /api/upload/training-data` — upload historical data for ML training
- `GET /api/pipeline/{batchId}/status` — pipeline run status
- `GET /api/pipeline/runs` — list recent pipeline runs
- `GET /api/breaks/clean` — clean breaks (limit 500)
- `GET /api/breaks/analysis` — clean breaks with features + predictions + historical matches (top-5)
- `POST /api/models/train` — train new ML model
- `GET /api/models` — model registry
- `GET /api/segments/stats` — segment threshold computations
- `GET /api/segments/trends` — EWMA trend data
- `GET /api/reconciliation/health` — latest health snapshot
- `GET /api/audit-log` — governance trail

## Streamlit Pages
- **Dashboard**: Health status, 4 KPI cards, ageing bucket bar chart, severity donut, segment threshold comparison bar chart, ML model card, pipeline card, dimension filters
- **Upload**: CSV drag-and-drop, 5-row preview in AG Grid, 8-step pipeline progress animation
- **Analysis**: AG Grid with 100-row pagination, risk/ageing/amount sorting, filters, row click → detail panel with 6-feature bars, prediction feature importance horizontal bar, up to 5 historical match cards with similarity drivers
- **Segments**: KPI cards, threshold cards per segment (Median/MAD/Material/EarlyWarning/Sigma), EWMA area + dashed line chart, segment dropdown
- **ML Training**: Upload historical CSV, Train Model button, AUC/Accuracy result cards, model version history AG Grid
- **Audit Log**: AG Grid with color-coded action badges (Timestamp, Action, Entity, Details)

## Intelligent Historical Linkage
- `find_historical_matches()`: Euclidean distance on min-max normalized 6-feature vectors within same segment, returns top-5 with similarity %, full break metadata (jiraId, tradeId, recName, entity, assetClass, accountGroup, startDate, ageingBucket), and per-feature contribution to similarity
- Each historical match includes `featureContributions` — which features drove the similarity

## ML Feature Importance
- `compute_feature_importance()`: tracks per-feature contribution to prediction score
- Displayed as horizontal bars in analysis row detail, sorted by importance

## Key Formulas
- **Threshold**: material = median + 4 × robust_sigma, early_warning = median + 2 × robust_sigma
- **Robust Sigma**: 1.4826 × MAD (Median Absolute Deviation)
- **EWMA**: α=0.3; segment deteriorates when drift > 1.5 × std deviation
- **Risk Score**: probability × 100 × severity_weight (0.6×prob + 0.4×amount_factor)
- **Similarity**: (1 - euclidean_dist / sqrt(6)) × 100, on min-max normalized 6-feature vectors
- **Feature Contribution**: per-dimension squared difference as proportion of total squared distance
