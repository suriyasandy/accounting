from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from backend.storage import storage
from backend.engines.pipeline import run_full_pipeline, get_pipeline_status, get_latest_pipeline_run
from backend.engines.ml_pipeline import train_model, get_analysis_with_matches

router = APIRouter()


def _normalize_row(r: dict) -> dict:
    return {
        "batchId": "",
        "tradeId": r.get("tradeId") or r.get("TradeId") or r.get("trade_id") or "",
        "recName": r.get("recName") or r.get("RecName") or r.get("rec_name") or "",
        "entity": r.get("entity") or r.get("Entity") or "",
        "assetClass": r.get("assetClass") or r.get("Asset_Class") or r.get("asset_class") or "",
        "accountGroup": r.get("accountGroup") or r.get("Account_Group") or r.get("account_group") or "",
        "startDate": r.get("startDate") or r.get("Start_Date") or r.get("start_date") or "",
        "maturityDate": r.get("maturityDate") or r.get("Maturity_Date") or r.get("maturity_date") or None,
        "amountGbp": str(r.get("amountGbp") or r.get("Amount_GBP") or r.get("amount_gbp") or "0"),
        "amountCcy": str(r.get("amountCcy") or r.get("Amount_CCY") or r.get("amount_ccy") or "0"),
        "ageingDays": r.get("ageingDays") or r.get("Ageing_Days") or r.get("ageing_days") or None,
        "ageingBucket": r.get("ageingBucket") or r.get("Ageing_Bucket") or r.get("ageing_bucket") or None,
        "jiraId": r.get("jiraId") or r.get("Jira_Id") or r.get("jira_id") or None,
    }


@router.post("/api/upload/breaks")
async def upload_breaks(request: Request):
    body = await request.json()
    rows = body.get("rows", [])
    if not rows:
        return JSONResponse({"message": "No rows provided"}, status_code=400)

    normalized = [_normalize_row(r) for r in rows]
    result = run_full_pipeline(normalized)
    return {"batchId": result["batchId"], "status": result["status"]}


@router.post("/api/upload/training-data")
async def upload_training_data(request: Request):
    body = await request.json()
    rows = body.get("rows", [])
    if not rows:
        return JSONResponse({"message": "No rows provided"}, status_code=400)

    normalized = [_normalize_row(r) for r in rows]
    result = run_full_pipeline(normalized)
    return {"batchId": result["batchId"], "status": result["status"]}


@router.get("/api/pipeline/{batch_id}/status")
async def pipeline_status(batch_id: str):
    status = get_pipeline_status(batch_id)
    if not status:
        return JSONResponse({"message": "Pipeline run not found"}, status_code=404)
    return status


@router.get("/api/pipeline/latest")
async def pipeline_latest():
    run = get_latest_pipeline_run()
    if not run:
        return {"status": "none"}
    return run


@router.get("/api/pipeline/runs")
async def pipeline_runs():
    runs = storage.pipeline_runs.get_all(limit=20, order_desc="startedAt")
    return runs


@router.get("/api/breaks/clean")
async def clean_breaks():
    breaks = storage.clean_breaks.get_all(limit=500, order_desc="createdAt")
    return breaks


@router.get("/api/breaks/analysis")
async def breaks_analysis():
    analysis = get_analysis_with_matches()
    return analysis


@router.get("/api/models")
async def list_models():
    all_models = storage.models.get_all(order_desc="createdAt")
    safe_models = []
    for m in all_models:
        entry = {k: v for k, v in m.items() if k != "weights"}
        safe_models.append(entry)
    return safe_models


@router.post("/api/models/train")
async def train_model_route():
    try:
        result = train_model()
        return result
    except ValueError as e:
        return JSONResponse({"message": str(e)}, status_code=400)


@router.get("/api/segments/stats")
async def segment_stats():
    stats = storage.segment_stats.get_all()
    latest: dict[str, dict] = {}
    for s in stats:
        key = s["segmentKey"]
        if key not in latest or s.get("version", 0) > latest[key].get("version", 0):
            latest[key] = s
    return list(latest.values())


@router.get("/api/segments/trends")
async def segment_trends():
    trends = storage.trend_metrics.get_all()
    return trends


@router.get("/api/reconciliation/health")
async def recon_health():
    all_health = storage.recon_health.get_all(order_desc="createdAt")
    if all_health:
        return all_health[0]
    return {
        "totalBreaks": 0,
        "activeBreaks": 0,
        "materialBreaks": 0,
        "warningBreaks": 0,
        "segmentsStable": 0,
        "segmentsDeteriorating": 0,
        "modelAccuracy": None,
        "status": "No Data",
    }


@router.get("/api/audit-log")
async def audit_log():
    logs = storage.audit_log.get_all(limit=100, order_desc="createdAt")
    return logs
