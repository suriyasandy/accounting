import threading
from datetime import datetime, timezone
from typing import Any, Optional
from copy import deepcopy


class Table:
    def __init__(self):
        self._data: list[dict] = []
        self._next_id: int = 1
        self._lock = threading.Lock()

    def insert(self, record: dict) -> dict:
        with self._lock:
            rec = deepcopy(record)
            rec["id"] = self._next_id
            self._next_id += 1
            if "createdAt" not in rec:
                rec["createdAt"] = datetime.now(timezone.utc).isoformat()
            self._data.append(rec)
            return deepcopy(rec)

    def insert_many(self, records: list[dict]) -> list[dict]:
        results = []
        for r in records:
            results.append(self.insert(r))
        return results

    def get_all(self, limit: Optional[int] = None, order_desc: Optional[str] = None) -> list[dict]:
        with self._lock:
            data = deepcopy(self._data)
        if order_desc:
            data.sort(key=lambda x: x.get(order_desc, ""), reverse=True)
        if limit:
            data = data[:limit]
        return data

    def get_by_id(self, record_id: int) -> Optional[dict]:
        with self._lock:
            for r in self._data:
                if r["id"] == record_id:
                    return deepcopy(r)
        return None

    def get_by_field(self, field: str, value: Any) -> list[dict]:
        with self._lock:
            return deepcopy([r for r in self._data if r.get(field) == value])

    def update_by_field(self, field: str, value: Any, updates: dict) -> int:
        count = 0
        with self._lock:
            for r in self._data:
                if r.get(field) == value:
                    r.update(updates)
                    count += 1
        return count

    def update_by_id(self, record_id: int, updates: dict) -> bool:
        with self._lock:
            for r in self._data:
                if r["id"] == record_id:
                    r.update(updates)
                    return True
        return False

    def count(self) -> int:
        with self._lock:
            return len(self._data)

    def clear(self):
        with self._lock:
            self._data.clear()
            self._next_id = 1


class Storage:
    def __init__(self):
        self.raw_breaks = Table()
        self.clean_breaks = Table()
        self.segment_stats = Table()
        self.trend_metrics = Table()
        self.ml_features = Table()
        self.ml_predictions = Table()
        self.models = Table()
        self.pipeline_runs = Table()
        self.recon_health = Table()
        self.audit_log = Table()


storage = Storage()
