import math
from backend.storage import storage


def std_dev(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    mean = sum(values) / len(values)
    sq_diffs = [(v - mean) ** 2 for v in values]
    return math.sqrt(sum(sq_diffs) / (len(values) - 1))


def run_trend_engine() -> dict:
    all_clean = storage.clean_breaks.get_all()

    segment_monthly: dict[str, dict[str, dict]] = {}

    for row in all_clean:
        key = row["segmentKey"]
        start_date = row["startDate"]
        month = start_date[:7] if isinstance(start_date, str) else start_date.strftime("%Y-%m")

        if key not in segment_monthly:
            segment_monthly[key] = {}
        if month not in segment_monthly[key]:
            segment_monthly[key][month] = {"sum": 0.0, "count": 0}

        segment_monthly[key][month]["sum"] += float(row["amountGbp"])
        segment_monthly[key][month]["count"] += 1

    alpha = 0.3
    deteriorating_segments = []

    for segment_key, month_map in segment_monthly.items():
        sorted_months = sorted(month_map.items(), key=lambda x: x[0])
        monthly_sums = [v["sum"] for _, v in sorted_months]

        ewma = monthly_sums[0] if monthly_sums else 0.0
        all_drifts = []

        for i, (month, data) in enumerate(sorted_months):
            if i > 0:
                ewma = alpha * data["sum"] + (1 - alpha) * ewma
            drift = data["sum"] - ewma
            all_drifts.append(drift)

            storage.trend_metrics.insert({
                "segmentKey": segment_key,
                "month": month,
                "monthlySum": f"{data['sum']:.2f}",
                "monthlyCount": data["count"],
                "ewmaValue": f"{ewma:.2f}",
                "drift": f"{drift:.2f}",
                "stdDev": f"{std_dev(monthly_sums):.2f}",
                "isDeteriorating": False,
            })

        latest_drift = all_drifts[-1] if all_drifts else 0.0
        series_std = std_dev(monthly_sums)

        if series_std > 0 and latest_drift > 1.5 * series_std:
            deteriorating_segments.append(segment_key)
            all_trends = storage.trend_metrics.get_by_field("segmentKey", segment_key)
            if all_trends:
                latest = max(all_trends, key=lambda t: t["month"])
                storage.trend_metrics.update_by_id(latest["id"], {"isDeteriorating": True})

            storage.segment_stats.update_by_field("segmentKey", segment_key, {"status": "deteriorating"})

    storage.audit_log.insert({
        "action": "TREND_ANALYSIS_COMPLETE",
        "entity": "trend_metrics",
        "details": {"segmentsAnalyzed": len(segment_monthly), "deteriorating": deteriorating_segments},
    })

    return {
        "segmentsAnalyzed": len(segment_monthly),
        "deterioratingSegments": deteriorating_segments,
    }
