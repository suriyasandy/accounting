import base64
import math
from datetime import datetime, timezone
from backend.storage import storage


def bucketize(days: int) -> str:
    if days <= 30:
        return "0-30"
    if days <= 60:
        return "31-60"
    if days <= 90:
        return "61-90"
    if days <= 180:
        return "91-180"
    return "180+"


def generate_segment_key(rec_name: str, entity: str, asset_class: str, account_group: str) -> str:
    raw = f"{rec_name}|{entity}|{asset_class}|{account_group}"
    return base64.b64encode(raw.encode()).decode()


def run_data_quality_engine(batch_id: str, run_date: datetime = None) -> dict:
    if run_date is None:
        run_date = datetime.now(timezone.utc)

    rows = storage.raw_breaks.get_by_field("batchId", batch_id)
    corrections = 0
    errors = []
    clean_rows = []

    for row in rows:
        start_date = datetime.fromisoformat(row["startDate"].replace("Z", "+00:00")) if isinstance(row["startDate"], str) else row["startDate"]
        if start_date.tzinfo is None:
            start_date = start_date.replace(tzinfo=timezone.utc)
        if run_date.tzinfo is None:
            run_date = run_date.replace(tzinfo=timezone.utc)

        computed_age = (run_date - start_date).days

        if computed_age < 0:
            errors.append(f"Future-dated break detected: {row['tradeId']} (start_date: {row['startDate']})")
            storage.audit_log.insert({
                "action": "DATA_QUALITY_ERROR",
                "entity": "raw_breaks",
                "entityId": str(row["id"]),
                "details": {"tradeId": row["tradeId"], "error": "Future-dated break", "startDate": row["startDate"]},
            })
            continue

        derived_bucket = bucketize(computed_age)
        original_bucket = row.get("ageingBucket")
        needs_correction = original_bucket is not None and derived_bucket != original_bucket

        if needs_correction:
            corrections += 1
            storage.audit_log.insert({
                "action": "AGEING_CORRECTION",
                "entity": "clean_breaks",
                "entityId": row["tradeId"],
                "details": {
                    "tradeId": row["tradeId"],
                    "originalBucket": original_bucket,
                    "derivedBucket": derived_bucket,
                    "originalDays": row.get("ageingDays"),
                    "computedDays": computed_age,
                },
            })

        segment_key = generate_segment_key(
            row["recName"], row["entity"], row["assetClass"], row["accountGroup"]
        )

        clean_rows.append({
            "rawBreakId": row["id"],
            "batchId": row["batchId"],
            "tradeId": row["tradeId"],
            "recName": row["recName"],
            "entity": row["entity"],
            "assetClass": row["assetClass"],
            "accountGroup": row["accountGroup"],
            "startDate": row["startDate"],
            "maturityDate": row.get("maturityDate"),
            "amountGbp": row["amountGbp"],
            "amountCcy": row.get("amountCcy"),
            "computedAgeingDays": computed_age,
            "derivedAgeingBucket": derived_bucket,
            "originalAgeingDays": row.get("ageingDays", computed_age),
            "originalAgeingBucket": original_bucket or derived_bucket,
            "correctionFlag": needs_correction,
            "correctionTimestamp": datetime.now(timezone.utc).isoformat() if needs_correction else None,
            "segmentKey": segment_key,
            "jiraId": row.get("jiraId"),
        })

    if clean_rows:
        storage.clean_breaks.insert_many(clean_rows)

    storage.audit_log.insert({
        "action": "DATA_QUALITY_COMPLETE",
        "entity": "pipeline",
        "entityId": batch_id,
        "details": {"totalProcessed": len(clean_rows), "corrections": corrections, "errors": len(errors)},
    })

    return {"totalProcessed": len(clean_rows), "corrections": corrections, "errors": errors}
