import uuid
from datetime import datetime, timezone
from backend.storage import storage
from backend.engines.data_quality import run_data_quality_engine
from backend.engines.threshold import run_threshold_engine
from backend.engines.trend import run_trend_engine
from backend.engines.features import run_feature_engineering
from backend.engines.ml_pipeline import run_inference

STEP_NAMES = [
    "Ingest File",
    "Validate Schema",
    "Recompute Ageing",
    "Recompute Thresholds",
    "Run Trend Analysis",
    "Generate Features",
    "ML Scoring",
    "Publish Health",
]


def update_pipeline_run(batch_id: str, step: int, status: str, steps: list[dict]):
    updates = {
        "currentStep": step,
        "status": status,
        "stepDetails": steps,
    }
    if status in ("complete", "failed"):
        updates["completedAt"] = datetime.now(timezone.utc).isoformat()
    storage.pipeline_runs.update_by_field("batchId", batch_id, updates)


def run_full_pipeline(raw_rows: list[dict]) -> dict:
    batch_id = str(uuid.uuid4())
    steps = [{"step": i + 1, "name": name, "status": "pending"} for i, name in enumerate(STEP_NAMES)]

    storage.pipeline_runs.insert({
        "batchId": batch_id,
        "status": "running",
        "currentStep": 0,
        "totalSteps": 8,
        "stepDetails": steps,
        "rawCount": len(raw_rows),
        "cleanCount": 0,
        "correctionCount": 0,
        "startedAt": datetime.now(timezone.utc).isoformat(),
    })

    try:
        steps[0]["status"] = "running"
        update_pipeline_run(batch_id, 1, "running", steps)

        rows_with_batch = []
        for r in raw_rows:
            row = dict(r)
            row["batchId"] = batch_id
            rows_with_batch.append(row)
        storage.raw_breaks.insert_many(rows_with_batch)
        steps[0]["status"] = "complete"
        steps[0]["details"] = {"count": len(raw_rows)}

        steps[1]["status"] = "running"
        update_pipeline_run(batch_id, 2, "running", steps)

        validation_errors = []
        for row in raw_rows:
            if not row.get("tradeId") or not row.get("recName") or not row.get("entity") or not row.get("assetClass") or not row.get("accountGroup"):
                validation_errors.append(f"Missing required field in trade {row.get('tradeId', 'unknown')}")
            if not row.get("amountGbp") or float(row.get("amountGbp", 0)) <= 0:
                validation_errors.append(f"Invalid amountGbp for trade {row.get('tradeId')}")
        steps[1]["status"] = "complete"
        steps[1]["details"] = {"validationErrors": len(validation_errors), "errors": validation_errors[:5]}

        steps[2]["status"] = "running"
        update_pipeline_run(batch_id, 3, "running", steps)

        dq_result = run_data_quality_engine(batch_id)
        steps[2]["status"] = "complete"
        steps[2]["details"] = dq_result

        steps[3]["status"] = "running"
        update_pipeline_run(batch_id, 4, "running", steps)

        thresh_result = run_threshold_engine(batch_id)
        steps[3]["status"] = "complete"
        steps[3]["details"] = thresh_result

        steps[4]["status"] = "running"
        update_pipeline_run(batch_id, 5, "running", steps)

        trend_result = run_trend_engine()
        steps[4]["status"] = "complete"
        steps[4]["details"] = trend_result

        steps[5]["status"] = "running"
        update_pipeline_run(batch_id, 6, "running", steps)

        feature_result = run_feature_engineering(batch_id)
        steps[5]["status"] = "complete"
        steps[5]["details"] = feature_result

        steps[6]["status"] = "running"
        update_pipeline_run(batch_id, 7, "running", steps)

        ready_models = [m for m in storage.models.get_all() if m.get("status") == "ready"]
        if ready_models:
            inference_result = run_inference()
            steps[6]["status"] = "complete"
            steps[6]["details"] = inference_result
        else:
            steps[6]["status"] = "skipped"
            steps[6]["details"] = {"reason": "No trained model available. Upload historical data and train first."}

        steps[7]["status"] = "running"
        update_pipeline_run(batch_id, 8, "running", steps)

        all_clean = storage.clean_breaks.get_all()
        all_predictions = storage.ml_predictions.get_all()
        all_seg_stats = storage.segment_stats.get_all()

        material_breaks = sum(1 for p in all_predictions if p.get("severity") == "High")
        warning_breaks = sum(1 for p in all_predictions if p.get("severity") == "Medium")
        stable_segments = sum(1 for s in all_seg_stats if s.get("status") == "stable")
        deteriorating_segments = sum(1 for s in all_seg_stats if s.get("status") == "deteriorating")

        latest_model = ready_models[-1] if ready_models else None

        storage.recon_health.insert({
            "totalBreaks": len(all_clean),
            "activeBreaks": sum(1 for b in all_clean if b["computedAgeingDays"] > 0),
            "materialBreaks": material_breaks,
            "warningBreaks": warning_breaks,
            "segmentsStable": stable_segments,
            "segmentsDeteriorating": deteriorating_segments,
            "modelAccuracy": latest_model.get("accuracy") if latest_model else None,
            "status": "Warning" if deteriorating_segments > 0 else "Healthy",
        })

        steps[7]["status"] = "complete"
        steps[7]["details"] = {
            "totalBreaks": len(all_clean),
            "materialBreaks": material_breaks,
            "warningBreaks": warning_breaks,
            "stableSegments": stable_segments,
            "deterioratingSegments": deteriorating_segments,
        }

        update_pipeline_run(batch_id, 8, "complete", steps)

        storage.pipeline_runs.update_by_field("batchId", batch_id, {
            "cleanCount": dq_result["totalProcessed"],
            "correctionCount": dq_result["corrections"],
        })

        storage.audit_log.insert({
            "action": "PIPELINE_COMPLETE",
            "entity": "pipeline_runs",
            "entityId": batch_id,
            "details": {"steps": [{"name": s["name"], "status": s["status"]} for s in steps]},
        })

        return {"batchId": batch_id, "status": "complete", "currentStep": 8, "totalSteps": 8, "steps": steps}

    except Exception as e:
        failed_step = -1
        for i, s in enumerate(steps):
            if s["status"] == "running":
                failed_step = i
                break

        if failed_step >= 0:
            steps[failed_step]["status"] = "failed"
            steps[failed_step]["details"] = {"error": str(e)}

        update_pipeline_run(batch_id, failed_step + 1, "failed", steps)

        storage.audit_log.insert({
            "action": "PIPELINE_FAILED",
            "entity": "pipeline_runs",
            "entityId": batch_id,
            "details": {"error": str(e), "failedStep": failed_step + 1},
        })

        return {"batchId": batch_id, "status": "failed", "currentStep": failed_step + 1, "totalSteps": 8, "steps": steps}


def get_pipeline_status(batch_id: str) -> dict | None:
    runs = storage.pipeline_runs.get_by_field("batchId", batch_id)
    if not runs:
        return None
    run = runs[0]
    return {
        "batchId": run["batchId"],
        "status": run["status"],
        "currentStep": run.get("currentStep", 0),
        "totalSteps": run.get("totalSteps", 8),
        "steps": run.get("stepDetails", []),
    }


def get_latest_pipeline_run() -> dict | None:
    all_runs = storage.pipeline_runs.get_all(order_desc="startedAt")
    return all_runs[0] if all_runs else None
