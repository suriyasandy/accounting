from backend.storage import storage


def median(values: list[float]) -> float:
    if not values:
        return 0.0
    sorted_vals = sorted(values)
    mid = len(sorted_vals) // 2
    if len(sorted_vals) % 2 != 0:
        return sorted_vals[mid]
    return (sorted_vals[mid - 1] + sorted_vals[mid]) / 2


def mad(values: list[float], med: float) -> float:
    deviations = [abs(v - med) for v in values]
    return median(deviations)


def run_threshold_engine(batch_id: str = None) -> dict:
    all_clean = storage.clean_breaks.get_all()

    segment_map: dict[str, dict] = {}
    for row in all_clean:
        key = row["segmentKey"]
        if key not in segment_map:
            segment_map[key] = {
                "amounts": [],
                "recName": row["recName"],
                "entity": row["entity"],
                "assetClass": row["assetClass"],
                "accountGroup": row["accountGroup"],
            }
        segment_map[key]["amounts"].append(float(row["amountGbp"]))

    existing_stats = storage.segment_stats.get_all()
    version_map: dict[str, int] = {}
    for s in existing_stats:
        key = s["segmentKey"]
        ver = s.get("version", 0)
        if key not in version_map or ver > version_map[key]:
            version_map[key] = ver

    details = []

    for segment_key, data in segment_map.items():
        values = data["amounts"]
        med = median(values)
        mad_val = mad(values, med)
        robust_sigma = 1.4826 * mad_val
        material_threshold = med + 4 * robust_sigma
        early_warning = med + 2 * robust_sigma
        next_version = (version_map.get(segment_key, 0)) + 1

        storage.segment_stats.insert({
            "segmentKey": segment_key,
            "recName": data["recName"],
            "entity": data["entity"],
            "assetClass": data["assetClass"],
            "accountGroup": data["accountGroup"],
            "breakCount": len(values),
            "medianAmountGbp": f"{med:.2f}",
            "madValue": f"{mad_val:.2f}",
            "robustSigma": f"{robust_sigma:.2f}",
            "materialThreshold": f"{material_threshold:.2f}",
            "earlyWarning": f"{early_warning:.2f}",
            "version": next_version,
            "status": "stable",
            "computedAt": None,
        })

        details.append({
            "segmentKey": segment_key,
            "breakCount": len(values),
            "medianAmountGbp": med,
            "materialThreshold": material_threshold,
            "earlyWarning": early_warning,
        })

    storage.audit_log.insert({
        "action": "THRESHOLD_COMPUTED",
        "entity": "segment_stats",
        "details": {"segmentsComputed": len(details), "batchId": batch_id},
    })

    return {"segmentsComputed": len(details), "details": details}
