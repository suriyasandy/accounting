import math
from datetime import datetime, timezone, timedelta
from backend.storage import storage


def std_dev(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    mean = sum(values) / len(values)
    sq_diffs = [(v - mean) ** 2 for v in values]
    return math.sqrt(sum(sq_diffs) / (len(values) - 1))


def run_feature_engineering(batch_id: str = None) -> dict:
    all_clean = storage.clean_breaks.get_all()

    all_stats = storage.segment_stats.get_all()
    latest_thresholds: dict[str, float] = {}
    for stat in all_stats:
        key = stat["segmentKey"]
        ver = stat.get("version", 0)
        existing_ver = latest_thresholds.get(key + "_ver", -1)
        if ver > existing_ver:
            latest_thresholds[key] = float(stat.get("materialThreshold", 1) or 1)
            latest_thresholds[key + "_ver"] = ver

    segment_breaks: dict[str, list[dict]] = {}
    trade_id_count: dict[str, int] = {}

    for row in all_clean:
        seg = row["segmentKey"]
        if seg not in segment_breaks:
            segment_breaks[seg] = []
        segment_breaks[seg].append(row)
        tid = row["tradeId"]
        trade_id_count[tid] = trade_id_count.get(tid, 0) + 1

    features_to_insert = []
    now = datetime.now(timezone.utc)
    thirty_days_ago = now - timedelta(days=30)

    for row in all_clean:
        seg_breaks = segment_breaks.get(row["segmentKey"], [])

        break_frequency_30d = 0
        for b in seg_breaks:
            sd = b["startDate"]
            if isinstance(sd, str):
                try:
                    d = datetime.fromisoformat(sd.replace("Z", "+00:00"))
                except ValueError:
                    d = datetime.strptime(sd[:10], "%Y-%m-%d").replace(tzinfo=timezone.utc)
            else:
                d = sd
            if d.tzinfo is None:
                d = d.replace(tzinfo=timezone.utc)
            if d >= thirty_days_ago:
                break_frequency_30d += 1

        avg_ageing = (
            sum(b["computedAgeingDays"] for b in seg_breaks) / len(seg_breaks)
            if seg_breaks else 0
        )

        material_threshold = latest_thresholds.get(row["segmentKey"], 1.0)
        if material_threshold == 0:
            material_threshold = 1.0
        threshold_distance = float(row["amountGbp"]) / material_threshold

        repeat_trade_flag = 1 if trade_id_count.get(row["tradeId"], 0) > 1 else 0

        amounts = [float(b["amountGbp"]) for b in seg_breaks]
        segment_volatility = std_dev(amounts)

        maturity_proximity_days = 999
        if row.get("maturityDate"):
            mat_str = row["maturityDate"]
            if isinstance(mat_str, str):
                try:
                    mat_date = datetime.fromisoformat(mat_str.replace("Z", "+00:00"))
                except ValueError:
                    mat_date = datetime.strptime(mat_str[:10], "%Y-%m-%d").replace(tzinfo=timezone.utc)
            else:
                mat_date = mat_str
            if mat_date.tzinfo is None:
                mat_date = mat_date.replace(tzinfo=timezone.utc)
            maturity_proximity_days = max(0, (mat_date - now).days)

        features_to_insert.append({
            "cleanBreakId": row["id"],
            "tradeId": row["tradeId"],
            "segmentKey": row["segmentKey"],
            "breakFrequency30d": str(break_frequency_30d),
            "avgAgeing": f"{avg_ageing:.2f}",
            "thresholdDistance": f"{threshold_distance:.4f}",
            "repeatTradeFlag": repeat_trade_flag,
            "segmentVolatility": f"{segment_volatility:.2f}",
            "maturityProximityDays": maturity_proximity_days,
            "computedAt": now.isoformat(),
        })

    if features_to_insert:
        storage.ml_features.insert_many(features_to_insert)

    storage.audit_log.insert({
        "action": "FEATURES_GENERATED",
        "entity": "ml_features",
        "details": {"featuresGenerated": len(features_to_insert), "batchId": batch_id},
    })

    return {"featuresGenerated": len(features_to_insert)}
