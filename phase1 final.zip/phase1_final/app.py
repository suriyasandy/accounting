"""
Accounting Control AI Platform — Phase 1
=========================================
Built on the uploaded Phase_1_app.txt with two major additions:

NEW FEATURE 1: CLICK-THROUGH DRILL-DOWN (Tab 3 — Break Counts)
  - Top chart shows all top-10 Rec Names trend (unchanged)
  - Below it: user selects ANY Rec Name from a dropdown
  - Dashboard renders full granular breakdown of that Rec:
    counts/amounts by Period × Team, Period × Entity,
    Period × Type of Break, Period × Asset Class
  - Uses st.session_state to persist selection across reruns

NEW FEATURE 2: STATISTICAL FALSE POSITIVE THRESHOLDING (Tab 6 — new)
  - For each segment (Rec + Team + Entity + Asset Class):
      * Computes break count across all uploaded periods
      * Uses last N-1 periods as "historical baseline"
      * Flags latest period as FP CANDIDATE if count is within
        historical_mean ± k × MAD  (configurable k)
      * Three confidence tiers: High / Medium / Low FP confidence
  - User reviews the ranked FP candidates and confirms/rejects
    via data_editor checkboxes
  - Confirmed FPs propagate to sidebar "Exclude False Positives" filter

ALL EXISTING FIXES RETAINED:
  - from __future__ import annotations  (Python 3.9 compatible)
  - format_short() K/M/B/T/P  (no 10^16 on axes)
  - TRY_CAST AS DOUBLE in all DuckDB amount SQL
  - Apply-button filter pattern
  - Auto Parquet conversion and cache
"""

from __future__ import annotations

import hashlib
import math
import os
import tempfile
from io import BytesIO

import duckdb
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

try:
    from st_aggrid import AgGrid, GridOptionsBuilder, JsCode
    HAS_AGGRID = True
except ImportError:
    HAS_AGGRID = False

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Accounting Control AI Platform",
    page_icon="📊", layout="wide",
    initial_sidebar_state="expanded",
)

COLORS       = ["#01696F","#0C4E54","#20808D","#4F98A3","#A84B2F",
                "#1B474D","#BCE2E7","#944454","#FFC553","#5C2D91"]
PRIMARY      = "#01696F"
DARK         = "#28251D"
MUTED        = "#7A7974"
BG_LIGHT     = "#F7F7F5"
WARN         = "#A84B2F"
BUCKET_ORDER = ["0-15","16-30","31-60","61-90","91-180","181-365","365+","Unknown"]
MAX_JS_INT   = 2 ** 53

st.markdown(f"""
<style>
  .main .block-container{{padding-top:1rem;padding-bottom:1rem;}}
  h1{{color:{DARK};font-size:1.6rem !important;}}
  h2{{color:{DARK};font-size:1.25rem !important;}}
  h3{{color:{DARK};font-size:1.05rem !important;}}
  .stTabs [data-baseweb="tab-list"]{{gap:8px;}}
  .stTabs [data-baseweb="tab"]{{background-color:{BG_LIGHT};border-radius:6px 6px 0 0;
      padding:8px 16px;font-weight:600;color:{DARK};}}
  .stTabs [aria-selected="true"]{{background-color:{PRIMARY} !important;color:white !important;}}
  .kpi-card{{background:white;border-left:4px solid {PRIMARY};padding:12px 16px;
      border-radius:4px;box-shadow:0 1px 3px rgba(0,0,0,.08);}}
  .kpi-warn{{background:white;border-left:4px solid {WARN};padding:12px 16px;
      border-radius:4px;box-shadow:0 1px 3px rgba(0,0,0,.08);}}
  .kpi-label{{color:{MUTED};font-size:.75rem;text-transform:uppercase;
      letter-spacing:.5px;margin-bottom:2px;}}
  .kpi-value{{color:{DARK};font-size:1.4rem;font-weight:700;margin:0;}}
  .kpi-delta-pos{{color:#A84B2F;font-size:.8rem;}}
  .kpi-delta-neg{{color:#01696F;font-size:.8rem;}}
  .banner-warn{{background:#FDECEA;border-left:4px solid {WARN};padding:10px 16px;
      border-radius:4px;margin-bottom:.5rem;font-size:.88rem;color:{DARK};}}
  .banner-info{{background:#E6F4F1;border-left:4px solid {PRIMARY};padding:10px 16px;
      border-radius:4px;margin-bottom:.5rem;font-size:.88rem;color:{DARK};}}
  .banner-fp{{background:#FFF8E1;border-left:4px solid #FFC553;padding:10px 16px;
      border-radius:4px;margin-bottom:.5rem;font-size:.88rem;color:{DARK};}}
  .banner-drill{{background:#EDE7F6;border-left:4px solid #5C2D91;padding:10px 16px;
      border-radius:4px;margin-bottom:.5rem;font-size:.88rem;color:{DARK};}}
  .banner-jira{{background:#E8F4FD;border-left:4px solid #20808D;padding:10px 16px;
      border-radius:4px;margin-bottom:.5rem;font-size:.88rem;color:{DARK};}}
  div[data-testid="stButton"]>button{{background-color:{PRIMARY};color:white;
      border:none;font-weight:600;border-radius:6px;padding:8px 24px;}}
  div[data-testid="stButton"]>button:hover{{background-color:#0C4E54;color:white;}}
  .drill-section{{background:#F8F6FF;border:1px solid #D1C4E9;border-radius:8px;
      padding:16px;margin-top:12px;}}
</style>
""", unsafe_allow_html=True)


# ════════════════════════════════════════════════════════════════
# UTILITIES
# ════════════════════════════════════════════════════════════════

def format_short(n, prefix="£"):
    if n is None:
        return "N/A"
    try:
        v = float(n)
        if math.isnan(v) or math.isinf(v):
            return "N/A"
    except (TypeError, ValueError):
        return "N/A"
    sign = "-" if v < 0 else ""
    v = abs(v)
    if v == 0:
        return f"{prefix}0"
    if v >= 1_000_000_000_000_000:
        return f"{sign}{prefix}{v/1e15:.2f}P"
    if v >= 1_000_000_000_000:
        return f"{sign}{prefix}{v/1e12:.2f}T"
    if v >= 1_000_000_000:
        return f"{sign}{prefix}{v/1e9:.1f}B"
    if v >= 1_000_000:
        return f"{sign}{prefix}{v/1e6:.1f}M"
    if v >= 1_000:
        return f"{sign}{prefix}{v/1e3:.1f}K"
    return f"{sign}{prefix}{v:,.2f}"


def format_number(n, decimal=0):
    if n is None:
        return "N/A"
    try:
        if math.isnan(float(n)):
            return "N/A"
    except (TypeError, ValueError):
        return "N/A"
    return f"{int(n):,}" if decimal == 0 else f"{float(n):,.{decimal}f}"


def safe_mom_pct(current, previous):
    if previous is None or previous == 0:
        return None
    return round(((current - previous) / abs(previous)) * 100, 1)


def kpi_card(label, value, delta=None, invert=False, warn=False):
    delta_html = ""
    if delta:
        css = ("kpi-delta-pos" if str(delta).startswith("-") else "kpi-delta-neg") \
              if invert else \
              ("kpi-delta-neg" if str(delta).startswith("-") else "kpi-delta-pos")
        delta_html = f'<p class="{css}">{delta}</p>'
    st.markdown(
        f'<div class="{"kpi-warn" if warn else "kpi-card"}">'
        f'<p class="kpi-label">{label}</p>'
        f'<p class="kpi-value">{value}</p>{delta_html}</div>',
        unsafe_allow_html=True)


def chart_layout(fig, title="", xt="", yt="", height=400):
    fig.update_layout(
        title=dict(text=title, font=dict(size=14, color=DARK)),
        xaxis_title=xt, yaxis_title=yt, height=height,
        margin=dict(l=40, r=20, t=50, b=40),
        font=dict(family="Inter, sans-serif", size=11, color=DARK),
        plot_bgcolor="white", paper_bgcolor="white",
        legend=dict(font=dict(size=10)),
    )
    fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor="#ECECEC")
    fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor="#ECECEC")
    return fig


def add_rolling_avg(fig, x, y, window=3, name="Rolling Avg", color=None):
    xl = list(x)
    if len(xl) < window:
        return fig
    rolled = pd.Series(list(y)).rolling(window, min_periods=1).mean().round(1)
    fig.add_trace(go.Scatter(x=xl, y=rolled.tolist(),
                             name=f"{name} ({window}p)", mode="lines",
                             line=dict(color=color or COLORS[7], width=2, dash="dot")))
    return fig


def render_grid(df, height=400, key=None, match_cols=None):
    df_d = df.copy()
    for col in df_d.columns:
        if df_d[col].dtype in (np.int64, np.uint64, np.float64):
            try:
                if df_d[col].dropna().abs().max() > MAX_JS_INT:
                    df_d[col] = df_d[col].apply(
                        lambda x: format_short(x) if pd.notna(x) else "N/A")
            except Exception:
                pass
    if HAS_AGGRID and len(df_d):
        gb = GridOptionsBuilder.from_dataframe(df_d)
        gb.configure_pagination(paginationAutoPageSize=False, paginationPageSize=20)
        gb.configure_default_column(filterable=True, sortable=True, resizable=True)
        if match_cols:
            cs = JsCode("""function(p){
                if(p.value===false||p.value==='False')
                    return{'backgroundColor':'#FDECEA','color':'#A84B2F','fontWeight':'bold'};
                if(p.value===true||p.value==='True')
                    return{'backgroundColor':'#E8F5E9','color':'#01696F'};
                return{};}""")
            for c in match_cols:
                if c in df_d.columns:
                    gb.configure_column(c, cellStyle=cs)
        AgGrid(df_d, gridOptions=gb.build(), height=height,
               theme="streamlit", key=key, allow_unsafe_jscode=True)
    else:
        st.dataframe(df_d, height=height, use_container_width=True)


# ════════════════════════════════════════════════════════════════
# DUCKDB
# ════════════════════════════════════════════════════════════════

@st.cache_resource
def get_duck():
    con = duckdb.connect()
    con.execute("SET threads=4")
    con.execute("SET memory_limit='2GB'")
    return con


def dq(sql, df=None):
    con = get_duck()
    if df is not None:
        con.register("tbl", df)
    return con.execute(sql).df()


def safe_amt(col):
    return f'TRY_CAST("{col}" AS DOUBLE)'


# ════════════════════════════════════════════════════════════════
# PARQUET CACHE
# ════════════════════════════════════════════════════════════════

def _cache_dir():
    d = os.path.join(tempfile.gettempdir(), "acai_cache")
    os.makedirs(d, exist_ok=True)
    return d


def _pq_path(fhash):
    return os.path.join(_cache_dir(), f"{fhash}.parquet")


def file_hash(b):
    return hashlib.sha256(b[:4*1024*1024] + str(len(b)).encode()).hexdigest()


# ════════════════════════════════════════════════════════════════
# VECTORISED HELPERS  (Python 3.9 safe — no X|Y hints)
# ════════════════════════════════════════════════════════════════

def period_to_datetime_vec(series):
    s     = pd.to_numeric(series, errors="coerce")
    year  = (s // 100).astype("Int64")
    month = (s  % 100).astype("Int64")
    valid = month.between(1, 12) & year.notna()
    nm    = (month + 1).where(valid)
    ny    = year.where(valid).copy()
    dec   = month == 12
    nm    = nm.where(~dec, 1)
    ny    = ny.where(~dec, year + 1)
    result = pd.Series(pd.NaT, index=series.index, dtype="datetime64[ns]")
    vi = valid[valid].index
    if len(vi):
        ds = (ny.loc[vi].astype(str) + "-"
              + nm.loc[vi].astype(str).str.zfill(2) + "-01")
        result.loc[vi] = pd.to_datetime(ds, errors="coerce") - pd.Timedelta(days=1)
    return result


def parse_amount_vec(series):
    orig = series.isna()
    s    = series.astype(str).str.strip()
    s    = s.str.replace(r"[£$€¥,]", "", regex=True)
    s    = s.str.replace(r"(?i)^(GBP|USD|EUR|JPY|CHF|AUD|CAD)\s*", "", regex=True)
    s    = s.str.replace(r"^\((.+)\)$", r"-\1", regex=True).str.strip()
    r    = pd.to_numeric(s, errors="coerce").astype("float64")
    r[orig] = np.nan
    overflow = r.abs() > MAX_JS_INT
    if overflow.sum():
        prev = st.session_state.get("_overflow", 0)
        st.session_state["_overflow"] = prev + int(overflow.sum())
        r[overflow] = np.nan
    return r


def parse_age_days_vec(series):
    s = series.astype(str).str.strip()
    r = pd.to_numeric(s.str.extract(r"^[~]?(-?\d+)", expand=False), errors="coerce")
    r[series.isna() | s.isin(["","N/A","n/a","-","nan","None"])] = np.nan
    return r


def age_to_bucket_vec(age_series):
    a    = age_series.values
    cond = [pd.isna(age_series), a<=15, a<=30, a<=60, a<=90, a<=180, a<=365]
    ch   = ["Unknown","0-15","16-30","31-60","61-90","91-180","181-365"]
    return pd.Categorical(np.select(cond, ch, default="365+"),
                          categories=BUCKET_ORDER, ordered=True)


# ════════════════════════════════════════════════════════════════
# COLUMN MAPPING
# ════════════════════════════════════════════════════════════════

EXPECTED_COLUMNS = [
    "Period","Asset Class","Team","Rec Name (as per Rec Cube)","Entity",
    "Type of break","Account Group","Products Reconciled","TRADE REF",
    "If Duplicate Trade, provide the CC, etc details","TRADE CCY",
    "BREAK AMOUNT CCY","BREAK AMOUNT GBP","Date","Age Days","Bucket",
    "True/Systemic Breaks","Journals Posted","Comments","ABS GBP",
    "Root Cause identified","B/S Cert","Jira Reference","Jira Desc",
    "System to be Fixed","ISSUE CATEGORY","JIRA PRIORITY","For Del",
]


def fuzzy_match(cols, target):
    tl = target.lower().strip()
    for c in cols:
        if c.lower().strip() == tl:
            return c
    for c in cols:
        if tl in c.lower() or c.lower() in tl:
            return c
    return None


def build_col_map(cols):
    result = {}
    for e in EXPECTED_COLUMNS:
        m = fuzzy_match(cols, e)
        if m:
            result[e] = m
    return result


def drop_blank_trailing(df, n=4):
    to_drop = []
    for col in list(df.columns)[-n:]:
        null_pct = df[col].isna().mean()
        try:
            blank_pct = df[col].astype(str).str.strip().isin(
                ["","nan","None","NaN"]).mean()
        except Exception:
            blank_pct = 0.0
        if max(null_pct, blank_pct) >= 0.95:
            to_drop.append(col)
    return df.drop(columns=to_drop), to_drop


# ════════════════════════════════════════════════════════════════
# PIPELINE
# ════════════════════════════════════════════════════════════════

@st.cache_data(show_spinner="Processing — runs once, then instant from Parquet…")
def run_pipeline(file_bytes, filename):
    st.session_state["_overflow"] = 0

    fhash   = file_hash(file_bytes)
    pq_path = _pq_path(fhash)

    if os.path.exists(pq_path):
        df = pd.read_parquet(pq_path)
    else:
        buf  = BytesIO(file_bytes)
        name = filename.lower()
        if name.endswith(".parquet"):
            df = pd.read_parquet(buf)
        elif name.endswith(".csv"):
            df = pd.read_csv(buf, low_memory=False)
        else:
            try:
                import python_calamine  # noqa
                df = pd.read_excel(buf, engine="calamine")
            except ImportError:
                buf.seek(0)
                df = pd.read_excel(buf, engine="openpyxl")

    df, dropped_cols = drop_blank_trailing(df, n=4)
    col_map    = build_col_map(df.columns.tolist())
    violations = []

    # For Del
    fdel = col_map.get("For Del")
    filtered_for_del = 0
    if fdel and fdel in df.columns:
        mask = df[fdel].astype(str).str.strip().str.lower().isin(
            {"true","yes","y","1","x","delete","del"})
        filtered_for_del = int(mask.sum())
        df = df[~mask].copy()

    # Amounts
    for key in ("BREAK AMOUNT CCY","BREAK AMOUNT GBP","ABS GBP"):
        actual = col_map.get(key)
        if actual and actual in df.columns:
            orig      = df[actual].copy()
            df[actual] = parse_amount_vec(df[actual])
            bad = orig.notna() & df[actual].isna()
            if bad.sum():
                violations.append({"Column":actual,"Expected Type":"float64",
                    "Violation Count":int(bad.sum()),
                    "Sample Values":", ".join(orig[bad].head(3).astype(str))})

    # Age Days
    actual = col_map.get("Age Days")
    if actual and actual in df.columns:
        orig       = df[actual].copy()
        df[actual] = parse_age_days_vec(df[actual])
        bad = orig.notna() & orig.astype(str).str.strip().ne("") & df[actual].isna()
        if bad.sum():
            violations.append({"Column":actual,"Expected Type":"numeric",
                "Violation Count":int(bad.sum()),
                "Sample Values":", ".join(orig[bad].head(3).astype(str))})

    # Date
    actual = col_map.get("Date")
    if actual and actual in df.columns:
        df[actual] = pd.to_datetime(df[actual], errors="coerce")

    # Period
    actual = col_map.get("Period")
    if actual and actual in df.columns:
        df["_Period_date"]  = period_to_datetime_vec(df[actual])
        df["_Period_label"] = (df["_Period_date"].dt.strftime("%Y-%m")
                                .fillna(df[actual].astype(str)))

    # Ageing
    date_actual = col_map.get("Date")
    if date_actual and date_actual in df.columns and "_Period_date" in df.columns:
        df["_Computed_Age_Days"] = (df["_Period_date"] - df[date_actual]).dt.days
        df["_Computed_Bucket"]   = age_to_bucket_vec(df["_Computed_Age_Days"])
        age_actual = col_map.get("Age Days")
        if age_actual and age_actual in df.columns:
            df["_Age_Match"] = np.isclose(
                df[age_actual].fillna(-999),
                df["_Computed_Age_Days"].fillna(-998), atol=1)
        bkt_actual = col_map.get("Bucket")
        if bkt_actual and bkt_actual in df.columns:
            df["_Bucket_Match"] = (
                df[bkt_actual].astype(str).str.strip()
                == df["_Computed_Bucket"].astype(str).str.strip())

    df["_FP_Confirmed"] = False  # user-confirmed false positive

    # Save Parquet
    if not os.path.exists(pq_path):
        try:
            save = df.copy()
            for c in save.select_dtypes(["category"]).columns:
                save[c] = save[c].astype(str)
            save.to_parquet(pq_path, index=False, engine="pyarrow",
                            compression="snappy")
        except Exception:
            pass

    # Filter options
    filter_options = {}
    for key in ("Period","Team","Rec Name (as per Rec Cube)","Entity",
                "Asset Class","Type of break","True/Systemic Breaks"):
        actual = col_map.get(key)
        if actual and actual in df.columns:
            filter_options[key] = sorted(df[actual].dropna().unique().tolist())

    vdf = (pd.DataFrame(violations) if violations
           else pd.DataFrame(columns=["Column","Expected Type","Violation Count","Sample Values"]))

    return {
        "df": df, "col_map": col_map, "filter_options": filter_options,
        "violations_df": vdf, "dropped_cols": dropped_cols,
        "filtered_for_del": filtered_for_del, "fhash": fhash,
    }


# ════════════════════════════════════════════════════════════════
# APPLY-BUTTON FILTER PATTERN
# ════════════════════════════════════════════════════════════════

def build_sidebar_filters(col_map, filter_options, df):
    st.sidebar.markdown("---")
    st.sidebar.markdown("### 🔍 Filters")
    st.sidebar.caption("Set filters → click **Apply** to update all tabs.")

    pending = {}

    for key, label, wkey in [
        ("Period",                     "Period",        "fw_period"),
        ("Team",                       "Team",          "fw_team"),
        ("Rec Name (as per Rec Cube)", "Rec Name",      "fw_rec"),
        ("Entity",                     "Entity",        "fw_entity"),
        ("Asset Class",                "Asset Class",   "fw_ac"),
        ("Type of break",              "Type of Break", "fw_tob"),
        ("True/Systemic Breaks",       "True/Systemic", "fw_ts"),
    ]:
        opts = filter_options.get(key, [])
        if not opts:
            continue
        sel = st.sidebar.multiselect(label, opts, default=opts, key=wkey)
        if sel and len(sel) < len(opts):
            pending[key] = sel

    abs_col = col_map.get("ABS GBP") or col_map.get("BREAK AMOUNT GBP")
    if abs_col and abs_col in df.columns:
        raw_max = df[abs_col].abs().max()
        safe_max = float(min(raw_max if pd.notna(raw_max) else 1e6, 1e9))
        thresh = st.sidebar.number_input(
            "Min ABS GBP (£)", min_value=0.0, max_value=safe_max,
            value=0.0, step=1000.0, format="%.0f", key="fw_thresh")
        if thresh > 0:
            pending["_ABS"] = (abs_col, thresh)

    if st.sidebar.checkbox("Exclude Confirmed False Positives", False, key="fw_fp"):
        pending["_EXCL_FP"] = True

    apply = st.sidebar.button("✅ Apply Filters", key="apply_btn",
                               use_container_width=True)
    st.sidebar.button("🔄 Reset", key="reset_btn",
                      on_click=_reset_filters, use_container_width=True)
    return pending, apply


def _reset_filters():
    for k in ["fw_period","fw_team","fw_rec","fw_entity","fw_ac","fw_tob","fw_ts",
              "fw_thresh","fw_fp","_applied_filters","_drill_rec"]:
        if k in st.session_state:
            del st.session_state[k]


def apply_filters(df, col_map, filters):
    if not filters:
        return df
    where = []
    for key, vals in filters.items():
        if key == "_ABS":
            col, thresh = vals
            where.append(f"ABS({safe_amt(col)}) >= {thresh}")
        elif key == "_EXCL_FP":
            where.append("_FP_Confirmed = false")
        else:
            col = col_map.get(key)
            if not col:
                continue
            esc    = [str(v).replace("'","''") for v in vals]
            in_lst = ", ".join(f"'{v}'" for v in esc)
            where.append(f'"{col}" IN ({in_lst})')
    if not where:
        return df
    try:
        return dq(f"SELECT * FROM tbl WHERE {' AND '.join(where)}", df)
    except Exception as exc:
        st.sidebar.error(f"Filter error: {exc}")
        return df


# ════════════════════════════════════════════════════════════════
# TAB 1 — DATA QUALITY
# ════════════════════════════════════════════════════════════════

def tab_data_quality(df, col_map, violations_df, dropped_cols, filtered_for_del):
    st.markdown("## Data Quality & Ingestion Scorecard")

    overflow = st.session_state.get("_overflow", 0)
    if overflow:
        st.markdown(f'<div class="banner-warn">⚠️ <b>Amount Overflow:</b> '
                    f'{format_number(overflow)} ABS GBP values exceeded 2^53 '
                    f'(JS integer limit) and were set to NaN. Check raw Excel.</div>',
                    unsafe_allow_html=True)

    vcount = int(violations_df["Violation Count"].sum()) if len(violations_df) else 0
    if vcount:
        st.markdown(f'<div class="banner-warn">⚠️ {format_number(vcount)} type violations '
                    f'across {len(violations_df)} column(s).</div>', unsafe_allow_html=True)
    if dropped_cols:
        st.markdown(f'<div class="banner-info">🗑️ Auto-removed {len(dropped_cols)} blank trailing '
                    f'column(s): {", ".join(dropped_cols)}</div>', unsafe_allow_html=True)
    if filtered_for_del:
        st.markdown(f'<div class="banner-info">✅ For Del filter removed '
                    f'{format_number(filtered_for_del)} records.</div>', unsafe_allow_html=True)

    n, nc = len(df), len(df.columns)
    comp = round(df.notna().sum().sum() / (n * nc) * 100, 1) if n * nc else 0

    c1, c2, c3, c4 = st.columns(4)
    with c1: kpi_card("Total Records",   format_number(n))
    with c2: kpi_card("Completeness",    f"{comp}%")
    with c3: kpi_card("Type Violations", format_number(vcount), warn=(vcount > 0))
    with c4: kpi_card("For Del Filtered",format_number(filtered_for_del))

    st.markdown("---")
    cl, cr = st.columns(2)
    with cl:
        st.markdown("### Column Completeness")
        non_meta = [c for c in df.columns if not c.startswith("_")]
        exprs    = ", ".join(f'ROUND(100.0*COUNT("{c}")/COUNT(*),1) AS "{c}"' for c in non_meta)
        if exprs:
            cdf = dq(f"SELECT {exprs} FROM tbl", df).T.reset_index()
            cdf.columns = ["Column","Completeness %"]
            cdf = cdf.sort_values("Completeness %", ascending=True)
            fig = px.bar(cdf, x="Completeness %", y="Column", orientation="h",
                         color_discrete_sequence=[PRIMARY])
            fig = chart_layout(fig,"Per-Column Completeness (%)","Completeness %",
                               height=max(300, len(cdf)*15))
            fig.update_layout(yaxis=dict(tickfont=dict(size=9)))
            st.plotly_chart(fig, use_container_width=True)

    with cr:
        st.markdown("### Type Violation Details")
        if len(violations_df):
            render_grid(violations_df, height=200, key="tv")
        else:
            st.success("✅ No type violations detected.")
        st.markdown("### Outlier Detection (IQR)")
        out_frames = []
        for key in ("BREAK AMOUNT CCY","BREAK AMOUNT GBP","ABS GBP","Age Days"):
            actual = col_map.get(key)
            if actual and actual in df.columns and df[actual].dtype == np.float64:
                clean = df[actual].dropna()
                if len(clean) >= 10:
                    q1, q3 = clean.quantile(0.25), clean.quantile(0.75)
                    iqr = q3 - q1
                    lo, hi = q1 - 1.5*iqr, q3 + 1.5*iqr
                    out = clean[(clean < lo) | (clean > hi)]
                    if len(out):
                        out_frames.append(pd.DataFrame({
                            "Column":[actual],"Outlier Count":[len(out)],
                            "Outlier %":[round(len(out)/len(clean)*100,2)],
                            "IQR Lower":[format_short(lo)],
                            "IQR Upper":[format_short(hi)],
                            "Min Outlier":[format_short(out.min())],
                            "Max Outlier":[format_short(out.max())],
                        }))
        if out_frames:
            render_grid(pd.concat(out_frames, ignore_index=True), height=200, key="ol")
        else:
            st.info("No significant outliers detected.")

    st.markdown("---")
    d1, d2 = st.columns(2)
    with d1:
        st.download_button("📥 Download Cleaned CSV",
                           df.to_csv(index=False).encode("utf-8"),
                           file_name="cleaned_data.csv", mime="text/csv")
    with d2:
        buf = BytesIO()
        df.to_parquet(buf, index=False, compression="zstd")
        st.download_button("⚡ Download Parquet (instant future uploads)",
                           buf.getvalue(), file_name="cleaned_data.parquet",
                           mime="application/octet-stream")


# ════════════════════════════════════════════════════════════════
# TAB 2 — AGEING VALIDATION
# ════════════════════════════════════════════════════════════════

def tab_ageing_validation(df, col_map):
    st.markdown("## Ageing Validation")

    age_col    = col_map.get("Age Days")
    bucket_col = col_map.get("Bucket")
    team_col   = col_map.get("Team")
    rec_col    = col_map.get("Rec Name (as per Rec Cube)")

    if not all(c in df.columns for c in
               ["_Computed_Age_Days","_Computed_Bucket","_Age_Match","_Bucket_Match"]):
        st.warning("Period and Date columns required for ageing validation.")
        return

    kpi = dq(f"""
        SELECT
            COUNT(*) FILTER (WHERE _Computed_Age_Days IS NOT NULL AND "{age_col}" IS NOT NULL)
                AS total_valid,
            COUNT(*) FILTER (WHERE _Age_Match=false AND _Computed_Age_Days IS NOT NULL)
                AS age_mis,
            COUNT(*) FILTER (WHERE _Bucket_Match=false AND _Computed_Age_Days IS NOT NULL)
                AS bucket_mis
        FROM tbl
    """, df).iloc[0]

    n, am, bm = int(kpi["total_valid"]), int(kpi["age_mis"]), int(kpi["bucket_mis"])
    ap = round(am / n * 100, 1) if n else 0
    bp = round(bm / n * 100, 1) if n else 0

    c1, c2, c3, c4 = st.columns(4)
    with c1: kpi_card("Records Validated",    format_number(n))
    with c2: kpi_card("Age Discrepancies",    f"{format_number(am)} ({ap}%)", warn=(ap>5), invert=True)
    with c3: kpi_card("Bucket Discrepancies", f"{format_number(bm)} ({bp}%)", warn=(bp>5), invert=True)
    with c4: kpi_card("Accuracy Rate",        f"{round(100-max(ap,bp),1)}%")

    st.markdown("---")
    st.markdown("### Discrepancy Records — Flag False Positives")
    st.markdown('<div class="banner-fp">💡 Tick <b>False Positive</b> to mark known exceptions. '
                'Use sidebar toggle to exclude globally.</div>', unsafe_allow_html=True)

    sel_sql = ", ".join(
        f'"{col_map[k]}"' for k in
        ["Period","Team","Rec Name (as per Rec Cube)","Entity","Date","TRADE REF"]
        if k in col_map and col_map[k] in df.columns
    )
    disc = dq(f"""
        SELECT {sel_sql},
               "{age_col}" AS "Age Days (Source)",
               _Computed_Age_Days AS "Age Days (Computed)",
               "{bucket_col}" AS "Bucket (Source)",
               _Computed_Bucket AS "Bucket (Computed)",
               _Age_Match AS "Age Match", _Bucket_Match AS "Bucket Match",
               _FP_Confirmed AS "False Positive"
        FROM tbl
        WHERE (_Age_Match=false OR _Bucket_Match=false)
          AND _Computed_Age_Days IS NOT NULL
        ORDER BY _Computed_Age_Days DESC LIMIT 500
    """, df)

    if len(disc):
        fp_ed = st.data_editor(disc,
            column_config={
                "False Positive": st.column_config.CheckboxColumn("False Positive?"),
                "Age Match":      st.column_config.CheckboxColumn("Age Match"),
                "Bucket Match":   st.column_config.CheckboxColumn("Bucket Match"),
            },
            use_container_width=True, height=380, num_rows="fixed", key="fp_editor")
        fp_cnt = int(fp_ed["False Positive"].sum())
        fc1, fc2, fc3 = st.columns(3)
        with fc1: kpi_card("Total Discrepancies",    format_number(len(disc)))
        with fc2: kpi_card("Flagged False Positive", format_number(fp_cnt))
        with fc3: kpi_card("Net Outstanding",        format_number(len(disc)-fp_cnt),
                           warn=(len(disc)-fp_cnt > 0))
    else:
        st.success("✅ No discrepancies found!")

    # Charts
    st.markdown("---")
    cl, cr = st.columns(2)
    with cl:
        h = dq(f"""SELECT "{age_col}" AS prepop, _Computed_Age_Days AS computed
                   FROM tbl WHERE _Computed_Age_Days IS NOT NULL AND "{age_col}" IS NOT NULL""", df)
        fig = go.Figure()
        fig.add_trace(go.Histogram(x=h["prepop"],  name="Pre-populated",
                                   opacity=0.6, marker_color=COLORS[0], nbinsx=50))
        fig.add_trace(go.Histogram(x=h["computed"], name="Computed",
                                   opacity=0.6, marker_color=COLORS[4], nbinsx=50))
        fig.update_layout(barmode="overlay")
        fig = chart_layout(fig,"Age Days Distribution","Age Days","Count")
        st.plotly_chart(fig, use_container_width=True)

    with cr:
        bkt = dq("SELECT _Computed_Bucket AS bucket, COUNT(*) AS computed FROM tbl "
                 "WHERE _Computed_Age_Days IS NOT NULL GROUP BY _Computed_Bucket", df)
        pre = dq(f'SELECT "{bucket_col}" AS bucket, COUNT(*) AS prepop '
                 f'FROM tbl GROUP BY "{bucket_col}"', df)
        mg  = bkt.merge(pre, on="bucket", how="outer").fillna(0)
        mg["bucket"] = pd.Categorical(mg["bucket"], categories=BUCKET_ORDER, ordered=True)
        mg = mg.sort_values("bucket")
        fig = go.Figure()
        fig.add_trace(go.Bar(x=mg["bucket"], y=mg["prepop"],  name="Pre-populated", marker_color=COLORS[0]))
        fig.add_trace(go.Bar(x=mg["bucket"], y=mg["computed"], name="Computed",      marker_color=COLORS[4]))
        fig.update_layout(barmode="group")
        fig = chart_layout(fig,"Bucket Distribution","Bucket","Count")
        st.plotly_chart(fig, use_container_width=True)

    if "_Period_label" in df.columns:
        period_order = sorted(df["_Period_label"].dropna().unique().tolist())
        st.markdown("---")
        st.markdown("## Ageing Trend Analysis")
        ct1, ct2 = st.columns(2)
        with ct1:
            tr = dq("SELECT _Period_label AS period, AVG(_Computed_Age_Days) AS mean_age, "
                    "MEDIAN(_Computed_Age_Days) AS median_age "
                    "FROM tbl WHERE _Computed_Age_Days IS NOT NULL "
                    "GROUP BY _Period_label ORDER BY _Period_label", df)
            fig = go.Figure()
            fig.add_trace(go.Bar(x=tr["period"], y=tr["mean_age"],
                                 name="Mean", marker_color=COLORS[0], opacity=0.7))
            fig.add_trace(go.Scatter(x=tr["period"], y=tr["median_age"], name="Median",
                                     line=dict(color=COLORS[4], width=2), mode="lines+markers"))
            fig = add_rolling_avg(fig, tr["period"], tr["mean_age"])
            fig = chart_layout(fig,"Average Age Days Trend","Period","Days")
            st.plotly_chart(fig, use_container_width=True)

        with ct2:
            bt = dq("SELECT _Period_label AS period, _Computed_Bucket AS bucket, COUNT(*) AS cnt "
                    "FROM tbl WHERE _Computed_Age_Days IS NOT NULL "
                    "GROUP BY _Period_label, _Computed_Bucket ORDER BY _Period_label", df)
            bt["bucket"] = pd.Categorical(bt["bucket"], categories=BUCKET_ORDER, ordered=True)
            fig = px.bar(bt, x="period", y="cnt", color="bucket",
                         color_discrete_sequence=COLORS, barmode="stack",
                         category_orders={"period":period_order,"bucket":BUCKET_ORDER})
            fig = chart_layout(fig,"Ageing Bucket Distribution Over Time","Period","Count")
            st.plotly_chart(fig, use_container_width=True)


# ════════════════════════════════════════════════════════════════
# TAB 3 — BREAK COUNTS + DRILL-DOWN
# ════════════════════════════════════════════════════════════════

def tab_break_counts(df, col_map):
    st.markdown("## Trend Analysis: Break Counts")

    period_col = col_map.get("Period")
    team_col   = col_map.get("Team")
    rec_col    = col_map.get("Rec Name (as per Rec Cube)")
    ac_col     = col_map.get("Asset Class")
    ts_col     = col_map.get("True/Systemic Breaks")
    bucket_col = col_map.get("Bucket")
    entity_col = col_map.get("Entity")
    tob_col    = col_map.get("Type of break")

    if not period_col or period_col not in df.columns or "_Period_label" not in df.columns:
        st.warning("Period column not found.")
        return

    period_order = sorted(df["_Period_label"].dropna().unique().tolist())
    latest = period_order[-1] if period_order else "0"
    prev   = period_order[-2] if len(period_order) >= 2 else "0"

    kpi = dq(f"""
        SELECT COUNT(*) AS total,
               COUNT(*) FILTER (WHERE _Period_label='{latest}') AS lat,
               COUNT(*) FILTER (WHERE _Period_label='{prev}')   AS prv
        FROM tbl
    """, df).iloc[0]

    mom = safe_mom_pct(int(kpi["lat"]), int(kpi["prv"]))
    c1, c2, c3, c4 = st.columns(4)
    with c1: kpi_card("Total Breaks",  format_number(kpi["total"]))
    with c2: kpi_card("Latest Period", format_number(kpi["lat"]),
                      f"{'+'if mom and mom>0 else ''}{mom}% MoM" if mom else None,
                      invert=True, warn=(mom is not None and mom > 15))
    with c3: kpi_card("Avg/Period",    format_number(round(kpi["total"]/max(len(period_order),1))))
    with c4: kpi_card("Periods",       str(len(period_order)))

    st.markdown("---")
    ca, cb = st.columns(2)
    with ca:
        p_df = dq("SELECT _Period_label AS period, COUNT(*) AS cnt "
                  "FROM tbl GROUP BY _Period_label ORDER BY _Period_label", df)
        fig = go.Figure()
        fig.add_trace(go.Bar(x=p_df["period"], y=p_df["cnt"],
                             name="Count", marker_color=COLORS[0], opacity=0.7))
        fig.add_trace(go.Scatter(x=p_df["period"], y=p_df["cnt"], name="Actual",
                                 mode="lines+markers", line=dict(color=COLORS[4], width=2)))
        fig = add_rolling_avg(fig, p_df["period"], p_df["cnt"])
        fig = chart_layout(fig,"Break Count Trend by Period","Period","Count")
        st.plotly_chart(fig, use_container_width=True)

    with cb:
        if team_col and team_col in df.columns:
            t_df = dq(f'SELECT "{team_col}" AS team, _Period_label AS period, COUNT(*) AS cnt '
                      f'FROM tbl GROUP BY "{team_col}", _Period_label ORDER BY _Period_label', df)
            fig = px.bar(t_df, x="period", y="cnt", color="team",
                         color_discrete_sequence=COLORS, barmode="group")
            fig = chart_layout(fig,"Break Count by Team","Period","Count")
            st.plotly_chart(fig, use_container_width=True)

    # ── Top 10 Rec Names chart ──
    if rec_col and rec_col in df.columns:
        st.markdown("---")
        st.markdown("### Top 10 Rec Names — Break Count Over Periods")

        top10 = dq(f'SELECT "{rec_col}" AS rec FROM tbl '
                   f'GROUP BY "{rec_col}" ORDER BY COUNT(*) DESC LIMIT 10', df)["rec"].tolist()
        in_l  = ", ".join(f"'{str(r).replace(chr(39),chr(39)*2)}'" for r in top10)
        r_df  = dq(f'SELECT "{rec_col}" AS rec, _Period_label AS period, COUNT(*) AS cnt '
                   f'FROM tbl WHERE "{rec_col}" IN ({in_l}) '
                   f'GROUP BY "{rec_col}", _Period_label ORDER BY _Period_label', df)

        fig = px.line(r_df, x="period", y="cnt", color="rec",
                      color_discrete_sequence=COLORS, markers=True)
        fig = chart_layout(fig,"Top 10 Rec Names — Break Count Over Periods","Period","Count",
                           height=420)
        st.plotly_chart(fig, use_container_width=True)

        # ── DRILL-DOWN: user selects a Rec Name ──────────────────────────
        st.markdown("---")
        st.markdown('<div class="banner-drill">🔎 <b>Rec Name Drill-Down:</b> '
                    "Select any Rec Name to see its full granular breakdown by Period × "
                    "Team, Entity, Type of Break, and Asset Class.</div>",
                    unsafe_allow_html=True)

        all_recs = sorted(df[rec_col].dropna().unique().tolist())

        # Persist selected rec across reruns using session_state
        if "_drill_rec" not in st.session_state:
            st.session_state["_drill_rec"] = top10[0] if top10 else (all_recs[0] if all_recs else None)

        col_sel, col_btn = st.columns([4, 1])
        with col_sel:
            selected_rec = st.selectbox(
                "Select Rec Name to drill into:",
                all_recs,
                index=all_recs.index(st.session_state["_drill_rec"])
                if st.session_state["_drill_rec"] in all_recs else 0,
                key="drill_rec_sel",
            )
        with col_btn:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("🔍 Drill Down", key="drill_btn"):
                st.session_state["_drill_rec"] = selected_rec

        drill_rec = st.session_state["_drill_rec"]

        if drill_rec:
            rec_esc = str(drill_rec).replace("'","''")

            # Filter to just this rec
            rec_df = dq(f'SELECT * FROM tbl WHERE "{rec_col}" = \'{rec_esc}\'', df)
            n_rec  = len(rec_df)

            if n_rec == 0:
                st.info(f"No records found for: {drill_rec}")
            else:
                st.markdown(
                    f'<div class="drill-section">'
                    f'<b>📊 Drill-down: {drill_rec}</b> — {format_number(n_rec)} total breaks'
                    f'</div>',
                    unsafe_allow_html=True)

                # KPIs for this rec
                abs_col = col_map.get("ABS GBP") or col_map.get("BREAK AMOUNT GBP")
                dk1, dk2, dk3, dk4 = st.columns(4)
                with dk1: kpi_card("Total Breaks", format_number(n_rec))
                with dk2:
                    periods_in_rec = rec_df["_Period_label"].nunique() if "_Period_label" in rec_df.columns else 0
                    kpi_card("Periods Present", str(periods_in_rec))
                with dk3:
                    if abs_col and abs_col in rec_df.columns:
                        kpi_card("Total ABS GBP", format_short(rec_df[abs_col].sum()))
                with dk4:
                    if "_Computed_Age_Days" in rec_df.columns:
                        kpi_card("Avg Age Days",
                                 format_number(rec_df["_Computed_Age_Days"].mean(), 1))

                st.markdown("")
                # Register rec_df for DuckDB
                get_duck().register("rec_tbl", rec_df)

                # Row 1: Period breakdown + Team breakdown
                d1a, d1b = st.columns(2)

                with d1a:
                    st.markdown(f"**{drill_rec} — Break Count by Period**")
                    period_cnt = get_duck().execute(
                        "SELECT _Period_label AS period, COUNT(*) AS cnt "
                        "FROM rec_tbl GROUP BY _Period_label ORDER BY _Period_label"
                    ).df()
                    fig = go.Figure()
                    fig.add_trace(go.Bar(x=period_cnt["period"], y=period_cnt["cnt"],
                                         marker_color=COLORS[9], opacity=0.85, name="Count"))
                    fig.add_trace(go.Scatter(x=period_cnt["period"], y=period_cnt["cnt"],
                                             mode="lines+markers",
                                             line=dict(color=PRIMARY, width=2.5), name="Trend"))
                    fig = add_rolling_avg(fig, period_cnt["period"], period_cnt["cnt"])
                    fig = chart_layout(fig, f"Break Count by Period", "Period", "Count", height=320)
                    st.plotly_chart(fig, use_container_width=True)

                with d1b:
                    if team_col and team_col in rec_df.columns:
                        st.markdown(f"**{drill_rec} — Count by Period × Team**")
                        tm = get_duck().execute(
                            f'SELECT "{team_col}" AS team, _Period_label AS period, COUNT(*) AS cnt '
                            f'FROM rec_tbl GROUP BY "{team_col}", _Period_label ORDER BY _Period_label'
                        ).df()
                        fig = px.bar(tm, x="period", y="cnt", color="team",
                                     color_discrete_sequence=COLORS, barmode="stack")
                        fig = chart_layout(fig,"by Period × Team","Period","Count",height=320)
                        st.plotly_chart(fig, use_container_width=True)

                # Row 2: Entity + Type of Break
                d2a, d2b = st.columns(2)

                with d2a:
                    if entity_col and entity_col in rec_df.columns:
                        st.markdown(f"**{drill_rec} — Count by Period × Entity**")
                        en = get_duck().execute(
                            f'SELECT "{entity_col}" AS entity, _Period_label AS period, COUNT(*) AS cnt '
                            f'FROM rec_tbl GROUP BY "{entity_col}", _Period_label ORDER BY _Period_label'
                        ).df()
                        top_entities = en.groupby("entity")["cnt"].sum().nlargest(8).index.tolist()
                        en = en[en["entity"].isin(top_entities)]
                        fig = px.bar(en, x="period", y="cnt", color="entity",
                                     color_discrete_sequence=COLORS, barmode="stack")
                        fig = chart_layout(fig,"by Period × Entity (Top 8)","Period","Count",height=320)
                        st.plotly_chart(fig, use_container_width=True)

                with d2b:
                    if tob_col and tob_col in rec_df.columns:
                        st.markdown(f"**{drill_rec} — Count by Period × Type of Break**")
                        tb = get_duck().execute(
                            f'SELECT "{tob_col}" AS tob, _Period_label AS period, COUNT(*) AS cnt '
                            f'FROM rec_tbl GROUP BY "{tob_col}", _Period_label ORDER BY _Period_label'
                        ).df()
                        fig = px.bar(tb, x="period", y="cnt", color="tob",
                                     color_discrete_sequence=COLORS, barmode="stack")
                        fig = chart_layout(fig,"by Period × Type of Break","Period","Count",height=320)
                        st.plotly_chart(fig, use_container_width=True)

                # Row 3: Asset Class + Ageing
                d3a, d3b = st.columns(2)

                with d3a:
                    if ac_col and ac_col in rec_df.columns:
                        st.markdown(f"**{drill_rec} — Count by Period × Asset Class**")
                        ac = get_duck().execute(
                            f'SELECT "{ac_col}" AS ac, _Period_label AS period, COUNT(*) AS cnt '
                            f'FROM rec_tbl GROUP BY "{ac_col}", _Period_label ORDER BY _Period_label'
                        ).df()
                        fig = px.bar(ac, x="period", y="cnt", color="ac",
                                     color_discrete_sequence=COLORS, barmode="stack")
                        fig = chart_layout(fig,"by Period × Asset Class","Period","Count",height=320)
                        st.plotly_chart(fig, use_container_width=True)

                with d3b:
                    if "_Computed_Bucket" in rec_df.columns:
                        st.markdown(f"**{drill_rec} — Ageing Bucket Distribution**")
                        bk = get_duck().execute(
                            "SELECT _Computed_Bucket AS bucket, COUNT(*) AS cnt "
                            "FROM rec_tbl WHERE _Computed_Age_Days IS NOT NULL "
                            "GROUP BY _Computed_Bucket"
                        ).df()
                        bk["bucket"] = pd.Categorical(bk["bucket"],
                                                       categories=BUCKET_ORDER, ordered=True)
                        bk = bk.sort_values("bucket")
                        fig = px.bar(bk, x="bucket", y="cnt",
                                     color_discrete_sequence=[PRIMARY])
                        fig = chart_layout(fig,"Ageing Bucket Distribution","Bucket","Count",height=320)
                        st.plotly_chart(fig, use_container_width=True)

                # Raw records table
                with st.expander(f"📋 Raw Records for {drill_rec} (top 500)", expanded=False):
                    show_keys = ["Period","Team","Rec Name (as per Rec Cube)","Entity",
                                 "Type of break","Asset Class","TRADE REF",
                                 "BREAK AMOUNT GBP","ABS GBP","Age Days","Bucket","Comments"]
                    show_cols = [col_map.get(k, k) for k in show_keys
                                 if col_map.get(k, k) in rec_df.columns]
                    render_grid(rec_df[show_cols].head(500).reset_index(drop=True),
                                height=360, key="drill_raw")

                st.download_button(
                    f"📥 Download {drill_rec} Records (CSV)",
                    rec_df.to_csv(index=False).encode("utf-8"),
                    file_name=f"drill_{drill_rec[:30].replace(' ','_')}.csv",
                    mime="text/csv")

    # Remaining standard charts
    st.markdown("---")
    ce, cf = st.columns(2)
    with ce:
        if ts_col and ts_col in df.columns:
            ts_df = dq(f'SELECT "{ts_col}" AS ts, _Period_label AS period, COUNT(*) AS cnt '
                       f'FROM tbl GROUP BY "{ts_col}", _Period_label ORDER BY _Period_label', df)
            fig = px.bar(ts_df, x="period", y="cnt", color="ts",
                         color_discrete_sequence=COLORS, barmode="stack")
            fig = chart_layout(fig,"True vs Systemic Breaks","Period","Count")
            st.plotly_chart(fig, use_container_width=True)

    with cf:
        if ac_col and ac_col in df.columns:
            ac_df = dq(f'SELECT "{ac_col}" AS ac, _Period_label AS period, COUNT(*) AS cnt '
                       f'FROM tbl GROUP BY "{ac_col}", _Period_label ORDER BY _Period_label', df)
            fig = px.bar(ac_df, x="period", y="cnt", color="ac",
                         color_discrete_sequence=COLORS, barmode="stack")
            fig = chart_layout(fig,"Break Count by Asset Class","Period","Count")
            st.plotly_chart(fig, use_container_width=True)


# ════════════════════════════════════════════════════════════════
# TAB 4 — AMOUNT ANALYSIS
# ════════════════════════════════════════════════════════════════

def tab_amount_analysis(df, col_map):
    st.markdown("## Trend Analysis: Break Amounts")

    period_col = col_map.get("Period")
    abs_col    = col_map.get("ABS GBP")
    gbp_col    = col_map.get("BREAK AMOUNT GBP")
    team_col   = col_map.get("Team")
    rec_col    = col_map.get("Rec Name (as per Rec Cube)")

    if not period_col or period_col not in df.columns or "_Period_label" not in df.columns:
        st.warning("Period column not found.")
        return
    amount_col = abs_col if (abs_col and abs_col in df.columns) else gbp_col
    if not amount_col or amount_col not in df.columns:
        st.warning("No ABS GBP column found.")
        return

    period_order = sorted(df["_Period_label"].dropna().unique().tolist())
    latest = period_order[-1] if period_order else "0"
    prev   = period_order[-2] if len(period_order) >= 2 else "0"

    a = safe_amt(amount_col)
    kpi = dq(f"""
        SELECT SUM(ABS({a})) AS total, AVG(ABS({a})) AS avg, MAX(ABS({a})) AS max_v,
               SUM(ABS({a})) FILTER (WHERE _Period_label='{latest}') AS lat,
               SUM(ABS({a})) FILTER (WHERE _Period_label='{prev}')   AS prv
        FROM tbl
    """, df).iloc[0]

    mom = safe_mom_pct(float(kpi["lat"] or 0), float(kpi["prv"] or 0))
    c1, c2, c3, c4 = st.columns(4)
    with c1: kpi_card("Total ABS GBP",    format_short(kpi["total"]))
    with c2: kpi_card("Latest Period",    format_short(kpi["lat"]),
                      f"{'+'if mom and mom>0 else ''}{mom}% MoM" if mom else None,
                      invert=True, warn=(mom is not None and mom > 15))
    with c3: kpi_card("Avg Break Amount", format_short(kpi["avg"]))
    with c4: kpi_card("Max Single Break", format_short(kpi["max_v"]))

    st.markdown("---")
    ca, cb = st.columns(2)
    with ca:
        p_df = dq(f"SELECT _Period_label AS period, SUM(ABS({a})) AS total "
                  f"FROM tbl GROUP BY _Period_label ORDER BY _Period_label", df)
        p_df["label"] = p_df["total"].apply(format_short)
        fig = go.Figure()
        fig.add_trace(go.Bar(x=p_df["period"], y=p_df["total"],
                             name="Total ABS GBP", marker_color=COLORS[0], opacity=0.7,
                             text=p_df["label"], textposition="outside"))
        fig.add_trace(go.Scatter(x=p_df["period"], y=p_df["total"], name="Actual",
                                 mode="lines+markers", line=dict(color=COLORS[4], width=2)))
        fig = add_rolling_avg(fig, p_df["period"], p_df["total"])
        fig = chart_layout(fig,"Total ABS GBP by Period","Period","GBP (£)")
        if float(p_df["total"].max()) > 1e12:
            fig.update_yaxes(tickformat=".2s")
        st.plotly_chart(fig, use_container_width=True)

    with cb:
        if team_col and team_col in df.columns:
            t_df = dq(f'SELECT "{team_col}" AS team, _Period_label AS period, '
                      f'SUM(ABS({a})) AS total FROM tbl '
                      f'GROUP BY "{team_col}", _Period_label ORDER BY _Period_label', df)
            fig = px.bar(t_df, x="period", y="total", color="team",
                         color_discrete_sequence=COLORS, barmode="group")
            fig = chart_layout(fig,"ABS GBP by Team","Period","GBP (£)")
            st.plotly_chart(fig, use_container_width=True)

    if rec_col and rec_col in df.columns:
        r_df = dq(f'SELECT "{rec_col}" AS rec, SUM(ABS({a})) AS total '
                  f'FROM tbl GROUP BY "{rec_col}" ORDER BY total DESC LIMIT 10', df)
        r_df = r_df.sort_values("total", ascending=True)
        r_df["label"] = r_df["total"].apply(format_short)
        fig = px.bar(r_df, x="total", y="rec", orientation="h",
                     color_discrete_sequence=[COLORS[0]])
        fig.update_traces(text=r_df["label"], textposition="outside")
        fig = chart_layout(fig,"Top 10 Rec Names by ABS GBP","GBP (£)","",
                           height=max(300, len(r_df)*32))
        st.plotly_chart(fig, use_container_width=True)


# ════════════════════════════════════════════════════════════════
# TAB 5 — JIRA FACTOR ANALYSIS
# ════════════════════════════════════════════════════════════════

def tab_jira_factor_analysis(df, col_map):
    st.markdown("## Jira Factor Analysis")
    st.markdown('<div class="banner-jira">🔍 Identify which Jira tickets, issue descriptions, '
                "and systems drive break volumes and worst ageing.</div>", unsafe_allow_html=True)

    jira_ref_col  = col_map.get("Jira Reference")
    jira_desc_col = col_map.get("Jira Desc")
    system_col    = col_map.get("System to be Fixed")
    abs_col       = col_map.get("ABS GBP") or col_map.get("BREAK AMOUNT GBP")

    all_dims = {}
    for label, col in [
        ("Jira Reference",     jira_ref_col),
        ("Jira Description",   jira_desc_col),
        ("System to be Fixed", system_col),
        ("Issue Category",     col_map.get("ISSUE CATEGORY")),
        ("Team",               col_map.get("Team")),
        ("Rec Name",           col_map.get("Rec Name (as per Rec Cube)")),
        ("Asset Class",        col_map.get("Asset Class")),
        ("Entity",             col_map.get("Entity")),
        ("True/Systemic",      col_map.get("True/Systemic Breaks")),
    ]:
        if col and col in df.columns:
            all_dims[label] = col

    if not all_dims:
        st.info("No Jira or dimension columns found.")
        return

    sel_dim = st.selectbox("Select Factor Dimension", list(all_dims.keys()), key="jira_dim")
    dim_col = all_dims[sel_dim]
    not_null = (f'WHERE "{dim_col}" IS NOT NULL AND '
                f"TRIM(CAST(\"{dim_col}\" AS VARCHAR)) NOT IN ('','nan','None','N/A')")

    amt_c = f", SUM(ABS({safe_amt(abs_col)})) AS total_abs" if abs_col and abs_col in df.columns else ""
    age_c = (", AVG(_Computed_Age_Days) AS avg_age"
             ", COUNT(*) FILTER (WHERE _Computed_Age_Days>90) AS over_90d"
             if "_Computed_Age_Days" in df.columns else "")

    summary = dq(f'SELECT "{dim_col}" AS factor, COUNT(*) AS break_count {age_c} {amt_c} '
                 f'FROM tbl {not_null} GROUP BY "{dim_col}" ORDER BY break_count DESC', df)

    rename = {"factor":sel_dim,"break_count":"Break Count","avg_age":"Avg Age Days",
              "over_90d":"Count > 90d","total_abs":"Total ABS GBP"}
    summary = summary.rename(columns={k:v for k,v in rename.items() if k in summary.columns})
    if "Total ABS GBP" in summary.columns:
        summary["Total ABS GBP"] = summary["Total ABS GBP"].apply(format_short)
    if "Avg Age Days" in summary.columns:
        summary["Avg Age Days"] = summary["Avg Age Days"].round(1)
    render_grid(summary, height=320, key="jira_sum")

    r1a, r1b = st.columns(2)
    with r1a:
        tc = dq(f'SELECT "{dim_col}" AS factor, COUNT(*) AS cnt FROM tbl {not_null} '
                f'GROUP BY "{dim_col}" ORDER BY cnt DESC LIMIT 10', df).sort_values("cnt", ascending=True)
        fig = px.bar(tc, x="cnt", y="factor", orientation="h",
                     color_discrete_sequence=[PRIMARY])
        fig = chart_layout(fig, f"Top 10 {sel_dim} by Break Count",
                           "Break Count","",height=max(300,len(tc)*32))
        st.plotly_chart(fig, use_container_width=True)

    with r1b:
        if "_Computed_Age_Days" in df.columns:
            ta = dq(f'SELECT "{dim_col}" AS factor, AVG(_Computed_Age_Days) AS avg_age '
                    f'FROM tbl {not_null} AND _Computed_Age_Days IS NOT NULL '
                    f'GROUP BY "{dim_col}" ORDER BY avg_age DESC LIMIT 10', df).sort_values("avg_age", ascending=True)
            fig = px.bar(ta, x="avg_age", y="factor", orientation="h",
                         color_discrete_sequence=[COLORS[4]])
            fig = chart_layout(fig, f"Top 10 {sel_dim} by Avg Age Days",
                               "Avg Age Days","",height=max(300,len(ta)*32))
            st.plotly_chart(fig, use_container_width=True)

    if "_Period_label" in df.columns:
        period_order = sorted(df["_Period_label"].dropna().unique().tolist())
        if len(period_order) >= 2:
            latest = period_order[-1]
            prev   = period_order[-2]
            top5   = dq(f'SELECT "{dim_col}" AS factor FROM tbl {not_null} '
                        f'GROUP BY "{dim_col}" ORDER BY COUNT(*) DESC LIMIT 5', df)["factor"].tolist()
            t5_in  = ", ".join(f"'{str(v).replace(chr(39),chr(39)*2)}'" for v in top5)
            tr_df  = dq(f'SELECT "{dim_col}" AS factor, _Period_label AS period, COUNT(*) AS cnt '
                        f'FROM tbl WHERE "{dim_col}" IN ({t5_in}) '
                        f'GROUP BY "{dim_col}", _Period_label ORDER BY _Period_label', df)
            fig = px.line(tr_df, x="period", y="cnt", color="factor",
                          color_discrete_sequence=COLORS, markers=True)
            fig = chart_layout(fig, f"Top 5 {sel_dim} — Period Trend","Period","Count")
            st.plotly_chart(fig, use_container_width=True)


# ════════════════════════════════════════════════════════════════
# TAB 6 — STATISTICAL FALSE POSITIVE THRESHOLDING  ← NEW
# ════════════════════════════════════════════════════════════════

def tab_fp_thresholding(df, col_map):
    """
    Statistically identify False Positive candidates.

    LOGIC:
    For each segment (Rec × Team × Entity × Asset Class):
      1. Compute break count for EVERY period in the uploaded data
      2. Treat ALL periods EXCEPT the latest as "historical baseline"
      3. Compute: historical_mean, historical_MAD (median absolute deviation)
      4. Latest period count vs. historical_mean:
           deviation_pct = |latest - hist_mean| / max(hist_mean, 1) * 100
           z_score (MAD) = |latest - hist_mean| / max(hist_mad, 0.5)
      5. Classification:
           deviation_pct < fp_threshold  AND  z_score < 1.5
             → HIGH confidence FP  (systemic/recurring — not a new spike)
           deviation_pct < fp_threshold * 2
             → MEDIUM confidence FP
           Otherwise → LOW / NOT FP

    The business confirms/rejects flagged segments via data_editor.
    Confirmed FPs propagate to the global filter (sidebar toggle).
    """
    st.markdown("## Statistical False Positive Thresholding")
    st.markdown(
        '<div class="banner-warn">⚠️ <b>Concept:</b> A break is a <b>False Positive candidate</b> '
        "if its count in the <b>latest period</b> is statistically consistent with prior periods — "
        "meaning it's a <b>recurring/systemic</b> break, not a new genuine issue. "
        "Set the threshold below, review candidates, and confirm which to mark as FP.</div>",
        unsafe_allow_html=True)

    if "_Period_label" not in df.columns:
        st.warning("Period column required for FP thresholding.")
        return

    period_order = sorted(df["_Period_label"].dropna().unique().tolist())
    if len(period_order) < 2:
        st.info("Need at least 2 periods to compute FP thresholds. Upload more history.")
        return

    latest_period = period_order[-1]
    hist_periods  = period_order[:-1]

    rec_col    = col_map.get("Rec Name (as per Rec Cube)")
    team_col   = col_map.get("Team")
    entity_col = col_map.get("Entity")
    ac_col     = col_map.get("Asset Class")
    abs_col    = col_map.get("ABS GBP") or col_map.get("BREAK AMOUNT GBP")

    # Config
    st.markdown("### Configuration")
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        fp_thresh_pct = st.slider(
            "FP Threshold (% deviation from historical mean)",
            min_value=5, max_value=100, value=20, step=5,
            help="If latest period count is within this % of historical mean → FP candidate. "
                 "20% = within 20% of average is considered 'normal recurring' volume.")
    with c2:
        mad_k = st.slider(
            "MAD multiplier (k)",
            min_value=0.5, max_value=5.0, value=2.0, step=0.5,
            help="Additional guard: z-score (MAD-based) must be < k to be flagged as FP. "
                 "Higher k = more permissive (flags more as FP).")
    with c3:
        min_hist_count = st.number_input(
            "Min historical avg count (ignore tiny segments)",
            min_value=1, value=3, step=1,
            help="Segments where historical average break count is below this are ignored "
                 "(too sparse to compute meaningful threshold).")
    with c4:
        seg_dims = st.multiselect(
            "Segment dimensions",
            options=[l for l, c in [
                ("Rec Name", rec_col), ("Team", team_col),
                ("Entity", entity_col), ("Asset Class", ac_col),
            ] if c and c in df.columns],
            default=[l for l, c in [("Rec Name", rec_col), ("Team", team_col)]
                     if c and c in df.columns],
            help="Which dimensions to use for segment grouping.",
        )

    if not seg_dims:
        st.info("Select at least one segment dimension above.")
        return

    # Map label → actual column name
    dim_label_map = {
        "Rec Name":   rec_col,
        "Team":       team_col,
        "Entity":     entity_col,
        "Asset Class": ac_col,
    }
    seg_cols = [dim_label_map[l] for l in seg_dims if dim_label_map.get(l) and dim_label_map[l] in df.columns]

    if not seg_cols:
        st.info("No valid segment columns found.")
        return

    st.markdown("---")
    st.markdown(f"### Threshold Analysis — Latest period: **{latest_period}** "
                f"vs {len(hist_periods)} historical period(s): **{', '.join(hist_periods)}**")

    # ── Compute segment break counts per period via DuckDB ────────────────
    seg_expr   = ", ".join(f'"{c}"' for c in seg_cols)
    seg_labels = ", ".join(f'"{c}" AS "{c}"' for c in seg_cols)

    counts_df = dq(
        f"SELECT {seg_labels}, _Period_label AS period, COUNT(*) AS cnt "
        f"FROM tbl GROUP BY {seg_expr}, _Period_label ORDER BY {seg_expr}, _Period_label",
        df
    )

    amt_df = None
    if abs_col and abs_col in df.columns:
        amt_df = dq(
            f"SELECT {seg_labels}, _Period_label AS period, "
            f"SUM(ABS({safe_amt(abs_col)})) AS total_amt "
            f"FROM tbl GROUP BY {seg_expr}, _Period_label ORDER BY {seg_expr}, _Period_label",
            df
        )

    # ── Pivot and compute thresholds ──────────────────────────────────────
    pivot = counts_df.pivot_table(index=seg_cols, columns="period",
                                  values="cnt", fill_value=0).reset_index()

    results = []
    for _, row in pivot.iterrows():
        hist_counts = [row.get(p, 0) for p in hist_periods]
        latest_cnt  = row.get(latest_period, 0)

        hist_mean = float(np.mean(hist_counts)) if hist_counts else 0
        hist_mad  = float(np.median(np.abs(
            np.array(hist_counts, dtype=float) - hist_mean
        ))) if hist_counts else 0

        if hist_mean < min_hist_count:
            continue

        dev_pct    = abs(latest_cnt - hist_mean) / max(hist_mean, 1) * 100
        z_mad      = abs(latest_cnt - hist_mean) / max(hist_mad, 0.5)

        if dev_pct <= fp_thresh_pct and z_mad <= mad_k:
            confidence = "🟢 High"
        elif dev_pct <= fp_thresh_pct * 2:
            confidence = "🟡 Medium"
        else:
            confidence = "🔴 Low (not FP)"

        seg_info = {c: row[c] for c in seg_cols}
        seg_info.update({
            "Historical Mean":    round(hist_mean, 1),
            "Historical MAD":     round(hist_mad, 2),
            "Latest Count":       int(latest_cnt),
            "Deviation %":        round(dev_pct, 1),
            "MAD Z-Score":        round(z_mad, 2),
            "FP Confidence":      confidence,
            "Confirm as FP":      confidence in ("🟢 High",),  # pre-tick High confidence
        })

        # Add per-period counts
        for p in period_order:
            seg_info[f"Count {p}"] = int(row.get(p, 0))

        # Add latest amount
        if amt_df is not None:
            amt_row = amt_df[(amt_df["period"] == latest_period)]
            for c in seg_cols:
                amt_row = amt_row[amt_row[c] == row[c]]
            seg_info["Latest ABS GBP"] = format_short(
                float(amt_row["total_amt"].iloc[0]) if len(amt_row) else 0
            )

        results.append(seg_info)

    if not results:
        st.info("No segments meet the minimum history count. Lower the Min historical count or upload more periods.")
        return

    result_df = pd.DataFrame(results).sort_values("FP Confidence")

    # KPIs
    high_fp   = (result_df["FP Confidence"] == "🟢 High").sum()
    med_fp    = (result_df["FP Confidence"] == "🟡 Medium").sum()
    not_fp    = (result_df["FP Confidence"] == "🔴 Low (not FP)").sum()
    pre_ticked = result_df["Confirm as FP"].sum()

    k1, k2, k3, k4 = st.columns(4)
    with k1: kpi_card("Segments Analysed",    format_number(len(result_df)))
    with k2: kpi_card("High Confidence FP",   format_number(high_fp),
                      "Pre-ticked for confirmation")
    with k3: kpi_card("Medium Confidence FP", format_number(med_fp),
                      "Review manually")
    with k4: kpi_card("Not FP (New Spikes)",  format_number(not_fp))

    st.markdown("")
    st.markdown(
        '<div class="banner-fp">💡 <b>How to use:</b> Rows with '
        '<b>🟢 High</b> FP confidence are pre-ticked. Review '
        '<b>🟡 Medium</b> rows manually. Tick <b>Confirm as FP</b> then click '
        '<b>Apply FP Selections</b> below. These segments will be excluded '
        'when you enable <b>Exclude Confirmed FPs</b> in the sidebar filter.</div>',
        unsafe_allow_html=True)

    # Visualisation: FP confidence distribution
    conf_counts = result_df["FP Confidence"].value_counts().reset_index()
    conf_counts.columns = ["Confidence","Count"]
    col_vis1, col_vis2 = st.columns(2)
    with col_vis1:
        fig = px.bar(conf_counts, x="Confidence", y="Count",
                     color="Confidence",
                     color_discrete_map={"🟢 High":PRIMARY, "🟡 Medium":"#FFC553",
                                         "🔴 Low (not FP)":WARN})
        fig = chart_layout(fig,"Segment FP Confidence Distribution","","Count",height=280)
        st.plotly_chart(fig, use_container_width=True)

    with col_vis2:
        # Deviation % histogram
        fp_segs = result_df[result_df["FP Confidence"] != "🔴 Low (not FP)"]
        if len(fp_segs):
            fig = px.histogram(fp_segs, x="Deviation %", nbins=30,
                               color_discrete_sequence=[PRIMARY])
            fig = chart_layout(fig,"Deviation % Distribution (FP Candidates)",
                               "Deviation %","Count",height=280)
            st.plotly_chart(fig, use_container_width=True)

    # Editable table
    st.markdown("### Review & Confirm FP Segments")

    # Only show relevant columns in the editor
    display_cols = seg_cols + ["Historical Mean","Latest Count","Deviation %",
                               "MAD Z-Score","FP Confidence"]
    display_cols += [f"Count {p}" for p in period_order]
    if "Latest ABS GBP" in result_df.columns:
        display_cols.append("Latest ABS GBP")
    display_cols.append("Confirm as FP")
    display_cols = [c for c in display_cols if c in result_df.columns]

    edited = st.data_editor(
        result_df[display_cols].reset_index(drop=True),
        column_config={
            "Confirm as FP": st.column_config.CheckboxColumn(
                "Confirm as FP?",
                help="Tick to mark this segment as a confirmed False Positive.",
                default=False,
            ),
            "FP Confidence": st.column_config.TextColumn("FP Confidence", disabled=True),
            "Deviation %":   st.column_config.NumberColumn("Deviation %", format="%.1f%%"),
            "MAD Z-Score":   st.column_config.NumberColumn("MAD Z-Score", format="%.2f"),
        },
        use_container_width=True,
        height=min(700, max(300, len(result_df) * 36 + 60)),
        num_rows="fixed",
        key="fp_thresh_editor",
    )

    confirmed_count = int(edited["Confirm as FP"].sum())
    st.markdown(f"**{confirmed_count} segment(s) confirmed as FP** "
                f"covering an estimated "
                f"**{format_number(edited[edited['Confirm as FP']]['Latest Count'].sum())} "
                f"breaks** in {latest_period}.")

    col_apply, col_dl = st.columns(2)
    with col_apply:
        if st.button("✅ Apply FP Selections → Propagate to Global Filter",
                     key="fp_apply_btn"):
            # Store confirmed FP segment keys in session state
            confirmed_rows = edited[edited["Confirm as FP"]]
            fp_keys = []
            for _, r in confirmed_rows.iterrows():
                key = tuple(r[c] for c in seg_cols)
                fp_keys.append(key)
            st.session_state["_fp_seg_keys"]  = fp_keys
            st.session_state["_fp_seg_cols"]  = seg_cols
            st.success(
                f"✅ {len(fp_keys)} FP segments stored. "
                "Enable 'Exclude Confirmed FPs' in the sidebar to apply globally.")

    with col_dl:
        st.download_button(
            "📥 Download FP Threshold Report (CSV)",
            result_df[display_cols].to_csv(index=False).encode("utf-8"),
            file_name="fp_threshold_report.csv",
            mime="text/csv",
        )

    # Explanation box
    with st.expander("📖 Methodology — How thresholds are computed", expanded=False):
        st.markdown(f"""
**Inputs for each segment** (combination of: {', '.join(seg_dims)}):

| Term | Definition |
|------|-----------|
| Historical Periods | All periods EXCEPT the latest: {', '.join(hist_periods)} |
| Latest Period | {latest_period} |
| Historical Mean | Average break count across historical periods |
| Historical MAD | Median Absolute Deviation of historical counts (robust to outliers) |
| Deviation % | `|latest - hist_mean| / hist_mean × 100` |
| MAD Z-Score | `|latest - hist_mean| / max(hist_MAD, 0.5)` |

**Classification rules** (with current settings k={mad_k}, threshold={fp_thresh_pct}%):

| Confidence | Condition | Interpretation |
|------------|-----------|---------------|
| 🟢 High FP | Deviation % ≤ {fp_thresh_pct}% AND MAD Z ≤ {mad_k} | Systemic/recurring — consistent with history |
| 🟡 Medium FP | Deviation % ≤ {fp_thresh_pct*2}% | Possibly recurring — review manually |
| 🔴 Low (not FP) | Otherwise | New spike — likely genuine break |

**Why MAD instead of std dev?**
MAD is robust to extreme outliers. With only 2-3 periods of history, a single
anomalous period could inflate std dev massively. MAD stays stable.
        """)


# ════════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════════

def main():
    st.sidebar.markdown(f"""
    <div style="text-align:center;padding:10px 0 5px">
      <h2 style="color:{PRIMARY};margin:0">Accounting Control AI</h2>
      <p style="color:{MUTED};font-size:.8rem;margin:0">Phase 1 — Full Analytics + FP Thresholding</p>
    </div>
    """, unsafe_allow_html=True)
    st.sidebar.markdown("---")
    st.sidebar.markdown("### Upload Data")

    uploaded = st.sidebar.file_uploader(
        "CSV / Excel / Parquet",
        type=["csv","xlsx","xls","xlsm","parquet"],
        key="uploader",
    )

    if not uploaded:
        st.markdown("## 👋 Accounting Control AI Platform")
        st.markdown("""
Upload your MI Report (CSV, Excel, or Parquet) to start.

**What's new in this version:**

| Feature | Description |
|---------|-------------|
| 🔎 Rec Name Drill-Down | Click any Rec → Period × Team / Entity / Type / Asset Class breakdown |
| 📊 Statistical FP Thresholding | Tab 6: MAD-based threshold per segment to flag recurring breaks |
| ✅ Apply-button filters | Filters only apply when you click "Apply Filters" |
| ⚡ Auto Parquet cache | XLSX/CSV converted to Parquet on first load — instant reruns |
| 💰 K/M/B/T/P formatting | No more 10^16 on chart axes |
        """)
        return

    file_bytes = uploaded.read()
    filename   = uploaded.name

    result = run_pipeline(file_bytes, filename)

    df               = result["df"]
    col_map          = result["col_map"]
    filter_options   = result["filter_options"]
    violations_df    = result["violations_df"]
    dropped_cols     = result["dropped_cols"]
    filtered_for_del = result["filtered_for_del"]

    vcount   = int(violations_df["Violation Count"].sum()) if len(violations_df) else 0
    overflow = st.session_state.get("_overflow", 0)

    st.sidebar.markdown(f"**{filename}** · {len(df):,} rows · {len(df.columns)} cols")
    if filtered_for_del:
        st.sidebar.caption(f"🗑️ For Del removed: {filtered_for_del:,}")
    if vcount:
        st.sidebar.markdown(
            f'<span style="color:{WARN};font-weight:600">⚠️ {vcount} violations</span>',
            unsafe_allow_html=True)
    if overflow:
        st.sidebar.markdown(
            f'<span style="color:{WARN};font-weight:600">⚠️ {overflow} amount overflows</span>',
            unsafe_allow_html=True)

    # Apply-button filter pattern
    pending, apply_clicked = build_sidebar_filters(col_map, filter_options, df)
    if apply_clicked:
        st.session_state["_applied_filters"] = pending

    applied = st.session_state.get("_applied_filters", {})
    df_f    = apply_filters(df, col_map, applied)
    active  = f"{len(applied)} filter(s) active" if applied else "No filters"
    st.sidebar.caption(f"📊 {len(df_f):,} rows · {active}")

    # Header
    st.markdown(
        f'<h1 style="margin-bottom:0">Accounting Control AI Platform '
        f'<span style="color:{MUTED};font-size:.85rem"> · Phase 1</span></h1>'
        f'<p style="color:{MUTED};font-size:.85rem;margin:2px 0">'
        f'{len(df_f):,} rows · {active}</p>',
        unsafe_allow_html=True)

    # Tabs
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
        "🧹 Data Quality",
        "📅 Ageing Validation",
        "📈 Break Counts + Drill-Down",
        "💷 Amount Analysis",
        "🔍 Jira Factor Analysis",
        "🎯 FP Thresholding",
    ])

    with tab1:
        tab_data_quality(df_f, col_map, violations_df, dropped_cols, filtered_for_del)
    with tab2:
        tab_ageing_validation(df_f, col_map)
    with tab3:
        tab_break_counts(df_f, col_map)
    with tab4:
        tab_amount_analysis(df_f, col_map)
    with tab5:
        tab_jira_factor_analysis(df_f, col_map)
    with tab6:
        tab_fp_thresholding(df_f, col_map)


if __name__ == "__main__":
    main()
