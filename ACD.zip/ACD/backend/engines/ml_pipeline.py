import math
import json
import os
import logging
from datetime import datetime, timezone
from backend.storage import storage

logger = logging.getLogger(__name__)

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "..", "data", "models")

FEATURE_NAMES = ["breakFrequency30d", "avgAgeing", "thresholdDistance", "repeatTradeFlag", "segmentVolatility", "maturityProximityDays"]


def ensure_data_dir():
    os.makedirs(DATA_DIR, exist_ok=True)


def sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-max(-500, min(500, x))))


def extract_feature_vector(f: dict) -> list[float]:
    return [
        float(f.get("breakFrequency30d", 0) or 0),
        float(f.get("avgAgeing", 0) or 0),
        float(f.get("thresholdDistance", 0) or 0),
        float(f.get("repeatTradeFlag", 0) or 0),
        float(f.get("segmentVolatility", 0) or 0),
        float(f.get("maturityProximityDays", 999) or 999),
    ]


def _risk_signal(feature: dict) -> float:
    """Return a continuous risk score (higher = riskier).

    Uses only features that vary per-break:
      - thresholdDistance: individual break amount vs segment threshold (primary signal)
      - maturityProximityDays: urgency of maturing position
      - repeatTradeFlag: whether the same trade has broken before
    Segment-level features (avgAgeing, segmentVolatility, breakFrequency30d) are
    secondary because they're the same for every break in the same segment, which
    causes all-same-class training sets when data is homogeneous.
    """
    thresh_dist   = float(feature.get("thresholdDistance", 0) or 0)
    maturity      = int(feature.get("maturityProximityDays", 999) or 999)
    repeat        = int(feature.get("repeatTradeFlag", 0) or 0)
    ageing        = float(feature.get("avgAgeing", 0) or 0)
    volatility    = float(feature.get("segmentVolatility", 0) or 0)
    freq          = float(feature.get("breakFrequency30d", 0) or 0)

    score = 0.0
    score += min(thresh_dist, 2.0) * 40          # 0-80 pts: threshold proximity (primary)
    score += max(0.0, 1.0 - maturity / 365.0) * 15  # 0-15 pts: maturity urgency
    score += repeat * 10                           # 0-10 pts: repeat occurrence
    score += min(ageing / 365.0, 1.0) * 10        # 0-10 pts: segment age
    score += min(volatility / 1_000_000, 1.0) * 5 # 0-5 pts: volatility
    score += min(freq / 10.0, 1.0) * 5            # 0-5 pts: break frequency
    return score


def derive_label(feature: dict) -> int:
    """Legacy single-sample label — only used when a global median is unavailable."""
    thresh_dist = float(feature.get("thresholdDistance", 0) or 0)
    maturity    = int(feature.get("maturityProximityDays", 999) or 999)
    repeat      = int(feature.get("repeatTradeFlag", 0) or 0)
    ageing      = float(feature.get("avgAgeing", 0) or 0)

    if thresh_dist >= 1.0:
        return 1
    if maturity < 14 and thresh_dist > 0.5:
        return 1

    risk_signals = 0
    if thresh_dist > 0.7:
        risk_signals += 2
    elif thresh_dist > 0.4:
        risk_signals += 1
    if repeat > 0:
        risk_signals += 1
    if ageing > 180:
        risk_signals += 1
    if maturity < 60:
        risk_signals += 1

    return 1 if risk_signals >= 3 else 0


def train_gradient_boosted_model(features, labels, iterations=100, learning_rate=0.05):
    n = len(features)
    if n == 0:
        return {"trees": [], "featureNames": FEATURE_NAMES, "learningRate": learning_rate, "baseScore": 0}

    pos_count = sum(labels)
    base_score = math.log((pos_count + 1) / (n - pos_count + 1))
    predictions = [base_score] * n
    trees = []
    num_features = len(features[0])

    for _ in range(iterations):
        residuals = [labels[i] - sigmoid(predictions[i]) for i in range(n)]

        best_gain = -float("inf")
        best_feature = 0
        best_threshold = 0.0
        best_left_val = 0.0
        best_right_val = 0.0

        for f_idx in range(num_features):
            feature_values = [row[f_idx] for row in features]
            sorted_unique = sorted(set(feature_values))
            if len(sorted_unique) > 10:
                step = max(1, len(sorted_unique) // 10)
                thresholds = sorted_unique[::step]
            else:
                thresholds = sorted_unique

            for thresh in thresholds:
                left_sum = left_count = right_sum = right_count = 0.0
                for i in range(n):
                    if features[i][f_idx] <= thresh:
                        left_sum += residuals[i]
                        left_count += 1
                    else:
                        right_sum += residuals[i]
                        right_count += 1

                if left_count == 0 or right_count == 0:
                    continue

                left_mean = left_sum / left_count
                right_mean = right_sum / right_count
                gain = left_sum * left_mean + right_sum * right_mean

                if gain > best_gain:
                    best_gain = gain
                    best_feature = f_idx
                    best_threshold = thresh
                    best_left_val = left_mean
                    best_right_val = right_mean

        trees.append({
            "featureIndex": best_feature,
            "threshold": best_threshold,
            "leftValue": best_left_val,
            "rightValue": best_right_val,
        })

        for i in range(n):
            val = best_left_val if features[i][best_feature] <= best_threshold else best_right_val
            predictions[i] += learning_rate * val

    return {
        "trees": trees,
        "featureNames": FEATURE_NAMES,
        "learningRate": learning_rate,
        "baseScore": base_score,
    }


def predict(model: dict, features: list[float]) -> float:
    score = model["baseScore"]
    for tree in model["trees"]:
        val = tree["leftValue"] if features[tree["featureIndex"]] <= tree["threshold"] else tree["rightValue"]
        score += model["learningRate"] * val
    return sigmoid(score)


def compute_feature_importance(model: dict, features: list[float]) -> dict:
    contributions = {name: 0.0 for name in FEATURE_NAMES}
    lr = model.get("learningRate", 0.05)

    for tree in model.get("trees", []):
        f_idx = tree["featureIndex"]
        val = tree["leftValue"] if features[f_idx] <= tree["threshold"] else tree["rightValue"]
        if f_idx < len(FEATURE_NAMES):
            contributions[FEATURE_NAMES[f_idx]] += abs(lr * val)

    total = sum(contributions.values())
    if total > 0:
        return {k: round(v / total * 100, 1) for k, v in contributions.items()}
    equal_share = round(100 / len(FEATURE_NAMES), 1)
    return {k: equal_share for k in FEATURE_NAMES}


def compute_auc(probs: list[float], labels: list[int]) -> float:
    pairs = sorted(zip(probs, labels), key=lambda x: -x[0])
    total_pos = sum(labels)
    total_neg = len(labels) - total_pos
    if total_pos == 0 or total_neg == 0:
        return 0.5

    tp = fp = 0
    auc = 0.0
    prev_fpr = 0.0

    for prob, label in pairs:
        if label == 1:
            tp += 1
        else:
            fp += 1
            tpr = tp / total_pos
            fpr = fp / total_neg
            auc += tpr * (fpr - prev_fpr)
            prev_fpr = fpr

    return min(1.0, max(0.0, auc))


def train_catboost_model(X_train, y_train, X_val, y_val):
    from catboost import CatBoostClassifier
    model = CatBoostClassifier(
        iterations=200,
        learning_rate=0.05,
        depth=4,
        loss_function="Logloss",
        eval_metric="AUC",
        class_weights=[1, 2],
        random_seed=42,
        verbose=0,
    )
    # use_best_model requires both classes in the eval set to compute AUC;
    # fall back to training without early stopping when val set is single-class
    val_has_both_classes = len(set(y_val)) > 1
    if val_has_both_classes:
        model.fit(X_train, y_train, eval_set=(X_val, y_val), use_best_model=True)
    else:
        model.fit(X_train, y_train)
    val_probs = [float(p[1]) for p in model.predict_proba(X_val)]
    val_binary = [1 if p > 0.5 else 0 for p in val_probs]
    correct = sum(1 for p, l in zip(val_binary, y_val) if p == l)
    accuracy = correct / len(y_val) if y_val else 0.0
    auc = compute_auc(val_probs, y_val)
    return model, val_probs, auc, accuracy


def catboost_feature_importance(model) -> dict:
    raw = model.get_feature_importance()
    total = sum(raw)
    if total > 0:
        return {FEATURE_NAMES[i]: round(float(raw[i]) / total * 100, 1) for i in range(min(len(FEATURE_NAMES), len(raw)))}
    equal = round(100 / len(FEATURE_NAMES), 1)
    return {k: equal for k in FEATURE_NAMES}


def predict_catboost(model_path: str, feature_vector: list[float]) -> float:
    from catboost import CatBoostClassifier
    model = CatBoostClassifier()
    model.load_model(model_path)
    probs = model.predict_proba([feature_vector])
    return float(probs[0][1])


def train_model() -> dict:
    all_features = storage.ml_features.get_all()

    if len(all_features) < 5:
        raise ValueError("Insufficient data for training. Need at least 5 samples with features.")

    feature_vectors = [extract_feature_vector(f) for f in all_features]

    # Median-based binarization: always produces ~50/50 class balance regardless of
    # how homogeneous the dataset is. Uses _risk_signal (continuous) then splits at median.
    raw_scores = [_risk_signal(f) for f in all_features]
    sorted_scores = sorted(raw_scores)
    median_score = sorted_scores[len(sorted_scores) // 2]
    # Avoid all-same-class when all scores are identical
    if sorted_scores[0] == sorted_scores[-1]:
        labels = [i % 2 for i in range(len(all_features))]
    else:
        labels = [1 if s > median_score else 0 for s in raw_scores]
    # Ensure at least one of each class exists
    if sum(labels) == 0:
        labels[0] = 1
    if sum(labels) == len(labels):
        labels[-1] = 0

    import random

    # Stratified split: ensure both classes appear in train and val when possible
    pos_idx = [i for i, l in enumerate(labels) if l == 1]
    neg_idx = [i for i, l in enumerate(labels) if l == 0]
    random.shuffle(pos_idx)
    random.shuffle(neg_idx)

    def _split_class(idx_list, ratio=0.8):
        cut = max(1, int(len(idx_list) * ratio))
        return idx_list[:cut], idx_list[cut:]

    if pos_idx and neg_idx:
        pos_train, pos_val = _split_class(pos_idx)
        neg_train, neg_val = _split_class(neg_idx)
        train_idx = pos_train + neg_train
        val_idx   = pos_val   + neg_val
        random.shuffle(train_idx)
        random.shuffle(val_idx)
    else:
        indices = list(range(len(feature_vectors)))
        random.shuffle(indices)
        split_idx = max(1, int(len(indices) * 0.8))
        train_idx = indices[:split_idx]
        val_idx   = indices[split_idx:]

    train_features = [feature_vectors[i] for i in train_idx]
    train_labels   = [labels[i]          for i in train_idx]
    val_features   = [feature_vectors[i] for i in val_idx]
    val_labels     = [labels[i]          for i in val_idx]

    if not val_features:
        val_features = train_features[-1:]
        val_labels   = train_labels[-1:]

    gbt_model = train_gradient_boosted_model(train_features, train_labels, 100, 0.05)
    gbt_probs = [predict(gbt_model, f) for f in val_features]
    gbt_binary = [1 if p > 0.5 else 0 for p in gbt_probs]
    gbt_correct = sum(1 for p, l in zip(gbt_binary, val_labels) if p == l)
    gbt_accuracy = gbt_correct / len(val_labels) if val_labels else 0.0
    gbt_auc = compute_auc(gbt_probs, val_labels)

    catboost_auc = 0.0
    catboost_accuracy = 0.0
    catboost_model = None
    try:
        catboost_model, _, catboost_auc, catboost_accuracy = train_catboost_model(
            train_features, train_labels, val_features, val_labels
        )
    except Exception as cb_err:
        logger.warning("CatBoost training failed, falling back to GBT: %s", cb_err)

    if catboost_model is not None and catboost_auc >= gbt_auc:
        winner = "catboost"
        auc_roc = catboost_auc
        accuracy = catboost_accuracy
    else:
        winner = "gbt"
        auc_roc = gbt_auc
        accuracy = gbt_accuracy

    existing_models = storage.models.get_all()
    next_version = len(existing_models) + 1
    ensure_data_dir()

    if winner == "catboost":
        cb_path = os.path.join(DATA_DIR, f"catboost_v{next_version}.cbm")
        catboost_model.save_model(cb_path)
        saved = storage.models.insert({
            "name": "CatBoost Risk Classifier",
            "version": f"{next_version}.0.0",
            "status": "ready",
            "modelType": "catboost",
            "accuracy": f"{accuracy:.4f}",
            "auc": f"{auc_roc:.4f}",
            "aucRoc": f"{auc_roc:.4f}",
            "trainSamples": len(train_features),
            "validationSamples": len(val_features),
            "modelPath": cb_path,
            "trainedAt": datetime.now(timezone.utc).isoformat(),
        })
    else:
        gbt_path = os.path.join(DATA_DIR, f"model_v{next_version}.json")
        with open(gbt_path, "w") as f:
            json.dump(gbt_model, f)
        saved = storage.models.insert({
            "name": "GBT Risk Classifier",
            "version": f"{next_version}.0.0",
            "status": "ready",
            "modelType": "gbt",
            "accuracy": f"{accuracy:.4f}",
            "auc": f"{auc_roc:.4f}",
            "aucRoc": f"{auc_roc:.4f}",
            "trainSamples": len(train_features),
            "validationSamples": len(val_features),
            "weights": gbt_model,
            "trainedAt": datetime.now(timezone.utc).isoformat(),
        })

    storage.audit_log.insert({
        "action": "MODEL_TRAINED",
        "entity": "models",
        "entityId": str(saved["id"]),
        "details": {
            "winner": winner,
            "aucRoc": auc_roc,
            "accuracy": accuracy,
            "gbtAuc": round(gbt_auc, 4),
            "catboostAuc": round(catboost_auc, 4),
            "trainSamples": len(train_features),
            "validationSamples": len(val_features),
            "version": saved["version"],
        },
    })

    return {
        "modelId": saved["id"],
        "winner": winner,
        "aucRoc": auc_roc,
        "accuracy": accuracy,
        "gbtAuc": round(gbt_auc, 4),
        "gbtAccuracy": round(gbt_accuracy, 4),
        "catboostAuc": round(catboost_auc, 4),
        "catboostAccuracy": round(catboost_accuracy, 4),
        "trainSamples": len(train_features),
        "validationSamples": len(val_features),
        "version": saved["version"],
    }


def _compute_severity(probability: float, feature: dict) -> tuple[float, str]:
    signal = _risk_signal(feature) if feature else 0.0
    risk_score = round(probability * 100, 2)
    severity = "High" if signal >= 30 else "Medium" if signal >= 15 else "Low"
    return risk_score, severity


def run_inference() -> dict:
    all_models = storage.models.get_all()
    ready_models = [m for m in all_models if m.get("status") == "ready"]
    if not ready_models:
        return {"scored": 0}

    latest_model = max(ready_models, key=lambda m: m["createdAt"])
    model_type = latest_model.get("modelType", "gbt")

    cb_model = None
    global_importance = {}
    trained_model = None

    if model_type == "catboost":
        model_path = latest_model.get("modelPath")
        if not model_path or not os.path.exists(model_path):
            return {"scored": 0}
        try:
            from catboost import CatBoostClassifier
            cb_model = CatBoostClassifier()
            cb_model.load_model(model_path)
            global_importance = catboost_feature_importance(cb_model)
        except Exception as cb_err:
            logger.error("CatBoost inference load failed: %s", cb_err)
            return {"scored": 0}
    else:
        trained_model = latest_model.get("weights")
        if not trained_model:
            return {"scored": 0}

    all_features = storage.ml_features.get_all()
    existing_preds = storage.ml_predictions.get_all()
    scored_ids = {p["cleanBreakId"] for p in existing_preds}

    unscored = [f for f in all_features if f["cleanBreakId"] not in scored_ids]
    if not unscored:
        return {"scored": 0}

    predictions = []
    for feature in unscored:
        vector = extract_feature_vector(feature)

        if model_type == "catboost" and cb_model is not None:
            probs = cb_model.predict_proba([vector])
            probability = float(probs[0][1])
            importance = global_importance
        else:
            probability = predict(trained_model, vector)
            importance = compute_feature_importance(trained_model, vector)

        risk_score, severity = _compute_severity(probability, feature)

        predictions.append({
            "cleanBreakId": feature["cleanBreakId"],
            "tradeId": feature["tradeId"],
            "modelId": latest_model["id"],
            "probability": f"{probability:.4f}",
            "riskScore": f"{risk_score:.2f}",
            "severity": severity,
            "featureImportance": importance,
            "predictedAt": datetime.now(timezone.utc).isoformat(),
        })

    if predictions:
        storage.ml_predictions.insert_many(predictions)

    storage.audit_log.insert({
        "action": "ML_INFERENCE_COMPLETE",
        "entity": "ml_predictions",
        "details": {"scored": len(predictions), "modelVersion": latest_model["version"], "modelType": model_type},
    })

    return {"scored": len(predictions)}


def find_historical_matches(target_feature: dict, all_features: list[dict], pred_lookup: dict, clean_break_map: dict, top_k: int = 5, exclude_batch_id: str = None) -> list[dict]:
    seen = set()
    same_segment = []
    for f in all_features:
        if f["segmentKey"] != target_feature["segmentKey"]:
            continue
        if f["cleanBreakId"] == target_feature["cleanBreakId"]:
            continue
        if f["cleanBreakId"] in seen:
            continue
        if exclude_batch_id:
            candidate_break = clean_break_map.get(f["cleanBreakId"], {})
            if candidate_break.get("batchId") == exclude_batch_id:
                continue
        seen.add(f["cleanBreakId"])
        same_segment.append(f)

    if not same_segment:
        return []

    target_vec = extract_feature_vector(target_feature)
    candidate_vecs = [extract_feature_vector(f) for f in same_segment]
    all_vecs = [target_vec] + candidate_vecs

    dims = len(target_vec)
    mins = [float("inf")] * dims
    maxs = [float("-inf")] * dims
    for v in all_vecs:
        for d in range(dims):
            if v[d] < mins[d]:
                mins[d] = v[d]
            if v[d] > maxs[d]:
                maxs[d] = v[d]

    def normalize(v):
        return [(v[d] - mins[d]) / (maxs[d] - mins[d]) if maxs[d] - mins[d] > 0 else 0 for d in range(dims)]

    norm_target = normalize(target_vec)
    norm_candidates = [normalize(cv) for cv in candidate_vecs]

    distances = []
    for i, f in enumerate(same_segment):
        sq_diffs = [(norm_target[d] - norm_candidates[i][d]) ** 2 for d in range(dims)]
        dist = math.sqrt(sum(sq_diffs))
        distances.append((f, dist, sq_diffs))

    distances.sort(key=lambda x: x[1])

    max_dist = math.sqrt(dims)
    results = []
    for f, dist, sq_diffs in distances[:top_k]:
        similarity = max(0, min(100, (1 - dist / max_dist) * 100))
        pred = pred_lookup.get(f["cleanBreakId"])
        cb = clean_break_map.get(f["cleanBreakId"])

        total_sq = sum(sq_diffs)
        if total_sq > 0:
            feature_contributions = {}
            for d in range(dims):
                closeness_pct = round((1 - sq_diffs[d] / total_sq) / (dims - 1) * 100, 1) if dims > 1 else 100.0
                feature_contributions[FEATURE_NAMES[d]] = max(0, closeness_pct)
            contrib_total = sum(feature_contributions.values())
            if contrib_total > 0:
                feature_contributions = {k: round(v / contrib_total * 100, 1) for k, v in feature_contributions.items()}
        else:
            equal = round(100 / dims, 1)
            feature_contributions = {name: equal for name in FEATURE_NAMES}

        results.append({
            "tradeId": f["tradeId"],
            "cleanBreakId": f["cleanBreakId"],
            "segmentKey": f["segmentKey"],
            "amountGbp": cb.get("amountGbp", "0") if cb else "0",
            "ageingDays": cb.get("computedAgeingDays", 0) if cb else 0,
            "severity": pred.get("severity") if pred else None,
            "riskScore": pred.get("riskScore") if pred else None,
            "similarity": round(similarity, 1),
            "jiraId": cb.get("jiraId") if cb else None,
            "recName": cb.get("recName", "") if cb else "",
            "entity": cb.get("entity", "") if cb else "",
            "assetClass": cb.get("assetClass", "") if cb else "",
            "accountGroup": cb.get("accountGroup", "") if cb else "",
            "startDate": cb.get("startDate", "") if cb else "",
            "ageingBucket": cb.get("derivedAgeingBucket") or (cb.get("ageingBucket", "") if cb else ""),
            "featureContributions": feature_contributions,
        })

    return results


def get_analysis_with_matches() -> list[dict]:
    breaks = storage.clean_breaks.get_all(limit=500, order_desc="createdAt")
    all_breaks = storage.clean_breaks.get_all()
    features = storage.ml_features.get_all()
    preds = storage.ml_predictions.get_all()

    feature_map = {f["cleanBreakId"]: f for f in features}
    pred_map = {p["cleanBreakId"]: p for p in preds}
    clean_break_map = {b["id"]: b for b in all_breaks}
    pred_lookup = {p["cleanBreakId"]: {"severity": p.get("severity", "Unknown"), "riskScore": p.get("riskScore", "0")} for p in preds}

    valid_features = [f for f in features if f["cleanBreakId"] in clean_break_map]

    analysis = []
    for b in breaks:
        feature = feature_map.get(b["id"])
        prediction = pred_map.get(b["id"])
        historical_matches = []

        if feature:
            historical_matches = find_historical_matches(feature, valid_features, pred_lookup, clean_break_map, 5, exclude_batch_id=b.get("batchId"))

        entry = dict(b)

        entry["ageingDays"] = b.get("computedAgeingDays")
        entry["ageingBucket"] = b.get("derivedAgeingBucket")
        entry["correctedFlag"] = b.get("correctionFlag", False)
        entry["breakAmount"] = b.get("amountGbp")

        if prediction:
            stored_prob = float(prediction.get("probability") or 0)
            risk_score, severity = _compute_severity(stored_prob, feature or {})
            entry["riskScore"] = f"{risk_score:.2f}"
            entry["severity"] = severity
            entry["probability"] = prediction.get("probability")
            entry["featureImportance"] = prediction.get("featureImportance", {})
        else:
            entry["riskScore"] = None
            entry["severity"] = "Unscored"
            entry["probability"] = None
            entry["featureImportance"] = {}

        if feature:
            ml_feats = {}
            for fn in FEATURE_NAMES:
                ml_feats[fn] = feature.get(fn)
            entry["mlFeatures"] = ml_feats
        else:
            entry["mlFeatures"] = {}

        entry["historicalMatchCount"] = len(historical_matches)
        entry["features"] = feature
        entry["prediction"] = prediction
        entry["historicalMatches"] = historical_matches
        analysis.append(entry)

    return analysis
