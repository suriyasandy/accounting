#!/bin/bash
set -e

# Resolve project root (works on Replit and locally)
PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"

# Ensure model directory exists (gitignored, so missing after fresh clone)
mkdir -p "$PROJECT_ROOT/data/models"

# Start FastAPI backend on port 8000
PYTHONPATH="$PROJECT_ROOT" python -m uvicorn backend.main:app \
  --host 0.0.0.0 --port 8000 --log-level info &
FASTAPI_PID=$!

# Give FastAPI a moment to bind before Dash starts
sleep 2

# Start Dash frontend on port 5000
PYTHONPATH="$PROJECT_ROOT" python "$PROJECT_ROOT/dash_app/app.py" &
DASH_PID=$!

trap "kill $FASTAPI_PID $DASH_PID 2>/dev/null; exit 0" EXIT INT TERM

wait
