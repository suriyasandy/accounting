# RICP — Reconciliation Risk State Engine

## Overview
Full end-to-end reconciliation risk platform for financial/banking operations. Implements deterministic data quality checks, robust statistical threshold computation, EWMA trend/drift detection, ML feature engineering, gradient-boosted decision tree model training/inference, and intelligent historical linkage with feature importance.

## Architecture
- **Frontend**: Dash (port 5000) — dash-ag-grid tables, Plotly charts, dark fintech theme, real URL routing
- **Backend**: FastAPI (Python) on port 8000 — 13 routes, 8-step pipeline, in-memory storage
- **Storage**: In-memory Python data store — thread-safe with auto-increment IDs
- **ML**: Python gradient-boosted decision stumps (numpy-based)
- **Model Weights**: JSON files saved to `data/models/` at runtime
- **Communication**: Dash callbacks call FastAPI directly via `requests` (no proxy)
- **Startup**: `bash start.sh` — launches uvicorn (FastAPI, port 8000) then Dash (port 5000)

## Running Locally

**Requirements**: Python 3.11+

```bash
# 1. Clone the repo and enter the directory
git clone <repo-url>
cd ricp

# 2. Install all dependencies
pip install scikit-learn catboost fastapi uvicorn numpy pandas plotly python-multipart requests \
            dash dash-bootstrap-components dash-ag-grid

# 3. Start both servers (FastAPI + Dash) with one command
bash start.sh

# 4. Open in browser
#    Dash UI:       http://localhost:5000
#    FastAPI docs:  http://localhost:8000/docs
```

`start.sh` handles everything automatically:
- Resolves the project root using `$(pwd)` — works on any machine, not just Replit
- Creates `data/models/` if it doesn't exist (needed after a fresh git clone)
- Sets `PYTHONPATH` correctly so all Python imports resolve
- Starts FastAPI on port 8000, then Dash on port 5000
- Cleans up both processes on exit (Ctrl+C)

## Dash App Structure
```
dash_app/
├── app.py              # Entry point: Dash(use_pages=True), sidebar nav, page_container
├── api.py              # Requests wrapper for all FastAPI routes
├── assets/
│   └── custom.css      # Dark fintech CSS (#0f1117 bg, #4f8ef7 accent, card/badge styles)
└── pages/
    ├── dashboard.py    # / — KPI cards, ageing bar, severity donut, threshold comparison
    ├── upload.py       # /upload — dcc.Upload, AG Grid preview, 8-step pipeline progress
    ├── analysis.py     # /analysis — AG Grid + row-click detail: features, importance, historical linkage
    ├── segments.py     # /segments — threshold cards, EWMA area+line trend chart
    ├── training.py     # /training — upload historical data, train model, version history AG Grid
    └── audit.py        # /audit — AG Grid with color-coded action column
```

## In-Memory Tables (backend/storage.py)
1. `raw_breaks` — untouched ingested break file data
2. `clean_breaks` — validated/corrected breaks with derived ageing
3. `segment_stats` — per-segment threshold computations (Median + MAD)
4. `trend_metrics` — monthly EWMA series, drift values per segment
5. `ml_features` — 6 engineered features per break
6. `ml_predictions` — model inference results with severity scoring + feature importance
7. `models` — ML model registry with weights stored as JSON
8. `pipeline_runs` — batch execution tracking (8-step pipeline)
9. `recon_health` — summary health snapshots
10. `audit_log` — governance/compliance trail

## Python Backend Files
- `backend/main.py` — FastAPI app entry with CORS
- `backend/storage.py` — Thread-safe in-memory Table class with CRUD helpers
- `backend/routes.py` — All API route handlers (13 routes)
- `backend/engines/data_quality.py` — ageing recalculation, correction flagging
- `backend/engines/threshold.py` — Median + MAD robust statistics
- `backend/engines/trend.py` — EWMA (α=0.3) drift detection
- `backend/engines/features.py` — 6 ML features per break
- `backend/engines/ml_pipeline.py` — gradient-boosted trees, training, inference, historical matching, feature importance
- `backend/engines/pipeline.py` — 8-step DAG orchestrator

## API Routes (all return 200)
- `POST /api/upload/breaks` — upload break CSV, triggers full 8-step pipeline
- `POST /api/upload/training-data` — upload historical data for ML training
- `GET /api/pipeline/{batchId}/status` — pipeline run status
- `GET /api/pipeline/runs` — list recent pipeline runs
- `GET /api/breaks/clean` — clean breaks (limit 500)
- `GET /api/breaks/analysis` — clean breaks with features + predictions + historical matches (top-5)
- `POST /api/models/train` — train new ML model
- `GET /api/models` — model registry
- `GET /api/segments/stats` — segment threshold computations
- `GET /api/segments/trends` — EWMA trend data
- `GET /api/reconciliation/health` — latest health snapshot
- `GET /api/audit-log` — governance trail

## Dash Pages
- **Dashboard** (`/`): Health status badge, 4 KPI cards, dimension filters, ageing bucket bar, severity donut, segment threshold grouped bar, info cards (segment health, ML model, pipeline)
- **Upload** (`/upload`): CSV drag-and-drop, 10-row preview in AG Grid, 8-step pipeline progress with pass/fail indicators
- **Analysis** (`/analysis`): AG Grid with filters + search, row click → detail panel (6-feature bars, prediction importance bars, up to 5 historical match cards with similarity % and feature contribution mini-bars)
- **Segments** (`/segments`): KPI cards, tabbed view — Thresholds tab (card grid per segment) and EWMA tab (area + dashed EWMA line + drift markers, segment dropdown)
- **ML Training** (`/training`): Upload historical CSV, Train Model button → AUC/Accuracy/sample metrics, model version history AG Grid
- **Audit Log** (`/audit`): KPI cards, AG Grid with color-coded action column (UPLOAD/PIPELINE/TRAIN/SCORE/DELETE)

## Intelligent Historical Linkage
- `find_historical_matches()`: Euclidean distance on min-max normalized 6-feature vectors within same segment, returns top-5 with similarity %, full break metadata (jiraId, tradeId, recName, entity, assetClass, accountGroup, startDate, ageingBucket), and per-feature contribution to similarity
- Each historical match includes `featureContributions` — which features drove the similarity

## ML Feature Importance
- `compute_feature_importance()`: tracks per-feature contribution to prediction score
- Displayed as horizontal bars in analysis row detail, sorted by importance

## Key Formulas
- **Threshold**: material = median + 4 × robust_sigma, early_warning = median + 2 × robust_sigma
- **Robust Sigma**: 1.4826 × MAD (Median Absolute Deviation)
- **EWMA**: α=0.3; segment deteriorates when drift > 1.5 × std deviation
- **Risk Score**: probability × 100 × severity_weight (0.6×prob + 0.4×amount_factor)
- **Similarity**: (1 - euclidean_dist / sqrt(6)) × 100, on min-max normalized 6-feature vectors
- **Feature Contribution**: per-dimension squared difference as proportion of total squared distance
