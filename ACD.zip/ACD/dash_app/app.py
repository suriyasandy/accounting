import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import dash
from dash import Dash, html, dcc
import dash_bootstrap_components as dbc

app = Dash(
    __name__,
    use_pages=True,
    external_stylesheets=[dbc.themes.DARKLY],
    suppress_callback_exceptions=True,
    title="RICP — Reconciliation Risk State Engine",
    pages_folder=os.path.join(os.path.dirname(__file__), "pages"),
)

_nav_items = [
    ("📊", "Dashboard",  "/"),
    ("📁", "Upload",     "/upload"),
    ("🔍", "Analysis",   "/analysis"),
    ("📈", "Segments",   "/segments"),
    ("🤖", "ML Training","/training"),
    ("📋", "Audit Log",  "/audit"),
]

_sidebar = html.Div(
    [
        html.Div(
            [
                html.Div(
                    "RICP",
                    style={
                        "fontSize": "20px",
                        "fontWeight": "900",
                        "color": "#4f8ef7",
                        "letterSpacing": "2px",
                    },
                ),
                html.Div(
                    "Reconciliation Risk Engine",
                    style={"fontSize": "10px", "color": "#475569", "marginTop": "2px"},
                ),
            ],
            style={"padding": "20px 16px 28px 16px"},
        ),
        dbc.Nav(
            [
                dbc.NavLink(
                    [html.Span(icon + " ", style={"width": "20px"}), label],
                    href=href,
                    active="exact",
                    className="sidebar-link",
                    id=f"nav-{label.lower().replace(' ', '-')}",
                )
                for icon, label, href in _nav_items
            ],
            vertical=True,
            pills=False,
        ),
        html.Hr(style={"borderColor": "#1e293b", "margin": "24px 8px 16px 8px"}),
        html.Div(
            [
                html.Div("FastAPI · Dash · AG Grid", style={"fontSize": "10px", "color": "#334155"}),
                html.Div("Port 8000 → 5000", style={"fontSize": "10px", "color": "#334155", "marginTop": "2px"}),
            ],
            style={"textAlign": "center", "padding": "0 12px"},
        ),
    ],
    style={
        "width": "210px",
        "background": "#0d1117",
        "height": "100vh",
        "position": "fixed",
        "top": "0",
        "left": "0",
        "borderRight": "1px solid #1e293b",
        "overflowY": "auto",
        "zIndex": "1000",
    },
)

app.layout = html.Div(
    [
        _sidebar,
        html.Div(
            dash.page_container,
            style={
                "marginLeft": "210px",
                "padding": "28px 32px",
                "minHeight": "100vh",
                "background": "#0f1117",
            },
        ),
    ],
    style={"background": "#0f1117"},
)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
