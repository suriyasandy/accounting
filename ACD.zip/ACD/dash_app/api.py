import requests

BASE_URL = "http://localhost:8000"


def _get(path: str, default=None):
    try:
        r = requests.get(f"{BASE_URL}{path}", timeout=30)
        r.raise_for_status()
        return r.json()
    except requests.exceptions.ConnectionError:
        print(f"API connection error on {path}: FastAPI not reachable on port 8000")
        return default if default is not None else []
    except Exception as e:
        print(f"API error on {path}: {e}")
        return default if default is not None else []


def _post(path: str, data: dict = None):
    """
    Returns (result_dict, error_message).
    On success: (payload, None)
    On HTTP error: (None, human-readable message from the API)
    On connection error: (None, connection message)
    """
    try:
        r = requests.post(f"{BASE_URL}{path}", json=data or {}, timeout=120)
        if not r.ok:
            try:
                body = r.json()
                msg = body.get("message") or body.get("detail") or r.text
            except Exception:
                msg = r.text or f"HTTP {r.status_code}"
            print(f"API {r.status_code} on {path}: {msg}")
            return None, msg
        return r.json(), None
    except requests.exceptions.ConnectionError:
        msg = "Cannot reach the API backend (port 8000). Check that FastAPI is running."
        print(f"API connection error on {path}: {msg}")
        return None, msg
    except Exception as e:
        print(f"API error on {path}: {e}")
        return None, str(e)


def get_health() -> dict:
    return _get("/api/reconciliation/health", {})


def get_analysis() -> list:
    return _get("/api/breaks/analysis", [])


def get_clean_breaks() -> list:
    return _get("/api/breaks/clean", [])


def get_segment_stats() -> list:
    return _get("/api/segments/stats", [])


def get_segment_trends() -> list:
    return _get("/api/segments/trends", [])


def get_models() -> list:
    return _get("/api/models", [])


def get_pipeline_runs() -> list:
    return _get("/api/pipeline/runs", [])


def get_audit_log() -> list:
    return _get("/api/audit-log", [])


def upload_breaks(rows: list):
    return _post("/api/upload/breaks", {"rows": rows})


def upload_training_data(rows: list):
    return _post("/api/upload/training-data", {"rows": rows})


def train_model():
    return _post("/api/models/train", {})
