import base64
import io
import csv

import dash
from dash import html, dcc, callback, Output, Input, State, no_update
import dash_bootstrap_components as dbc
import dash_ag_grid as dag

dash.register_page(__name__, path="/training", name="ML Training", order=4)

_history_cols = [
    {"field": "version",    "headerName": "Ver",        "width": 65},
    {"field": "name",       "headerName": "Model Name", "flex": 1, "minWidth": 140},
    {
        "field": "modelType",
        "headerName": "Type",
        "width": 100,
        "cellStyle": {
            "styleConditions": [
                {"condition": "params.value === 'catboost'", "style": {"color": "#fbbf24", "fontWeight": "700"}},
                {"condition": "params.value === 'gbt'",      "style": {"color": "#4f8ef7", "fontWeight": "700"}},
            ],
            "defaultStyle": {"color": "#94a3b8"},
        },
        "valueFormatter": {"function": "params.value ? params.value.toUpperCase() : '—'"},
    },
    {
        "field": "auc",
        "headerName": "AUC-ROC",
        "width": 95,
        "type": "numericColumn",
        "valueFormatter": {"function": "params.value != null ? Number(params.value).toFixed(4) : '—'"},
    },
    {
        "field": "accuracy",
        "headerName": "Accuracy",
        "width": 95,
        "type": "numericColumn",
        "valueFormatter": {"function": "params.value != null ? Number(params.value).toFixed(4) : '—'"},
    },
    {
        "field": "trainSamples",
        "headerName": "Train N",
        "width": 80,
        "type": "numericColumn",
    },
    {
        "field": "status",
        "headerName": "Status",
        "width": 80,
        "cellStyle": {
            "styleConditions": [
                {"condition": "params.value === 'ready'",    "style": {"color": "#34d399", "fontWeight": "700"}},
                {"condition": "params.value === 'training'", "style": {"color": "#fbbf24", "fontWeight": "700"}},
            ],
            "defaultStyle": {"color": "#94a3b8"},
        },
    },
    {
        "field": "trainedAt",
        "headerName": "Trained At",
        "flex": 1,
        "minWidth": 150,
        "valueFormatter": {"function": "params.value ? params.value.replace('T',' ').slice(0,19) : ''"},
    },
]

_workflow_note = html.Div(
    [
        html.Div("ℹ️  How training works", style={"fontWeight": "700", "color": "#4f8ef7", "marginBottom": "8px", "fontSize": "13px"}),
        html.Div(
            [
                html.Div("Step 1 →", style={"color": "#64748b", "fontSize": "11px", "minWidth": "60px"}),
                html.Div(
                    "Upload a breaks CSV on this page (or via the Upload page) — this runs the 8-step pipeline and generates ML features.",
                    style={"fontSize": "11px", "color": "#94a3b8"},
                ),
            ],
            style={"display": "flex", "gap": "8px", "marginBottom": "6px"},
        ),
        html.Div(
            [
                html.Div("Step 2 →", style={"color": "#64748b", "fontSize": "11px", "minWidth": "60px"}),
                html.Div(
                    "Click Train Model — both GBT and CatBoost are trained; the best AUC-ROC wins and drives inference. Needs at least 5 records.",
                    style={"fontSize": "11px", "color": "#94a3b8"},
                ),
            ],
            style={"display": "flex", "gap": "8px"},
        ),
    ],
    style={
        "background": "rgba(79,142,247,0.08)",
        "border": "1px solid rgba(79,142,247,0.2)",
        "borderRadius": "8px",
        "padding": "12px 14px",
        "marginBottom": "16px",
    },
)

layout = html.Div(
    [
        html.Div(
            [
                html.H1("🤖 ML Training", style={"fontSize": "22px", "fontWeight": "700", "margin": "0"}),
                html.P(
                    "Train GBT and CatBoost classifiers — the model with the highest AUC-ROC is automatically selected",
                    style={"fontSize": "13px", "color": "#64748b", "margin": "4px 0 0 0"},
                ),
            ],
            className="page-header",
        ),
        _workflow_note,
        dbc.Row(
            [
                dbc.Col(
                    [
                        html.Div(
                            [
                                html.Div("Step 1 — Upload Data", className="info-panel-title"),
                                dcc.Upload(
                                    id="train-upload",
                                    children=html.Div(
                                        [
                                            html.Div("📂", style={"fontSize": "32px", "marginBottom": "8px"}),
                                            html.Div(
                                                "Drag & drop a breaks CSV here",
                                                style={"color": "#94a3b8", "fontSize": "13px"},
                                            ),
                                            html.A(
                                                "or click to select",
                                                style={"color": "#4f8ef7", "cursor": "pointer"},
                                            ),
                                        ]
                                    ),
                                    className="upload-zone",
                                    multiple=False,
                                    accept=".csv",
                                ),
                                html.Div(id="train-upload-status", style={"marginTop": "8px", "fontSize": "12px"}),
                                html.Div(id="train-preview-section"),
                                dbc.Button(
                                    "📤 Run Pipeline on This Data",
                                    id="train-upload-btn",
                                    color="primary",
                                    outline=True,
                                    disabled=True,
                                    size="sm",
                                    className="mt-2",
                                    n_clicks=0,
                                ),
                                html.Div(id="train-upload-result", style={"marginTop": "8px"}),
                            ],
                            className="info-panel",
                            style={"height": "100%"},
                        ),
                    ],
                    md=6,
                ),
                dbc.Col(
                    [
                        html.Div(
                            [
                                html.Div("Step 2 — Train Model", className="info-panel-title"),
                                html.P(
                                    "Trains GBT and CatBoost classifiers on the ML features generated by the pipeline. "
                                    "The winner (highest AUC-ROC) is saved to data/models/ and used for inference.",
                                    style={"fontSize": "12px", "color": "#64748b", "marginBottom": "16px"},
                                ),
                                dbc.Button(
                                    "🚀 Train Model",
                                    id="train-run-btn",
                                    color="primary",
                                    size="lg",
                                    className="mb-3",
                                    n_clicks=0,
                                ),
                                dcc.Loading(
                                    html.Div(id="train-results"),
                                    color="#4f8ef7",
                                ),
                            ],
                            className="info-panel",
                            style={"height": "100%"},
                        ),
                    ],
                    md=6,
                ),
            ],
            className="g-3 mb-4",
        ),
        html.Div(
            [
                html.Div("Model Version History", className="info-panel-title", style={"marginBottom": "10px"}),
                dbc.Button(
                    "🔄 Refresh",
                    id="train-refresh-btn",
                    outline=True,
                    color="secondary",
                    size="sm",
                    className="mb-2",
                    n_clicks=0,
                ),
                dag.AgGrid(
                    id="train-history-grid",
                    rowData=[],
                    columnDefs=_history_cols,
                    className="ag-theme-alpine-dark",
                    style={"height": "280px"},
                    dashGridOptions={"suppressCellFocus": True},
                    defaultColDef={"resizable": True, "sortable": True},
                ),
            ],
            className="info-panel",
        ),
        dcc.Store(id="train-rows-store"),
        dcc.Interval(id="train-init", interval=400, max_intervals=1, n_intervals=0),
    ]
)


def _metric(label, value, color):
    return html.Div(
        [
            html.Div(label, className="metric-label"),
            html.Div(str(value), className="metric-value", style={"color": color}),
        ],
        className="metric-card",
        style={"flex": "1", "textAlign": "center"},
    )


def _error_box(msg):
    return html.Div(
        [html.Span("✕  ", style={"fontWeight": "700"}), html.Span(msg)],
        style={
            "color": "#f87171",
            "background": "rgba(248,113,113,0.08)",
            "border": "1px solid rgba(248,113,113,0.2)",
            "borderRadius": "7px",
            "padding": "10px 14px",
            "fontSize": "13px",
        },
    )


def _model_comparison(result):
    winner  = result.get("winner", "gbt")
    gbt_auc = result.get("gbtAuc", 0)
    gbt_acc = result.get("gbtAccuracy", 0)
    cb_auc  = result.get("catboostAuc", 0)
    cb_acc  = result.get("catboostAccuracy", 0)

    gbt_is_winner = winner == "gbt"
    cb_is_winner  = winner == "catboost"

    def _model_card(name, auc, acc, is_winner, color):
        border = "rgba(79,142,247,0.5)" if is_winner else "#1e293b"
        bg     = "rgba(79,142,247,0.06)" if is_winner else "#161b2e"
        badge  = html.Span("⭐ Selected", className="badge-blue", style={"marginLeft": "8px"}) if is_winner else html.Span()
        return html.Div(
            [
                html.Div(
                    [html.Span(name, style={"fontWeight": "700", "color": color, "fontSize": "13px"}), badge],
                    style={"marginBottom": "10px", "display": "flex", "alignItems": "center"},
                ),
                html.Div(
                    [
                        html.Div(
                            [html.Div("AUC-ROC", className="metric-label"),
                             html.Div(f"{auc:.4f}", className="metric-value", style={"color": color, "fontSize": "22px"})],
                            style={"flex": "1", "textAlign": "center"},
                        ),
                        html.Div(
                            [html.Div("ACCURACY", className="metric-label"),
                             html.Div(f"{acc:.4f}", className="metric-value", style={"color": "#94a3b8", "fontSize": "22px"})],
                            style={"flex": "1", "textAlign": "center"},
                        ),
                    ],
                    style={"display": "flex", "gap": "8px"},
                ),
            ],
            style={
                "flex": "1",
                "background": bg,
                "border": f"1px solid {border}",
                "borderRadius": "8px",
                "padding": "14px",
            },
        )

    return html.Div(
        [
            html.Div("Model Comparison", className="info-panel-title", style={"marginBottom": "10px"}),
            html.Div(
                [
                    _model_card("GBT",      gbt_auc, gbt_acc, gbt_is_winner, "#4f8ef7"),
                    html.Div("vs", style={"color": "#334155", "fontSize": "14px", "fontWeight": "700",
                                          "alignSelf": "center", "padding": "0 8px"}),
                    _model_card("CatBoost", cb_auc,  cb_acc,  cb_is_winner,  "#fbbf24"),
                ],
                style={"display": "flex", "gap": "6px", "alignItems": "stretch"},
            ),
        ],
        style={"marginTop": "14px"},
    )


@callback(
    Output("train-history-grid", "rowData"),
    Input("train-init",          "n_intervals"),
    Input("train-refresh-btn",   "n_clicks"),
)
def _load_history(_, __):
    from dash_app.api import get_models
    return get_models()


@callback(
    Output("train-rows-store",      "data"),
    Output("train-preview-section", "children"),
    Output("train-upload-status",   "children"),
    Output("train-upload-btn",      "disabled"),
    Input("train-upload",           "contents"),
    State("train-upload",           "filename"),
    prevent_initial_call=True,
)
def _parse_training(contents, filename):
    if not contents:
        return no_update, no_update, no_update, True

    try:
        _, b64 = contents.split(",", 1)
        text   = base64.b64decode(b64).decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(text))
        rows   = list(reader)
    except Exception as e:
        return None, html.Div(), _error_box(f"Error reading file: {e}"), True

    if not rows:
        return None, html.Div(), _error_box("File is empty or has no data rows."), True

    fields   = list(rows[0].keys())
    col_defs = [{"field": f, "headerName": f, "flex": 1, "minWidth": 80} for f in fields]
    preview  = html.Div(
        [
            html.Div("Preview (first 5 rows):", className="info-panel-title", style={"marginTop": "10px"}),
            dag.AgGrid(
                id="train-preview-grid",
                rowData=rows[:5],
                columnDefs=col_defs,
                className="ag-theme-alpine-dark",
                style={"height": "160px"},
                dashGridOptions={"suppressCellFocus": True},
            ),
        ]
    )

    status = html.Span(
        f"✓ {filename}  ({len(rows):,} rows)",
        style={"color": "#34d399", "fontWeight": "600"},
    )
    return rows, preview, status, False


@callback(
    Output("train-upload-result", "children"),
    Output("train-upload-btn",    "disabled", allow_duplicate=True),
    Input("train-upload-btn",     "n_clicks"),
    State("train-rows-store",     "data"),
    prevent_initial_call=True,
)
def _do_upload(n, rows):
    if not n or not rows:
        return no_update, no_update

    from dash_app.api import upload_training_data

    result, err = upload_training_data(rows)
    if err:
        return _error_box(f"Upload failed: {err}"), False

    steps = result.get("steps", []) if result else []
    dq    = steps[2].get("details", {}) if len(steps) > 2 else {}
    count = dq.get("totalProcessed", len(rows))
    return html.Div(
        f"✓ Pipeline ran on {count:,} records — ML features generated. You can now Train Model.",
        style={"color": "#34d399", "fontSize": "12px", "fontWeight": "600"},
    ), True


@callback(
    Output("train-results",      "children"),
    Output("train-history-grid", "rowData", allow_duplicate=True),
    Input("train-run-btn",       "n_clicks"),
    prevent_initial_call=True,
)
def _train(n):
    if not n:
        return no_update, no_update

    from dash_app.api import train_model, get_models

    result, err = train_model()

    if err:
        hint = ""
        if "insufficient" in err.lower() or "5 samples" in err.lower() or "least" in err.lower():
            hint = " — Upload a breaks CSV using Step 1 above first."
        return _error_box(err + hint), no_update

    auc     = result.get("aucRoc",   result.get("auc", 0))
    acc     = result.get("accuracy", 0)
    train_n = result.get("trainSamples", "?")
    val_n   = result.get("validationSamples", "?")
    version = result.get("version", "?")
    winner  = result.get("winner", "gbt")

    winner_label = "CatBoost" if winner == "catboost" else "GBT"

    summary = html.Div(
        [
            html.Div(
                [
                    _metric("AUC-ROC",  f"{float(auc):.4f}", "#4f8ef7"),
                    _metric("ACCURACY", f"{float(acc):.4f}", "#34d399"),
                    _metric("TRAIN N",  str(train_n),        "#a78bfa"),
                    _metric("VAL N",    str(val_n),          "#fbbf24"),
                ],
                style={"display": "flex", "gap": "10px", "marginTop": "12px"},
            ),
            html.Div(
                [
                    html.Span(f"✓ {winner_label} selected  ",
                              style={"color": "#34d399", "fontWeight": "700"}),
                    html.Span(f"v{version} saved to data/models/",
                              style={"color": "#64748b", "fontSize": "12px"}),
                ],
                style={"marginTop": "10px"},
            ),
            _model_comparison(result),
        ]
    )
    return summary, get_models()
