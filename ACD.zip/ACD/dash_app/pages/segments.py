import base64
import dash
from dash import html, dcc, callback, Output, Input
import dash_bootstrap_components as dbc
import plotly.graph_objects as go

dash.register_page(__name__, path="/segments", name="Segments", order=3)

CHART_BASE = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(13,17,23,0.6)",
    font=dict(color="#e2e8f0", size=11, family="Inter, system-ui"),
    margin=dict(l=8, r=8, t=36, b=8),
)


def _seg_label(key: str) -> str:
    try:
        parts = base64.b64decode(key).decode().split("|")
        return " · ".join(p for p in parts if p) or key[:30]
    except Exception:
        return key[:30]


layout = html.Div(
    [
        html.Div(
            [
                html.H1("📈 Segments", style={"fontSize": "22px", "fontWeight": "700", "margin": "0"}),
                html.P(
                    "Segment health, adaptive thresholds, and EWMA trend analysis",
                    style={"fontSize": "13px", "color": "#64748b", "margin": "4px 0 0 0"},
                ),
            ],
            className="page-header",
        ),
        dbc.Row(
            [
                dbc.Col(html.Div(id="seg-kpi-total"),        md=3),
                dbc.Col(html.Div(id="seg-kpi-stable"),       md=3),
                dbc.Col(html.Div(id="seg-kpi-deteriorating"),md=3),
                dbc.Col(html.Div(id="seg-kpi-breaks"),       md=3),
            ],
            className="g-3 mb-3",
        ),
        dbc.Tabs(
            [
                dbc.Tab(
                    html.Div(id="seg-thresholds-tab", style={"paddingTop": "20px"}),
                    label="⚖️  Thresholds",
                    tab_id="tab-thresholds",
                ),
                dbc.Tab(
                    html.Div(
                        [
                            dbc.Row(
                                [
                                    dbc.Col(
                                        [
                                            html.Label(
                                                "Select Segment",
                                                style={"fontSize": "12px", "color": "#94a3b8", "marginBottom": "4px"},
                                            ),
                                            dcc.Dropdown(
                                                id="seg-dropdown",
                                                placeholder="Choose a segment…",
                                                style={"fontSize": "12px"},
                                            ),
                                        ],
                                        md=6,
                                    ),
                                ],
                                className="g-2 mt-3 mb-3",
                            ),
                            dcc.Loading(
                                dcc.Graph(
                                    id="seg-ewma-chart",
                                    config={"displayModeBar": False},
                                    style={"height": "360px"},
                                ),
                                color="#4f8ef7",
                            ),
                        ]
                    ),
                    label="📉  EWMA Trends",
                    tab_id="tab-ewma",
                ),
            ],
            id="seg-tabs",
            active_tab="tab-thresholds",
        ),
        dcc.Store(id="seg-store"),
        dcc.Store(id="seg-trends-store"),
        dcc.Interval(id="seg-init", interval=400, max_intervals=1, n_intervals=0),
    ]
)


def _kpi(label, value, color):
    return html.Div(
        [
            html.Div(label, className="metric-label"),
            html.Div(str(value), className="metric-value", style={"color": color}),
        ],
        className="metric-card",
    )


def _fmt_gbp(v):
    try:
        return f"£{float(v):,.2f}"
    except Exception:
        return str(v)


def _fmt_plain(v, decimals=2):
    try:
        return f"{float(v):,.{decimals}f}"
    except Exception:
        return str(v)


@callback(
    Output("seg-store",        "data"),
    Output("seg-trends-store", "data"),
    Input("seg-init",          "n_intervals"),
)
def _load(_):
    from dash_app.api import get_segment_stats, get_segment_trends
    return get_segment_stats(), get_segment_trends()


@callback(
    Output("seg-kpi-total",        "children"),
    Output("seg-kpi-stable",       "children"),
    Output("seg-kpi-deteriorating","children"),
    Output("seg-kpi-breaks",       "children"),
    Output("seg-thresholds-tab",   "children"),
    Output("seg-dropdown",         "options"),
    Output("seg-dropdown",         "value"),
    Input("seg-store", "data"),
)
def _update_stats(segs):
    segs = segs or []
    total         = len(segs)
    deteriorating = sum(1 for s in segs if s.get("status") == "deteriorating")
    stable        = total - deteriorating
    total_breaks  = sum(int(s.get("breakCount", 0)) for s in segs)

    threshold_cards = _build_threshold_cards(segs)

    seg_keys = sorted({s.get("segmentKey", "?") for s in segs})
    opts = [{"label": _seg_label(k), "value": k} for k in seg_keys]
    first_seg = seg_keys[0] if seg_keys else None

    return (
        _kpi("TOTAL SEGMENTS",   total,         "#4f8ef7"),
        _kpi("STABLE",           stable,        "#34d399"),
        _kpi("DETERIORATING",    deteriorating, "#f87171"),
        _kpi("TOTAL BREAKS",     total_breaks,  "#a78bfa"),
        threshold_cards,
        opts,
        first_seg,
    )


def _build_threshold_cards(segs):
    if not segs:
        return html.Div(
            [
                html.Div(
                    "No segment data yet.",
                    style={"color": "#94a3b8", "fontSize": "16px", "fontWeight": "600", "marginBottom": "8px"},
                ),
                html.Div(
                    "Upload a breaks CSV and run the pipeline to generate adaptive thresholds.",
                    style={"color": "#475569", "fontSize": "13px"},
                ),
            ],
            style={"textAlign": "center", "padding": "60px 20px"},
        )

    cards = []
    for s in segs:
        is_det = s.get("status") == "deteriorating"
        badge  = (
            html.Span("▼ Deteriorating", className="badge-high")
            if is_det
            else html.Span("● Stable", className="badge-low")
        )

        label_parts = [s.get("recName", ""), s.get("entity", ""), s.get("assetClass", ""), s.get("accountGroup", "")]
        display_label = " · ".join(p for p in label_parts if p) or s.get("segmentKey", "?")[:30]

        rows_list = [
            ("Median Amount",     "medianAmountGbp",   "#4f8ef7",  _fmt_gbp),
            ("MAD",               "madValue",          "#64748b",  _fmt_gbp),
            ("Material (4σ)",     "materialThreshold", "#f87171",  _fmt_gbp),
            ("Early Warning (2σ)","earlyWarning",      "#fbbf24",  _fmt_gbp),
            ("Robust Sigma",      "robustSigma",       "#a78bfa",  _fmt_gbp),
            ("Break Count",       "breakCount",        "#94a3b8",  lambda v: str(int(float(v or 0)))),
        ]

        card = dbc.Col(
            html.Div(
                [
                    html.Div(
                        [
                            html.Span(
                                display_label,
                                style={"fontWeight": "700", "fontSize": "12px", "flex": "1",
                                       "overflow": "hidden", "textOverflow": "ellipsis", "whiteSpace": "nowrap"},
                                title=display_label,
                            ),
                            badge,
                        ],
                        style={"display": "flex", "alignItems": "center", "gap": "8px", "marginBottom": "10px"},
                    ),
                    *[
                        html.Div(
                            [
                                html.Span(label, style={"color": "#64748b", "fontSize": "11px", "flex": "1"}),
                                html.Span(
                                    fmt_fn(s.get(field, 0)),
                                    style={"color": color, "fontSize": "12px", "fontWeight": "600"},
                                ),
                            ],
                            style={
                                "display": "flex",
                                "justifyContent": "space-between",
                                "padding": "4px 0",
                                "borderBottom": "1px solid rgba(30,58,95,0.4)",
                            },
                        )
                        for label, field, color, fmt_fn in rows_list
                    ],
                ],
                className="info-panel",
                style={"height": "100%"},
            ),
            md=4,
            style={"marginBottom": "16px"},
        )
        cards.append(card)

    return dbc.Row(cards, className="g-3")


@callback(
    Output("seg-ewma-chart", "figure"),
    Input("seg-dropdown",    "value"),
    Input("seg-trends-store","data"),
)
def _update_ewma(seg_key, trends):
    trends = trends or []
    empty = go.Figure(
        layout={
            **CHART_BASE,
            "title": {"text": "Select a segment to view EWMA trend", "font": {"color": "#475569", "size": 13}},
        }
    )
    if not seg_key or not trends:
        return empty

    seg_trends = [t for t in trends if t.get("segmentKey") == seg_key]
    if not seg_trends:
        return empty

    seg_trends.sort(key=lambda x: x.get("month", ""))

    months       = [t.get("month", "") for t in seg_trends]
    monthly_sums = [float(t.get("monthlySum", 0))  for t in seg_trends]
    ewma_vals    = [float(t.get("ewmaValue", 0))    for t in seg_trends]
    deteriorating= [bool(t.get("isDeteriorating", False)) for t in seg_trends]

    fig = go.Figure()

    fig.add_trace(
        go.Scatter(
            x=months,
            y=monthly_sums,
            mode="lines+markers",
            name="Monthly Sum (£)",
            line=dict(color="#4f8ef7", width=2),
            marker=dict(size=5),
            fill="tozeroy",
            fillcolor="rgba(79,142,247,0.12)",
        )
    )
    fig.add_trace(
        go.Scatter(
            x=months,
            y=ewma_vals,
            mode="lines",
            name="EWMA",
            line=dict(color="#f97316", width=2, dash="dash"),
        )
    )

    for p, det in zip(months, deteriorating):
        if det:
            fig.add_shape(
                type="line",
                x0=p, x1=p,
                y0=0, y1=1,
                yref="paper",
                line=dict(color="rgba(248,113,113,0.4)", dash="dot", width=1.5),
            )
            fig.add_annotation(
                x=p, y=1.02,
                yref="paper",
                text="⚠",
                font=dict(color="#f87171", size=10),
                showarrow=False,
            )

    fig.update_layout(
        **CHART_BASE,
        title={"text": f"EWMA Trend — {_seg_label(seg_key)}", "font": {"size": 13}},
        xaxis=dict(
            title="Month",
            gridcolor="#1e293b",
            tickangle=30,
            tickfont=dict(size=9),
        ),
        yaxis=dict(title="Amount (£)", gridcolor="#1e293b"),
        legend=dict(orientation="h", y=1.08, x=0, font=dict(size=10)),
        hovermode="x unified",
    )
    return fig
