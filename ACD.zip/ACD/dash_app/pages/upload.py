import base64
import io
import csv

import dash
from dash import html, dcc, callback, Output, Input, State, no_update
import dash_bootstrap_components as dbc
import dash_ag_grid as dag

dash.register_page(__name__, path="/upload", name="Upload", order=1)

PIPELINE_STEPS = [
    "Schema Validation",
    "Duplicate Detection",
    "Ageing Calculation",
    "Segment Classification",
    "Threshold Evaluation",
    "ML Risk Scoring",
    "Historical Linkage",
    "Audit Logging",
]

STATUS_MAP = {
    "complete": ("✓  ", "step-item step-complete"),
    "failed":   ("✕  ", "step-item step-error"),
    "skipped":  ("—  ", "step-item step-skipped"),
    "running":  ("…  ", "step-item step-running"),
    "pending":  ("○  ", "step-item step-pending"),
}


def _step_list_pending():
    return [
        html.Div([html.Span("○  "), step], className="step-item step-pending")
        for step in PIPELINE_STEPS
    ]


def _step_summary(step: dict) -> str:
    details = step.get("details") or {}
    if not details:
        return ""
    parts = []
    if "count" in details:
        parts.append(f"{int(details['count']):,} records ingested")
    if "totalProcessed" in details:
        parts.append(f"{int(details['totalProcessed']):,} processed")
    if "corrections" in details and int(details.get("corrections", 0)):
        parts.append(f"{details['corrections']} ageing corrections")
    if "validationErrors" in details and int(details.get("validationErrors", 0)):
        parts.append(f"{details['validationErrors']} validation errors")
    if "scored" in details:
        parts.append(f"{details['scored']} records scored")
    if "reason" in details:
        parts.append(str(details["reason"]))
    if "totalBreaks" in details:
        parts.append(f"{details['totalBreaks']} breaks · {details.get('materialBreaks', 0)} material")
    return " · ".join(parts)


def _step_list_result(pipeline_result):
    api_steps = pipeline_result.get("steps", [])
    items = []
    for i, label in enumerate(PIPELINE_STEPS):
        if i < len(api_steps):
            s = api_steps[i]
            status = s.get("status", "pending")
            icon, cls = STATUS_MAP.get(status, ("○  ", "step-item step-pending"))
            summary = _step_summary(s)
            items.append(
                html.Div(
                    [
                        html.Span(icon),
                        html.Span(label, style={"fontWeight": "600"}),
                        html.Span(
                            f"  {summary}" if summary else "",
                            style={"color": "#64748b", "fontSize": "11px"},
                        ),
                    ],
                    className=cls,
                )
            )
        else:
            items.append(html.Div([html.Span("○  "), label], className="step-item step-pending"))
    return items


layout = html.Div(
    [
        html.Div(
            [
                html.H1("📁 Upload Breaks", style={"fontSize": "22px", "fontWeight": "700", "margin": "0"}),
                html.P(
                    "Upload a CSV of reconciliation breaks and run the 8-step RICP pipeline",
                    style={"fontSize": "13px", "color": "#64748b", "margin": "4px 0 0 0"},
                ),
            ],
            className="page-header",
        ),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dcc.Upload(
                            id="upload-csv",
                            children=html.Div(
                                [
                                    html.Div("📂", style={"fontSize": "40px", "marginBottom": "12px"}),
                                    html.Div(
                                        "Drag & drop a CSV file here, or",
                                        style={"color": "#94a3b8", "fontSize": "14px"},
                                    ),
                                    html.A(
                                        "click to select",
                                        style={"color": "#4f8ef7", "fontWeight": "600", "cursor": "pointer"},
                                    ),
                                    html.Div(
                                        ".csv files only",
                                        style={"color": "#475569", "fontSize": "11px", "marginTop": "8px"},
                                    ),
                                ]
                            ),
                            className="upload-zone",
                            multiple=False,
                            accept=".csv",
                        ),
                        html.Div(
                            id="upload-filename",
                            style={"marginTop": "10px", "fontSize": "12px", "color": "#64748b"},
                        ),
                    ],
                    md=5,
                ),
                dbc.Col(
                    [
                        html.Div(
                            [
                                html.Div("Pipeline Steps", className="info-panel-title"),
                                html.Div(id="upload-step-list", children=_step_list_pending()),
                            ],
                            className="info-panel",
                            style={"minHeight": "220px"},
                        ),
                        html.Div(id="upload-result-msg", style={"marginTop": "12px"}),
                        html.Div(
                            [
                                dbc.Button(
                                    "⚡ Run Pipeline",
                                    id="upload-run-btn",
                                    color="primary",
                                    disabled=True,
                                    className="me-2",
                                    n_clicks=0,
                                ),
                                dbc.Button(
                                    "🔄 Reset",
                                    id="upload-reset-btn",
                                    outline=True,
                                    color="secondary",
                                    n_clicks=0,
                                ),
                            ],
                            style={"marginTop": "14px"},
                        ),
                    ],
                    md=7,
                ),
            ],
            className="g-3 mb-4",
        ),
        html.Div(id="upload-preview-section"),
        dcc.Store(id="upload-rows-store"),
        dcc.Loading(
            html.Div(id="upload-loading-div"),
            id="upload-loading",
            type="circle",
            color="#4f8ef7",
        ),
    ]
)


@callback(
    Output("upload-rows-store",     "data"),
    Output("upload-preview-section","children"),
    Output("upload-filename",       "children"),
    Output("upload-run-btn",        "disabled"),
    Input("upload-csv",             "contents"),
    State("upload-csv",             "filename"),
    prevent_initial_call=True,
)
def _parse_upload(contents, filename):
    if not contents:
        return no_update, no_update, no_update, True

    try:
        _, b64 = contents.split(",", 1)
        text   = base64.b64decode(b64).decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(text))
        rows   = list(reader)
    except Exception as e:
        return (
            None,
            html.Div(f"Error parsing file: {e}", style={"color": "#f87171", "fontSize": "13px"}),
            f"Error: {filename}",
            True,
        )

    if not rows:
        return (
            None,
            html.Div("File is empty or has no data rows.", style={"color": "#fbbf24"}),
            filename,
            True,
        )

    fields   = list(rows[0].keys())
    col_defs = [{"field": f, "headerName": f, "flex": 1, "minWidth": 90} for f in fields]
    preview  = html.Div(
        [
            html.Div(
                [
                    html.Span(f"✓  {filename}", style={"color": "#34d399", "fontWeight": "600"}),
                    html.Span(
                        f"  —  {len(rows):,} rows · {len(fields)} columns",
                        style={"color": "#94a3b8", "fontSize": "12px"},
                    ),
                ],
                style={"marginBottom": "10px"},
            ),
            html.Div("Preview (first 10 rows):", className="info-panel-title"),
            dag.AgGrid(
                id="upload-preview-grid",
                rowData=rows[:10],
                columnDefs=col_defs,
                className="ag-theme-alpine-dark",
                style={"height": "240px"},
                dashGridOptions={"suppressCellFocus": True},
            ),
        ]
    )
    return rows, preview, f"📄 {filename} ({len(rows):,} rows)", False


@callback(
    Output("upload-step-list",   "children"),
    Output("upload-result-msg",  "children"),
    Output("upload-loading-div", "children"),
    Input("upload-run-btn",      "n_clicks"),
    State("upload-rows-store",   "data"),
    prevent_initial_call=True,
)
def _run_pipeline(n, rows):
    if not n or not rows:
        return no_update, no_update, no_update

    from dash_app.api import upload_breaks

    result, err = upload_breaks(rows)

    if err:
        return (
            _step_list_pending(),
            html.Div(
                [html.Span("✕  ", style={"fontWeight": "700"}), html.Span(f"Pipeline failed: {err}")],
                style={"color": "#f87171", "fontSize": "13px",
                       "background": "rgba(248,113,113,0.08)",
                       "border": "1px solid rgba(248,113,113,0.2)",
                       "borderRadius": "7px", "padding": "10px 14px"},
            ),
            "",
        )

    pipeline_status = result.get("status", "complete")
    steps = result.get("steps", [])

    dq_details = steps[2].get("details", {}) if len(steps) > 2 else {}
    clean_count   = dq_details.get("totalProcessed", len(rows))
    correction_ct = dq_details.get("corrections", 0)

    if pipeline_status == "complete":
        summary_color = "#34d399"
        icon = "✓  Pipeline complete"
        detail = f"{clean_count:,} breaks processed"
        if correction_ct:
            detail += f" · {correction_ct} ageing corrections applied"
        border_color = "rgba(52,211,153,0.2)"
        bg_color     = "rgba(52,211,153,0.08)"
    else:
        summary_color = "#f87171"
        icon = "✕  Pipeline failed"
        detail = f"Failed at step {result.get('currentStep', '?')} of {result.get('totalSteps', 8)}"
        border_color = "rgba(248,113,113,0.2)"
        bg_color     = "rgba(248,113,113,0.08)"

    msg = html.Div(
        [
            html.Span(icon,   style={"color": summary_color, "fontWeight": "700"}),
            html.Span(f"  {detail}", style={"color": "#94a3b8", "fontSize": "12px"}),
        ],
        style={
            "padding": "10px 14px",
            "background": bg_color,
            "border": f"1px solid {border_color}",
            "borderRadius": "7px",
        },
    )
    return _step_list_result(result), msg, ""


@callback(
    Output("upload-csv",             "contents"),
    Output("upload-rows-store",      "data",     allow_duplicate=True),
    Output("upload-preview-section", "children", allow_duplicate=True),
    Output("upload-filename",        "children", allow_duplicate=True),
    Output("upload-run-btn",         "disabled", allow_duplicate=True),
    Output("upload-step-list",       "children", allow_duplicate=True),
    Output("upload-result-msg",      "children", allow_duplicate=True),
    Input("upload-reset-btn",        "n_clicks"),
    prevent_initial_call=True,
)
def _reset(n):
    if not n:
        return (no_update,) * 7
    return None, None, html.Div(), "", True, _step_list_pending(), html.Div()
