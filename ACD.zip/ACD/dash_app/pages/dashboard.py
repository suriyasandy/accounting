import base64
import dash
from dash import html, dcc, callback, Output, Input
import dash_bootstrap_components as dbc
import plotly.graph_objects as go

dash.register_page(__name__, path="/", name="Dashboard", order=0)

BUCKET_ORDER  = ["0-30", "31-60", "61-90", "91-180", "180+"]
BUCKET_COLORS = ["#34d399", "#4f8ef7", "#fbbf24", "#f97316", "#f87171"]
SEV_COLORS    = {"High": "#f87171", "Medium": "#fbbf24", "Low": "#34d399", "Unscored": "#475569"}

CHART_BASE = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(13,17,23,0.6)",
    font=dict(color="#e2e8f0", size=11, family="Inter, system-ui"),
    margin=dict(l=8, r=8, t=36, b=8),
)


def _metric(label, value, color_cls):
    return html.Div(
        [
            html.Div(label, className="metric-label"),
            html.Div(str(value), className=f"metric-value {color_cls}"),
        ],
        className="metric-card",
    )


def _opt(lst):
    return [{"label": v, "value": v} for v in sorted(set(lst)) if v]


_dd_style = {"fontSize": "12px"}


layout = html.Div(
    [
        html.Div(
            [
                html.H1(
                    "📊 Dashboard",
                    style={"fontSize": "22px", "fontWeight": "700", "margin": "0"},
                ),
                html.P(
                    "Real-time reconciliation health, risk distribution and segment thresholds",
                    style={"fontSize": "13px", "color": "#64748b", "margin": "4px 0 0 0"},
                ),
            ],
            className="page-header",
        ),
        html.Div(id="dash-status-row", style={"marginBottom": "14px"}),
        dbc.Row(
            [
                dbc.Col(html.Div(id="dash-kpi-total"), md=3),
                dbc.Col(html.Div(id="dash-kpi-high"),  md=3),
                dbc.Col(html.Div(id="dash-kpi-med"),   md=3),
                dbc.Col(html.Div(id="dash-kpi-active"),md=3),
            ],
            className="g-3 mb-3",
        ),
        dbc.Card(
            [
                dbc.CardHeader("🔽  Dimension Filters"),
                dbc.CardBody(
                    dbc.Row(
                        [
                            dbc.Col(
                                [
                                    html.Label("Rec Name", style={"fontSize": "11px", "color": "#94a3b8", "marginBottom": "4px"}),
                                    dcc.Dropdown(id="dash-rec", placeholder="All", clearable=True, style=_dd_style),
                                ],
                                md=3,
                            ),
                            dbc.Col(
                                [
                                    html.Label("Entity", style={"fontSize": "11px", "color": "#94a3b8", "marginBottom": "4px"}),
                                    dcc.Dropdown(id="dash-ent", placeholder="All", clearable=True, style=_dd_style),
                                ],
                                md=3,
                            ),
                            dbc.Col(
                                [
                                    html.Label("Asset Class", style={"fontSize": "11px", "color": "#94a3b8", "marginBottom": "4px"}),
                                    dcc.Dropdown(id="dash-ac", placeholder="All", clearable=True, style=_dd_style),
                                ],
                                md=3,
                            ),
                            dbc.Col(
                                [
                                    html.Label("Account Group", style={"fontSize": "11px", "color": "#94a3b8", "marginBottom": "4px"}),
                                    dcc.Dropdown(id="dash-ag", placeholder="All", clearable=True, style=_dd_style),
                                ],
                                md=3,
                            ),
                        ],
                        className="g-2",
                    )
                ),
            ],
            className="mb-3",
        ),
        dbc.Row(
            [
                dbc.Col(
                    dcc.Graph(id="dash-ageing-chart", config={"displayModeBar": False}, style={"height": "300px"}),
                    md=7,
                ),
                dbc.Col(
                    dcc.Graph(id="dash-severity-chart", config={"displayModeBar": False}, style={"height": "300px"}),
                    md=5,
                ),
            ],
            className="g-3 mb-3",
        ),
        dbc.Card(
            [
                dbc.CardHeader("⚖️  Segment Threshold Comparison"),
                dbc.CardBody(
                    dcc.Graph(id="dash-threshold-chart", config={"displayModeBar": False}, style={"height": "280px"})
                ),
            ],
            className="mb-3",
        ),
        dbc.Row(
            [
                dbc.Col(html.Div(id="dash-seg-card"),      md=4),
                dbc.Col(html.Div(id="dash-model-card"),    md=4),
                dbc.Col(html.Div(id="dash-pipeline-card"), md=4),
            ],
            className="g-3",
        ),
        dcc.Store(id="dash-store"),
        dcc.Interval(id="dash-init", interval=300, max_intervals=1, n_intervals=0),
    ]
)


@callback(
    Output("dash-store", "data"),
    Input("dash-init", "n_intervals"),
)
def _load(_):
    from dash_app.api import get_health, get_analysis, get_segment_stats, get_models, get_pipeline_runs
    return {
        "health":   get_health(),
        "breaks":   get_analysis(),
        "segments": get_segment_stats(),
        "models":   get_models(),
        "runs":     get_pipeline_runs(),
    }


@callback(
    Output("dash-rec", "options"),
    Output("dash-ent", "options"),
    Output("dash-ac",  "options"),
    Output("dash-ag",  "options"),
    Input("dash-store", "data"),
)
def _populate_filters(data):
    if not data or not data.get("breaks"):
        return [], [], [], []
    rows = data["breaks"]
    return (
        _opt([r.get("recName","") for r in rows]),
        _opt([r.get("entity","")  for r in rows]),
        _opt([r.get("assetClass","") for r in rows]),
        _opt([r.get("accountGroup","") for r in rows]),
    )


@callback(
    Output("dash-status-row",     "children"),
    Output("dash-kpi-total",      "children"),
    Output("dash-kpi-high",       "children"),
    Output("dash-kpi-med",        "children"),
    Output("dash-kpi-active",     "children"),
    Output("dash-ageing-chart",   "figure"),
    Output("dash-severity-chart", "figure"),
    Output("dash-threshold-chart","figure"),
    Output("dash-seg-card",       "children"),
    Output("dash-model-card",     "children"),
    Output("dash-pipeline-card",  "children"),
    Input("dash-store", "data"),
    Input("dash-rec",   "value"),
    Input("dash-ent",   "value"),
    Input("dash-ac",    "value"),
    Input("dash-ag",    "value"),
)
def _update(data, rec, ent, ac, ag):
    empty_fig = go.Figure(layout={
        **CHART_BASE,
        "title": {"text": "No data — upload a breaks CSV first", "font": {"color": "#475569", "size": 12}},
        "annotations": [{"text": "Upload breaks via the Upload page to populate this chart",
                          "showarrow": False, "x": 0.5, "y": 0.5, "xref": "paper", "yref": "paper",
                          "font": {"color": "#334155", "size": 11}}],
    })

    if not data:
        no_data = _metric("—", "—", "text-muted-c")
        return (
            html.Span("No Data", className="badge-nodata"),
            no_data, no_data, no_data, no_data,
            empty_fig, empty_fig, empty_fig,
            _info_card("Segment Health", "No data loaded"),
            _info_card("ML Model",       "No model trained"),
            _info_card("Latest Pipeline","No runs yet"),
        )

    health   = data.get("health", {})
    all_rows = data.get("breaks", [])
    segs     = data.get("segments", [])
    models   = data.get("models", [])
    runs     = data.get("runs", [])

    rows = [r for r in all_rows
            if (not rec or r.get("recName")    == rec)
            and (not ent or r.get("entity")    == ent)
            and (not ac  or r.get("assetClass")== ac)
            and (not ag  or r.get("accountGroup")==ag)]

    def _seg_matches_filters(seg):
        try:
            parts = base64.b64decode(seg.get("segmentKey", "")).decode().split("|")
            seg_rec = parts[0] if len(parts) > 0 else ""
            seg_ent = parts[1] if len(parts) > 1 else ""
            seg_ac  = parts[2] if len(parts) > 2 else ""
            seg_ag  = parts[3] if len(parts) > 3 else ""
            return (
                (not rec or seg_rec == rec)
                and (not ent or seg_ent == ent)
                and (not ac  or seg_ac  == ac)
                and (not ag  or seg_ag  == ag)
            )
        except Exception:
            return True

    filtered_segs = [s for s in segs if _seg_matches_filters(s)]

    total   = len(rows)
    high    = sum(1 for r in rows if r.get("severity") == "High")
    med     = sum(1 for r in rows if r.get("severity") == "Medium")
    corrected = sum(1 for r in rows if r.get("correctedFlag", False))

    status = health.get("status", "No Data")
    if status == "Healthy":
        status_badge = html.Span(f"● {status}", className="badge-healthy")
    elif status == "Warning":
        status_badge = html.Span(f"▲ {status}", className="badge-warning-status")
    else:
        status_badge = html.Span(f"○ {status}", className="badge-nodata")

    ageing_fig = _ageing_chart(rows)
    sev_fig    = _severity_chart(rows)
    thr_fig    = _threshold_chart(filtered_segs)

    deteriorating = sum(1 for s in filtered_segs if s.get("status") == "deteriorating")
    seg_card = _info_card(
        "📈 Segment Health",
        f"{len(filtered_segs)} segments · {deteriorating} deteriorating",
        [
            ("Total Segments",    str(len(filtered_segs))),
            ("Deteriorating",     str(deteriorating)),
            ("Stable",            str(len(filtered_segs) - deteriorating)),
        ],
    )

    latest_model = models[0] if models else {}
    auc_val = latest_model.get("auc") or latest_model.get("aucRoc") or "—"
    acc_val = latest_model.get("accuracy", "—")
    try:
        auc_display = f"{float(auc_val):.4f}"
    except Exception:
        auc_display = "—"
    try:
        acc_display = f"{float(acc_val):.4f}"
    except Exception:
        acc_display = "—"

    model_card = _info_card(
        "🤖 ML Model",
        latest_model.get("name", "No model trained"),
        [
            ("Version",    str(latest_model.get("version", "—"))),
            ("Type",       str(latest_model.get("modelType", "gbt")).upper()),
            ("AUC-ROC",    auc_display),
            ("Accuracy",   acc_display),
        ] if latest_model else [],
    )

    latest_run = runs[0] if runs else {}
    raw_count  = latest_run.get("rawCount", "—")
    clean_count = latest_run.get("cleanCount", "—")
    started_at = str(latest_run.get("startedAt", ""))[:16].replace("T", " ") if latest_run.get("startedAt") else "—"

    pipeline_card = _info_card(
        "⚡ Latest Pipeline",
        latest_run.get("status", "No runs yet").title(),
        [
            ("Records In",   str(raw_count)),
            ("Records Out",  str(clean_count)),
            ("Started",      started_at),
        ] if latest_run else [],
    )

    return (
        status_badge,
        _metric("TOTAL BREAKS",    total,     "text-white"),
        _metric("MATERIAL (HIGH)", high,      "text-high"),
        _metric("WARNING (MED)",   med,       "text-medium"),
        _metric("CORRECTED",       corrected, "text-accent"),
        ageing_fig,
        sev_fig,
        thr_fig,
        seg_card,
        model_card,
        pipeline_card,
    )


def _ageing_chart(rows):
    counts = {b: 0 for b in BUCKET_ORDER}
    for r in rows:
        b = r.get("ageingBucket") or r.get("derivedAgeingBucket") or "0-30"
        if b in counts:
            counts[b] += 1

    if not any(counts.values()):
        return go.Figure(layout={
            **CHART_BASE,
            "title": {"text": "Ageing Distribution — No data", "font": {"color": "#475569", "size": 13}},
        })

    fig = go.Figure(
        go.Bar(
            x=BUCKET_ORDER,
            y=[counts[b] for b in BUCKET_ORDER],
            marker_color=BUCKET_COLORS,
            text=[counts[b] if counts[b] > 0 else "" for b in BUCKET_ORDER],
            textposition="outside",
        )
    )
    fig.update_layout(
        **CHART_BASE,
        title={"text": "Ageing Distribution (days)", "font": {"size": 13}},
        xaxis=dict(gridcolor="#1e293b", tickfont=dict(size=11)),
        yaxis=dict(gridcolor="#1e293b", showgrid=True),
        showlegend=False,
    )
    return fig


def _severity_chart(rows):
    sev_counts: dict = {}
    for r in rows:
        s = r.get("severity") or "Unscored"
        sev_counts[s] = sev_counts.get(s, 0) + 1

    if not sev_counts:
        return go.Figure(layout={
            **CHART_BASE,
            "title": {"text": "Severity Distribution — No data", "font": {"color": "#475569", "size": 13}},
        })

    labels = list(sev_counts.keys())
    values = list(sev_counts.values())
    colors = [SEV_COLORS.get(l, "#475569") for l in labels]
    fig = go.Figure(
        go.Pie(
            labels=labels,
            values=values,
            hole=0.6,
            marker_colors=colors,
            textinfo="percent+label",
            textfont_size=11,
        )
    )
    fig.update_layout(
        **CHART_BASE,
        title={"text": "Severity Distribution", "font": {"size": 13}},
        showlegend=True,
        legend=dict(orientation="v", x=1.0, y=0.5, font=dict(size=10)),
    )
    return fig


def _decode_segment_key(key: str) -> str:
    try:
        parts = base64.b64decode(key).decode().split("|")
        rec    = parts[0] if len(parts) > 0 else "?"
        entity = parts[1] if len(parts) > 1 else ""
        asset  = parts[2] if len(parts) > 2 else ""
        ag     = parts[3] if len(parts) > 3 else ""
        label  = f"{rec}\n{entity} · {asset}"
        if ag:
            label += f" · {ag}"
        return label
    except Exception:
        return key[:20]


def _threshold_chart(segs):
    if not segs:
        return go.Figure(layout={
            **CHART_BASE,
            "title": {"text": "Segment Threshold Comparison — No data", "font": {"color": "#475569", "size": 13}},
        })

    names     = [_decode_segment_key(s.get("segmentKey", "")) for s in segs]
    materials = [float(s.get("materialThreshold", 0) or 0) for s in segs]
    warnings  = [float(s.get("earlyWarning", 0) or 0)      for s in segs]
    medians   = [float(s.get("medianAmountGbp", 0) or 0)   for s in segs]

    fig = go.Figure(
        [
            go.Bar(name="Material (4σ)",     x=names, y=materials, marker_color="#f87171"),
            go.Bar(name="Early Warning (2σ)", x=names, y=warnings,  marker_color="#fbbf24"),
            go.Bar(name="Median",             x=names, y=medians,   marker_color="#4f8ef7"),
        ]
    )
    fig.update_layout(
        **CHART_BASE,
        title={"text": "Segment Threshold Comparison (£)", "font": {"size": 13}},
        barmode="group",
        xaxis=dict(tickfont=dict(size=9), gridcolor="#1e293b"),
        yaxis=dict(gridcolor="#1e293b", tickprefix="£"),
        legend=dict(orientation="h", y=1.1, x=0, font=dict(size=10)),
    )
    return fig


def _info_card(title, subtitle, rows=None):
    items = []
    if rows:
        for k, v in rows:
            items.append(
                html.Div(
                    [
                        html.Span(k, style={"color": "#64748b", "fontSize": "11px", "flex": "1"}),
                        html.Span(v, style={"color": "#e2e8f0", "fontSize": "12px", "fontWeight": "600"}),
                    ],
                    style={"display": "flex", "justifyContent": "space-between",
                           "padding": "4px 0", "borderBottom": "1px solid rgba(30,41,59,0.6)"},
                )
            )
    return html.Div(
        [
            html.Div(title, className="info-panel-title"),
            html.Div(subtitle, style={"fontSize": "13px", "color": "#94a3b8", "marginBottom": "10px"}),
            *items,
        ],
        className="info-panel",
    )
