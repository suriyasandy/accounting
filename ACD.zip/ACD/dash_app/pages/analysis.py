import dash
from dash import html, dcc, callback, Output, Input, State, no_update
import dash_bootstrap_components as dbc
import dash_ag_grid as dag
import plotly.graph_objects as go

dash.register_page(__name__, path="/analysis", name="Analysis", order=2)

FEATURE_NAMES = [
    "breakFrequency30d",
    "avgAgeing",
    "thresholdDistance",
    "repeatTradeFlag",
    "segmentVolatility",
    "maturityProximityDays",
]
FEATURE_LABELS = [
    "Break Freq 30d",
    "Avg Ageing (d)",
    "Threshold Dist",
    "Repeat Trade",
    "Seg Volatility",
    "Maturity Proximity",
]

SEV_COLORS = {"High": "#f87171", "Medium": "#fbbf24", "Low": "#34d399"}
CHART_BASE  = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(13,17,23,0.6)",
    font=dict(color="#e2e8f0", size=10, family="Inter, system-ui"),
    margin=dict(l=6, r=6, t=28, b=6),
)

_main_cols = [
    {"field": "tradeId",      "headerName": "Trade ID",   "pinned": "left", "width": 110},
    {"field": "recName",      "headerName": "Rec Name",   "flex": 1, "minWidth": 110},
    {"field": "entity",       "headerName": "Entity",     "width": 95},
    {"field": "assetClass",   "headerName": "Asset Class","width": 100},
    {
        "field": "amountGbp",
        "headerName": "Amount (£)",
        "width": 115,
        "type": "numericColumn",
        "valueFormatter": {"function": "params.value != null ? '£' + Number(params.value).toLocaleString('en-GB',{minimumFractionDigits:2,maximumFractionDigits:2}) : ''"},
    },
    {"field": "ageingDays",   "headerName": "Ageing (d)", "width": 90,  "type": "numericColumn"},
    {"field": "ageingBucket", "headerName": "Bucket",     "width": 80},
    {
        "field": "riskScore",
        "headerName": "Risk Score",
        "width": 100,
        "type": "numericColumn",
        "valueFormatter": {"function": "params.value != null ? Number(params.value).toFixed(1) : '—'"},
        "cellStyle": {
            "styleConditions": [
                {"condition": "params.value >= 50", "style": {"color": "#f87171", "fontWeight": "700"}},
                {"condition": "params.value >= 25", "style": {"color": "#fbbf24", "fontWeight": "600"}},
                {"condition": "params.value >= 0",  "style": {"color": "#34d399", "fontWeight": "600"}},
            ],
            "defaultStyle": {"color": "#94a3b8"},
        },
    },
    {
        "field": "severity",
        "headerName": "Severity",
        "width": 95,
        "cellStyle": {
            "styleConditions": [
                {"condition": "params.value === 'High'",     "style": {"color": "#f87171", "fontWeight": "700"}},
                {"condition": "params.value === 'Medium'",   "style": {"color": "#fbbf24", "fontWeight": "600"}},
                {"condition": "params.value === 'Low'",      "style": {"color": "#34d399", "fontWeight": "600"}},
                {"condition": "params.value === 'Unscored'", "style": {"color": "#475569"}},
            ],
            "defaultStyle": {"color": "#94a3b8"},
        },
    },
    {
        "field": "correctedFlag",
        "headerName": "Corrected",
        "width": 95,
        "valueFormatter": {"function": "params.value ? 'Yes' : 'No'"},
        "cellStyle": {
            "styleConditions": [
                {"condition": "params.value === true", "style": {"color": "#fbbf24"}},
            ],
            "defaultStyle": {"color": "#475569"},
        },
    },
    {"field": "historicalMatchCount", "headerName": "Matches", "width": 80, "type": "numericColumn"},
    {"field": "jiraId",    "headerName": "Jira ID", "width": 95},
]

_dd_style = {"fontSize": "12px"}

layout = html.Div(
    [
        html.Div(
            [
                html.H1("🔍 Risk Analysis", style={"fontSize": "22px", "fontWeight": "700", "margin": "0"}),
                html.P(
                    "Explore scored breaks, apply filters, and inspect ML features and historical linkage",
                    style={"fontSize": "13px", "color": "#64748b", "margin": "4px 0 0 0"},
                ),
            ],
            className="page-header",
        ),
        dbc.Row(
            [
                dbc.Col(html.Div(id="an-kpi-high"),      md=3),
                dbc.Col(html.Div(id="an-kpi-med"),       md=3),
                dbc.Col(html.Div(id="an-kpi-low"),       md=3),
                dbc.Col(html.Div(id="an-kpi-corrected"), md=3),
            ],
            className="g-3 mb-3",
        ),
        dbc.Card(
            dbc.CardBody(
                dbc.Row(
                    [
                        dbc.Col(
                            dbc.Input(id="an-search", placeholder="Search trade ID, rec, entity…", type="text", size="sm"),
                            md=3,
                        ),
                        dbc.Col(
                            dcc.Dropdown(id="an-rec",  placeholder="Rec Name",    clearable=True, style=_dd_style),
                            md=2,
                        ),
                        dbc.Col(
                            dcc.Dropdown(id="an-ent",  placeholder="Entity",      clearable=True, style=_dd_style),
                            md=2,
                        ),
                        dbc.Col(
                            dcc.Dropdown(id="an-ac",   placeholder="Asset Class", clearable=True, style=_dd_style),
                            md=2,
                        ),
                        dbc.Col(
                            dcc.Dropdown(
                                id="an-sev",
                                placeholder="Severity",
                                clearable=True,
                                options=[
                                    {"label": "High",     "value": "High"},
                                    {"label": "Medium",   "value": "Medium"},
                                    {"label": "Low",      "value": "Low"},
                                    {"label": "Unscored", "value": "Unscored"},
                                ],
                                style=_dd_style,
                            ),
                            md=2,
                        ),
                        dbc.Col(
                            dbc.Button("🔄", id="an-refresh", outline=True, color="secondary", size="sm"),
                            width="auto",
                        ),
                    ],
                    className="g-2 align-items-center",
                )
            ),
            className="mb-3",
        ),
        dcc.Loading(
            dag.AgGrid(
                id="an-grid",
                rowData=[],
                columnDefs=_main_cols,
                className="ag-theme-alpine-dark",
                style={"height": "360px"},
                dashGridOptions={
                    "rowSelection": "single",
                    "suppressCellFocus": True,
                    "pagination": True,
                    "paginationPageSize": 25,
                },
                defaultColDef={"resizable": True, "sortable": True, "filter": True},
            ),
            color="#4f8ef7",
        ),
        html.Div(id="an-detail-panel"),
        dcc.Store(id="an-store"),
        dcc.Interval(id="an-init", interval=400, max_intervals=1, n_intervals=0),
    ]
)


def _kpi(label, value, color):
    return html.Div(
        [
            html.Div(label, className="metric-label"),
            html.Div(str(value), className="metric-value", style={"color": color}),
        ],
        className="metric-card",
    )


def _opt(lst):
    return [{"label": v, "value": v} for v in sorted(set(lst)) if v]


@callback(
    Output("an-store", "data"),
    Input("an-init",   "n_intervals"),
    Input("an-refresh","n_clicks"),
)
def _load(_, __):
    from dash_app.api import get_analysis
    return get_analysis()


@callback(
    Output("an-rec", "options"),
    Output("an-ent", "options"),
    Output("an-ac",  "options"),
    Input("an-store","data"),
)
def _populate(rows):
    if not rows:
        return [], [], []
    return (
        _opt([r.get("recName","")    for r in rows]),
        _opt([r.get("entity","")     for r in rows]),
        _opt([r.get("assetClass","") for r in rows]),
    )


@callback(
    Output("an-kpi-high",      "children"),
    Output("an-kpi-med",       "children"),
    Output("an-kpi-low",       "children"),
    Output("an-kpi-corrected", "children"),
    Output("an-grid",          "rowData"),
    Input("an-store",  "data"),
    Input("an-search", "value"),
    Input("an-rec",    "value"),
    Input("an-ent",    "value"),
    Input("an-ac",     "value"),
    Input("an-sev",    "value"),
)
def _filter(rows, search, rec, ent, ac, sev):
    rows = rows or []

    if not rows:
        empty = _kpi("—", "—", "#475569")
        return empty, empty, empty, empty, []

    if search:
        s = search.lower()
        rows = [r for r in rows if
                s in str(r.get("tradeId","")).lower() or
                s in str(r.get("recName","")).lower() or
                s in str(r.get("entity","")).lower()]
    if rec: rows = [r for r in rows if r.get("recName")    == rec]
    if ent: rows = [r for r in rows if r.get("entity")     == ent]
    if ac:  rows = [r for r in rows if r.get("assetClass") == ac]
    if sev: rows = [r for r in rows if r.get("severity")   == sev]

    high      = sum(1 for r in rows if r.get("severity") == "High")
    med       = sum(1 for r in rows if r.get("severity") == "Medium")
    low       = sum(1 for r in rows if r.get("severity") == "Low")
    corrected = sum(1 for r in rows if r.get("correctedFlag"))

    grid_rows = []
    for r in rows:
        gr = dict(r)
        gr.pop("features", None)
        gr.pop("prediction", None)
        gr.pop("historicalMatches", None)
        gr.pop("mlFeatures", None)
        gr.pop("featureImportance", None)
        grid_rows.append(gr)

    return (
        _kpi("HIGH RISK",  high,      "#f87171"),
        _kpi("MEDIUM RISK",med,       "#fbbf24"),
        _kpi("LOW RISK",   low,       "#34d399"),
        _kpi("CORRECTED",  corrected, "#4f8ef7"),
        grid_rows,
    )


def _ageing_correction_widget(row: dict) -> html.Div:
    """Build the ageing bucket before/after correction widget for the detail panel."""
    corrected       = bool(row.get("correctedFlag") or row.get("correctionFlag"))
    orig_days       = row.get("originalAgeingDays")
    orig_bucket     = row.get("originalAgeingBucket", "—")
    curr_days       = row.get("ageingDays") or row.get("computedAgeingDays", "?")
    curr_bucket     = row.get("ageingBucket") or row.get("derivedAgeingBucket", "?")

    def _bucket_box(label_cls, label_txt, days, bucket, box_cls, days_cls, tag_cls):
        return html.Div(
            [
                html.Div(label_txt, className=f"ageing-bucket-label {label_cls}"),
                html.Div(f"{days}d", className=f"ageing-days {days_cls}"),
                html.Div(str(bucket), className=f"ageing-bucket-tag {tag_cls}"),
            ],
            className=f"ageing-bucket-box {box_cls}",
        )

    if corrected and orig_days is not None and str(orig_bucket) != str(curr_bucket):
        children = [
            html.Div("Ageing Correction", className="ageing-correction-title"),
            _bucket_box(
                "ageing-bucket-label-from", "✗  Before",
                orig_days, orig_bucket,
                "ageing-bucket-box-from", "ageing-days-from", "ageing-bucket-tag-from",
            ),
            html.Div("↓  corrected to", className="ageing-correction-arrow"),
            _bucket_box(
                "ageing-bucket-label-to", "✓  After",
                curr_days, curr_bucket,
                "ageing-bucket-box-to", "ageing-days-to", "ageing-bucket-tag-to",
            ),
        ]
    elif corrected:
        children = [
            html.Div("Ageing Correction", className="ageing-correction-title"),
            html.Div(
                "Days recalculated — bucket unchanged",
                style={"fontSize": "11px", "color": "#64748b", "marginBottom": "4px"},
            ),
            _bucket_box(
                "ageing-bucket-label-to", "✓  Verified",
                curr_days, curr_bucket,
                "ageing-bucket-box-to", "ageing-days-to", "ageing-bucket-tag-to",
            ),
        ]
    else:
        children = [
            html.Div("Ageing", className="ageing-correction-title"),
            _bucket_box(
                "ageing-bucket-label-ok", "✓  Current",
                curr_days, curr_bucket,
                "ageing-bucket-box-unchanged", "ageing-days-unchanged", "ageing-bucket-tag-unchanged",
            ),
        ]

    return html.Div(children, className="ageing-correction-widget")


@callback(
    Output("an-detail-panel", "children"),
    Input("an-grid",          "selectedRows"),
    State("an-store",         "data"),
    prevent_initial_call=True,
)
def _show_detail(selected, all_rows):
    if not selected:
        return []

    row_from_grid = selected[0]
    trade_id = row_from_grid.get("tradeId")

    row = row_from_grid
    if all_rows and trade_id:
        for r in all_rows:
            if r.get("tradeId") == trade_id:
                row = r
                break

    features      = row.get("mlFeatures") or {}
    importance    = row.get("featureImportance") or {}
    hist_matches  = row.get("historicalMatches") or []
    sev           = row.get("severity", "Unscored")
    risk_score    = row.get("riskScore")
    probability   = row.get("probability")

    feat_vals = [float(features.get(f, 0) or 0) for f in FEATURE_NAMES]
    imp_vals  = [float(importance.get(f, 0) or 0) for f in FEATURE_NAMES]

    feat_fig = go.Figure(
        go.Bar(
            y=FEATURE_LABELS,
            x=feat_vals,
            orientation="h",
            marker_color="#4f8ef7",
            text=[f"{v:.2f}" for v in feat_vals],
            textposition="outside",
        )
    )
    feat_fig.update_layout(
        **CHART_BASE,
        title={"text": "ML Feature Values", "font": {"size": 12}},
        xaxis=dict(gridcolor="#1e293b"),
        yaxis=dict(gridcolor="rgba(0,0,0,0)", tickfont=dict(size=10)),
        height=230,
    )

    imp_fig = go.Figure(
        go.Bar(
            y=FEATURE_LABELS,
            x=imp_vals,
            orientation="h",
            marker_color="#a78bfa",
            text=[f"{v:.1f}%" for v in imp_vals],
            textposition="outside",
        )
    )
    imp_fig.update_layout(
        **CHART_BASE,
        title={"text": "Feature Importance (%)", "font": {"size": 12}},
        xaxis=dict(gridcolor="#1e293b"),
        yaxis=dict(gridcolor="rgba(0,0,0,0)", tickfont=dict(size=10)),
        height=230,
    )

    sev_cls = {"High": "badge-high", "Medium": "badge-medium", "Low": "badge-low"}.get(sev, "badge-gray")

    try:
        risk_display = f"{float(risk_score):.1f}" if risk_score is not None else "—"
    except Exception:
        risk_display = str(risk_score) if risk_score else "—"

    try:
        prob_display = f"{float(probability)*100:.1f}%" if probability is not None else "—"
    except Exception:
        prob_display = "—"

    meta_rows = [
        ("Trade ID",     row.get("tradeId", "?")),
        ("Rec Name",     row.get("recName", "?")),
        ("Entity",       row.get("entity", "?")),
        ("Asset Class",  row.get("assetClass", "?")),
        ("Amount (£)",   f"£{float(row.get('amountGbp', 0) or 0):,.2f}"),
        ("Jira ID",      row.get("jiraId") or "—"),
    ]

    header = html.Div(
        [
            html.Div(
                [
                    html.Span(f"Trade {row.get('tradeId','?')}", style={"fontWeight": "700", "fontSize": "15px"}),
                    html.Span(" · ", style={"color": "#334155"}),
                    html.Span(sev, className=sev_cls),
                    html.Span(
                        f"  Risk Score: {risk_display}  ·  P(High): {prob_display}",
                        style={"color": "#64748b", "fontSize": "12px", "marginLeft": "10px"},
                    ),
                ],
                style={"marginBottom": "4px"},
            ),
            html.Div(
                [
                    html.Span(f"{row.get('recName','?')} · {row.get('entity','?')} · {row.get('assetClass','?')}",
                              style={"color": "#64748b", "fontSize": "12px"}),
                ]
            ),
        ]
    )

    meta_panel = html.Div(
        [
            html.Div("Break Details", className="info-panel-title"),
            *[
                html.Div(
                    [
                        html.Span(k, style={"color": "#64748b", "fontSize": "11px", "flex": "1"}),
                        html.Span(v, style={"color": "#e2e8f0", "fontSize": "12px", "fontWeight": "600"}),
                    ],
                    style={"display": "flex", "justifyContent": "space-between",
                           "padding": "4px 0", "borderBottom": "1px solid rgba(30,41,59,0.5)"},
                )
                for k, v in meta_rows
            ],
            _ageing_correction_widget(row),
        ],
        style={"height": "100%"},
    )

    matches_section = _build_matches(hist_matches)

    return html.Div(
        [
            header,
            html.Hr(style={"borderColor": "#1e3a5f", "margin": "12px 0"}),
            dbc.Row(
                [
                    dbc.Col(meta_panel, md=2),
                    dbc.Col(dcc.Graph(figure=feat_fig, config={"displayModeBar": False}), md=3),
                    dbc.Col(dcc.Graph(figure=imp_fig,  config={"displayModeBar": False}), md=3),
                    dbc.Col(matches_section, md=4),
                ],
                className="g-3",
            ),
        ],
        className="detail-panel",
    )


def _build_matches(matches):
    if not matches:
        return html.Div(
            [
                html.Div("Historical Linkage", className="info-panel-title"),
                html.Div(
                    [
                        html.Div("No historical matches from previous uploads.",
                                 style={"color": "#475569", "fontSize": "12px", "marginBottom": "4px"}),
                        html.Div("Upload additional break files over time to build a reference pool.",
                                 style={"color": "#334155", "fontSize": "11px"}),
                    ]
                ),
            ]
        )

    cards = []
    for i, m in enumerate(matches[:5], 1):
        sim     = float(m.get("similarity", 0))
        sev     = m.get("severity") or "Unscored"
        sev_cls = {"High": "badge-high", "Medium": "badge-medium", "Low": "badge-low"}.get(sev, "badge-gray")

        try:
            amount_display = f"£{float(m.get('amountGbp', 0) or 0):,.0f}"
        except Exception:
            amount_display = "—"

        try:
            risk_display = f"{float(m.get('riskScore', 0) or 0):.1f}"
        except Exception:
            risk_display = "—"

        row_meta = [
            ("Trade ID",  m.get("tradeId", "?")),
            ("Jira",      m.get("jiraId") or "—"),
            ("Amount",    amount_display),
            ("Ageing",    f"{m.get('ageingDays', '?')}d"),
            ("Bucket",    m.get("ageingBucket", "?")),
            ("Risk",      risk_display),
            ("Date",      str(m.get("startDate", "?"))[:10]),
        ]

        feat_contrib = m.get("featureContributions", {})
        fc_names = list(feat_contrib.keys())[:6]
        fc_vals  = [float(feat_contrib[k] or 0) for k in fc_names]

        mini_fig = None
        if fc_vals and sum(fc_vals) > 0:
            short_names = [n.replace("breakFrequency30d", "Freq").replace("avgAgeing", "Ageing")
                            .replace("thresholdDistance", "Thresh").replace("repeatTradeFlag", "Repeat")
                            .replace("segmentVolatility", "Volat").replace("maturityProximityDays", "Matur")
                            for n in fc_names]
            mini_fig = go.Figure(
                go.Bar(
                    x=short_names,
                    y=fc_vals,
                    marker_color="#4f8ef7",
                    text=[f"{v:.0f}%" for v in fc_vals],
                    textposition="outside",
                    textfont=dict(size=8),
                )
            )
            mini_fig.update_layout(
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                font=dict(color="#e2e8f0", size=8),
                margin=dict(l=4, r=4, t=4, b=28),
                xaxis=dict(tickfont=dict(size=7), gridcolor="rgba(0,0,0,0)"),
                yaxis=dict(gridcolor="rgba(0,0,0,0)", showticklabels=False),
                height=80,
                showlegend=False,
            )

        cards.append(
            html.Div(
                [
                    html.Div(
                        [
                            html.Span(str(i), className="match-rank"),
                            html.Span(f"{sim:.1f}% match",
                                      style={"color": "#4f8ef7", "fontWeight": "700", "fontSize": "12px"}),
                            html.Span(sev, className=sev_cls, style={"marginLeft": "8px"}),
                        ],
                        style={"marginBottom": "8px"},
                    ),
                    *[
                        html.Div(
                            [
                                html.Span(k + ": ", style={"color": "#64748b", "fontSize": "11px"}),
                                html.Span(v, style={"color": "#e2e8f0", "fontSize": "11px", "fontWeight": "500"}),
                            ]
                        )
                        for k, v in row_meta
                    ],
                    (
                        dcc.Graph(figure=mini_fig, config={"displayModeBar": False}, style={"marginTop": "6px"})
                        if mini_fig else html.Div()
                    ),
                ],
                className="match-card",
            )
        )

    return html.Div(
        [
            html.Div(
                f"Historical Linkage  ({len(matches)} match{'es' if len(matches) != 1 else ''})",
                className="info-panel-title",
            ),
            html.Div(cards, style={"maxHeight": "480px", "overflowY": "auto"}),
        ]
    )
