import dash
from dash import html, dcc, callback, Output, Input
import dash_bootstrap_components as dbc
import dash_ag_grid as dag

dash.register_page(__name__, path="/audit", name="Audit Log", order=5)

ACTION_COLORS = {
    "UPLOAD":    "#4f8ef7",
    "PIPELINE":  "#a78bfa",
    "TRAIN":     "#34d399",
    "SCORE":     "#fbbf24",
    "DELETE":    "#f87171",
    "ERROR":     "#f87171",
}

_col_defs = [
    {
        "field": "timestamp",
        "headerName": "Timestamp",
        "width": 170,
        "sort": "desc",
        "valueFormatter": {"function": "params.value ? params.value.replace('T',' ').slice(0,19) : ''"},
    },
    {
        "field": "action",
        "headerName": "Action",
        "width": 130,
        "cellStyle": {
            "styleConditions": [
                {"condition": "params.value === 'UPLOAD'",   "style": {"color": "#4f8ef7", "fontWeight": "700"}},
                {"condition": "params.value === 'PIPELINE'", "style": {"color": "#a78bfa", "fontWeight": "700"}},
                {"condition": "params.value === 'TRAIN'",    "style": {"color": "#34d399", "fontWeight": "700"}},
                {"condition": "params.value === 'SCORE'",    "style": {"color": "#fbbf24", "fontWeight": "700"}},
                {"condition": "params.value === 'DELETE'",   "style": {"color": "#f87171", "fontWeight": "700"}},
                {"condition": "params.value === 'ERROR'",    "style": {"color": "#f87171", "fontWeight": "700"}},
            ],
            "defaultStyle": {"color": "#94a3b8", "fontWeight": "700"},
        },
    },
    {"field": "entity",   "headerName": "Entity",    "flex": 1, "minWidth": 100},
    {"field": "entityId", "headerName": "Entity ID", "flex": 1, "minWidth": 100},
    {
        "field": "details",
        "headerName": "Details",
        "flex": 2,
        "minWidth": 200,
        "valueFormatter": {
            "function": "typeof params.value === 'object' ? JSON.stringify(params.value) : (params.value || '')"
        },
    },
]

layout = html.Div(
    [
        html.Div(
            [
                html.H1("📋 Audit Log", style={"fontSize": "22px", "fontWeight": "700", "margin": "0"}),
                html.P(
                    "Full history of uploads, pipeline runs, model training and scoring events",
                    style={"fontSize": "13px", "color": "#64748b", "margin": "4px 0 0 0"},
                ),
            ],
            className="page-header",
        ),
        dbc.Row(
            [
                dbc.Col(html.Div(id="audit-kpi-total"),   md=4),
                dbc.Col(html.Div(id="audit-kpi-actions"), md=4),
                dbc.Col(html.Div(id="audit-kpi-latest"),  md=4),
            ],
            className="g-3 mb-3",
        ),
        dbc.Row(
            [
                dbc.Col(
                    dbc.Button(
                        "🔄 Refresh",
                        id="audit-refresh-btn",
                        outline=True,
                        color="secondary",
                        size="sm",
                        n_clicks=0,
                    ),
                    width="auto",
                ),
            ],
            className="mb-3",
        ),
        dcc.Loading(
            dag.AgGrid(
                id="audit-grid",
                rowData=[],
                columnDefs=_col_defs,
                className="ag-theme-alpine-dark",
                style={"height": "520px"},
                dashGridOptions={
                    "suppressCellFocus": True,
                    "pagination": True,
                    "paginationPageSize": 50,
                },
                defaultColDef={"resizable": True, "sortable": True, "filter": True},
            ),
            color="#4f8ef7",
        ),
        dcc.Interval(id="audit-init", interval=400, max_intervals=1, n_intervals=0),
    ]
)


def _kpi(label, value, color):
    return html.Div(
        [
            html.Div(label, className="metric-label"),
            html.Div(str(value), className="metric-value", style={"color": color}),
        ],
        className="metric-card",
    )


@callback(
    Output("audit-grid",        "rowData"),
    Output("audit-kpi-total",   "children"),
    Output("audit-kpi-actions", "children"),
    Output("audit-kpi-latest",  "children"),
    Input("audit-init",         "n_intervals"),
    Input("audit-refresh-btn",  "n_clicks"),
)
def _load(_, __):
    from dash_app.api import get_audit_log
    rows = get_audit_log()

    total   = len(rows)
    actions = len({r.get("action","") for r in rows})
    latest  = rows[0].get("timestamp","—")[:19].replace("T"," ") if rows else "—"

    return (
        rows,
        _kpi("TOTAL ENTRIES",   total,   "#4f8ef7"),
        _kpi("UNIQUE ACTIONS",  actions, "#a78bfa"),
        _kpi("LATEST EVENT",    latest,  "#34d399"),
    )
